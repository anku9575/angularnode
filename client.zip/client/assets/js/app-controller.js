mainApp.controller('mainController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "appMethods", "$localStorage", "$timeout", "$window", "$state", "$sessionStorage", "$compile", "$window", "$interval", function($scope, $rootScope, $http, $location, appAlerts, appMethods, $localStorage, $timeout, $window, $state, $sessionStorage, $compile, $window, $interval){
    
 alert("dfdf")
    $scope.myOrderBy = 'UserName';
    $scope.reverse = false;
    $scope.orderByMe = function(col){
        $scope.myOrderBy = col;
        if($scope.reverse){
            $scope.reverse = false;
            // $scope.reverseclass = 'arrow-up';
        } else {
            $scope.reverse = true;
            // $scope.reverseclass = 'arrow-down';
        }
    } 

    $scope.sortClass = function(col){
        if($scope.myOrderBy == col ){
            if($scope.reverse){
                // return 'arrow-down'; 
            } else {
                // return 'arrow-up';
            }
        } else {
            return '';
        }
    }

    $scope.showNotification = function(from, align, ErrorMessage){
        color = Math.floor((Math.random() * 4) + 1);
        $.notify({
            icon:"notifications",
            message: ErrorMessage
        },{
            type: type[color],
            timer: 1000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    /* logout all modules */
	$scope.logout = function(){
        swal({
            title: 'Are you sure?',
            text: "want to logout from Feet On Street !",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, log me out!',
            cancelButtonText: 'Not now !',
            confirmButtonClass: "btn btn-success",
            cancelButtonClass: "btn btn-danger",
            reverseButtons: true,
            buttonsStyling: false
        }).then(function() {
            swal({
                title: 'Logged Out',
                text: 'Successfully logout :)',
                type: 'success',
                confirmButtonClass: "btn btn-success",
                allowOutsideClick: false,
                buttonsStyling: false
            }).catch(swal.noop)
            $timeout(function(){
                delete $localStorage.userData;
                delete $localStorage.AccessToken;
                // $location.path("https://45.114.79.242/QAgenericComponent");
                window.location.href = "https://45.114.79.242/QAgenericComponent";
            }, 100);
        }, function(dismiss) {
            // dismiss can be 'overlay', 'cancel', 'close', 'esc', 'timer'
            if (dismiss === 'cancel') {
                swal({
                    title: 'Continue &',
                    text: 'Enjoy your ride :)',
                    type: 'success',
                    confirmButtonClass: "btn btn-info",
                    buttonsStyling: false
                }).catch(swal.noop)
            }
        })
    }

}]);