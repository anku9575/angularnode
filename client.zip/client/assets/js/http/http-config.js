mainApp.config(function ($httpProvider) {
    $httpProvider.interceptors.push('httpRequestInterceptor');
});

mainApp.factory('httpRequestInterceptor', function () {
  return {
    request: function (config) {
        //alert(11);
        // use this to destroying other existing headers
        try {
            config.headers['Content-Type'] = 'application/json';
            /*config.headers['Authorization-ApiKey'] = 'Ak12mr27Xwg@d89ul';
            if (localStorage.getItem("Lcid")) {
                config.headers['Lcid'] = localStorage.getItem("Lcid");
            }
            else {
                config.headers['Lcid'] = 1033;
            }*/
        }
        catch (err) {
            console.log(err);
        }
        return config;
    }
  };
});

mainApp.config(function ($httpProvider) {
    $httpProvider.interceptors.push('httpRequestInterceptor');
});