/**
*	Including all the dependencies
***/
var mainApp = angular.module('mainApp', [
	'ui.router', 
	// 'angularUtils.directives.dirPagination',
	'oc.lazyLoad', 
	'ngCookies', 
	'ngStorage', 
	'ngSanitize',
	'angular-loading-bar',
	'ngMaterial', 

]);
