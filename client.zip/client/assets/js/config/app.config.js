/**
*	Defin all global configuration
***/
mainApp.run(['$rootScope', function ($rootScope) {
    // $rootScope.serviceURL = 'http://192.168.43.214:2017/';
}]);

mainApp.constant('JS_REQUIRES', {
    //*** Scripts
    scripts: {
        //*** Controllers
        'loginContrller ': 'assets/modules/login/controller/login-controller.js'
    },
    //*** angularJS Modules
    modules: []
});

mainApp.config(['$localStorageProvider',
function ($localStorageProvider) {
    $localStorageProvider.setKeyPrefix('mainApp');
    // console.log($localStorageProvider);
}]);

/*Angular-Loading-Bar
configuration*/
mainApp.config(['cfpLoadingBarProvider',
function (cfpLoadingBarProvider) {
    cfpLoadingBarProvider.includeBar = true;
    cfpLoadingBarProvider.includeSpinner = true;
}]);
