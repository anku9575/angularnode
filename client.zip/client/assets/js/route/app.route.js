/**
*   Configration when route has change
***/
mainApp.run(['$rootScope', '$timeout', '$interval', '$location', '$localStorage', '$state', function ($rootScope, $timeout, $interval, $location, $localStorage, $state) {
    if ($localStorage.userData == null) {
        
    }

    /*Checking state fully changed*/
    $rootScope.$on('$stateChangeSuccess', function (event, current, previous) {
        document.body.scrollTop = document.documentElement.scrollTop = 0;
        if($localStorage.userData == null){
            var cURL = current.url;
            switch(cURL){
                case '/':
                    $location.path('/login');
                    break;
                case '/login':
                    $location.path('/login');
                    break;    
                default:
                    $location.path('/');
                    break;
            }
        } else {

        }
    });
    
}]);

/**
*   Define all the routes here
***/
mainApp.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$provide', '$ocLazyLoadProvider', 'JS_REQUIRES',
function ($stateProvider, $urlRouterProvider, $locationProvider, $provide, $ocLazyLoadProvider, jsRequires) {
    /**
    *   Define global method provider
    ***/
    mainApp.value = function (name, value) {
        $provide.value(name, value);
        return (this);
    };

    /*Here I have declear the global app alerts*/
    mainApp.value("appAlerts", {});
    mainApp.value("appMethods", {});


    $ocLazyLoadProvider.config({
        debug: false,
        serie: true,
        modules: [{
            name: 'login',
            files: [
                'assets/modules/login/controller/login-controller.js'
            ],
            serie: true
        }]
    });

    $urlRouterProvider.otherwise('/login')
    /**
    *   State defination START
    ***/
    $stateProvider
        // GET ACCESS TOKEN STATES AND NESTED VIEWS ========================================
        .state('login', {
            url: '/login',
            title: 'login',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/login/login.html', controller: 'loginController' },
                'sidebarView@login': { templateUrl: 'assets/templates/partial/sidebar.html'}
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['login'])
                }]
            }
        })
        /*.state('app', {
            url: '/app',
            title: 'login',
            activeOrder: 1,
            abstract: true,
            views: {
                '': { templateUrl: 'assets/templates/partial/app.html'},
                'contentView@app': { templateUrl: 'assets/templates/partial/content.html'},
                'sidebarView@app': { templateUrl: 'assets/templates/partial/sidebar.html', controller: 'mainController'},
                'headerView@app': { templateUrl: 'assets/templates/partial/header.html', controller: 'mainController'},
                'fixedPluginView@app': { templateUrl: 'assets/templates/partial/fixedPlugin.html', controller: 'mainController'}
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['login'])
                }]
            }
        })*/
        $locationProvider.html5Mode(true);
        
        
	
	//check browser support
        if(window.history && window.history.pushState){
            //$locationProvider.html5Mode(true); will cause an error $location in HTML5 mode requires a  tag to be present! Unless you set baseUrl tag after head tag like so: <head> <base href="">

            // to know more about setting base URL visit: https://docs.angularjs.org/error/$location/nobase

            // if you don't wish to set base URL then use this
            /*$locationProvider.html5Mode({
                enabled: true,
                requireBase: false
            });*/
        }

    /**
    *   State defination END
    ***/
    /*Generates a resolve object previously configured in constant.JS_REQUIRES (config.constant.js)*/
    function loadSequence() {
        var _args = arguments;
        return {
            deps: ['$ocLazyLoad', '$q',
            function ($ocLL, $q) {
                var promise = $q.when(1);
                for (var i = 0, len = _args.length; i < len; i++) {
                    promise = promiseThen(_args[i]);
                }
                return promise;

                function promiseThen(_arg) {
                    if (typeof _arg == 'function')
                        return promise.then(_arg);
                    else
                        return promise.then(function () {
                            var nowLoad = requiredData(_arg);
                            if (!nowLoad)
                                return $.error('Route resolve: Bad resource name [' + _arg + ']');
                            return $ocLL.load(nowLoad);
                        });
                }

                function requiredData(name) {
                    if (jsRequires.modules)
                        for (var m in jsRequires.modules)
                            if (jsRequires.modules[m].name && jsRequires.modules[m].name === name)
                                return jsRequires.modules[m];
                    return jsRequires.scripts && jsRequires.scripts[name];
                }
            }]
        };
    }
}]);