/**
* Purpose – For login.
* @author - Ankit Solanki
* Created at September 02, 2018
**/

angular.module("mainApp").controller('loginController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$stateParams", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $stateParams) {
alert(54545)   
	$scope.signInUser = function(isValid){
		if(isValid){
			$http.post($rootScope.serviceURL+"login", $scope.formData).then(function(response){
				var data = response.data;
				if(data.ErrorCode == 200 && data.success == true){
					$localStorage.userData = data;
					$scope.showNotification(from = 'bottom', align='right', "Login Successfull !!!");
					// $location.path("dashboard");
					setTimeout(function() {
						window.location = $("base").attr('href') + "app/dashboard";
					}, 1000);
				} else {
					$scope.showNotification(from = 'bottom', align='right', "Invalid email or password !!!");
				}
			}).catch(function(err){
				return err;
			})
		} else{
			$scope.submitted = true
		}
	}
}]);