mainApp.factory('tokenService', ['$http',function($http) {
    return {
        post : function(url,formData) {
            return $http.post(url, formData);
        }
    }
}]);


/**
*   Configration when route has change
***/
mainApp.run(['$rootScope', '$timeout', '$interval', '$location', '$localStorage', '$state', 'tokenService', function ($rootScope, $timeout, $interval, $location, $localStorage, $state, tokenService) {
    if ($localStorage.userData == null) {
        
    }



    $rootScope.$on('$stateChangeStart', function (event, current, previous) {
        console.log(event)
        console.log(current)
        console.log(current.name)
        console.log(previous)
        console.log($localStorage.AccessToken)
        if(current.name != "logintoken" && current.name != "login"){
            if($localStorage.AccessToken){
                if(!$rootScope.isVerified){
                   tokenService.post("https://45.114.79.242/QAComponentService/ComponentsService.svc/IsValidateUserByFOSLoginSession", {"loginSession" : $localStorage.AccessToken}).then(function(response){
                        console.log(response)
                        var accessTokenResponse = response.data
                        if(accessTokenResponse.IsSuccess == true){
                            $rootScope.isVerified = true;
                            // alert("token true")
                        } else {
                            swal({
                                title: 'Invalid Token !',
                                text: 'Please login POIS PLUS to continue in Feet On Street :)',
                                type: 'success',
                                confirmButtonClass: "btn btn-success",
                                allowOutsideClick: false,
                                buttonsStyling: false
                            }).then(function(result) {
                                console.log(result)
                                if(result == true){
                                    window.location.href = "https://45.114.79.242/QAgenericComponent";
                                }
                            }).catch(swal.noop)
                            event.preventDefault();
                        }
                    });  
                }
                document.body.scrollTop = document.documentElement.scrollTop = 0;
                var urlMenu = current.url.split('/')
                $rootScope.sidebarData = $localStorage.userData.LoginUserTypeRights
                var hrefs = ["exportFile"]
                for(var i = 0; i < $rootScope.sidebarData.length; i++){
                    var href = $rootScope.sidebarData[i].href
                    var subMenu = $rootScope.sidebarData[i].subMenu
                    hrefs.push(href)
                    for(var j = 0; j < subMenu.length; j++){
                        var href1 = subMenu[j].href
                        hrefs.push(href1)
                    }
                }
                if (hrefs.indexOf("concern") > -1) {
                    hrefs.push("concernSearch")
                }
                if (hrefs.indexOf("survey") > -1) {
                    hrefs.push("surveySearch")
                }
                var arr = hrefs.filter(function(e){return e});
                if (arr.indexOf(urlMenu[1]) > -1) {
                    //console.log("In the array")
                } else {
                    if(urlMenu[1] != "login"){
                        //console.log("Not the array")
                        swal("","You don't have permission to use this page.", "warning")
                        event.preventDefault();
                    }
                }
            } else {
                swal({
                    title: 'Invalid Token !',
                    text: 'Please login POIS PLUS to continue in Feet On Street :)',
                    type: 'success',
                    confirmButtonClass: "btn btn-success",
                    allowOutsideClick: false,
                    buttonsStyling: false
                }).then(function(result) {
                    console.log(result)
                    if(result == true){
                        window.location.href = "https://45.114.79.242/QAgenericComponent";
                    }
                }).catch(swal.noop)
                event.preventDefault();
            }
        } else {
            // alert("token true else")
            document.body.scrollTop = document.documentElement.scrollTop = 0;
            var urlMenu = current.url.split('/')
            $rootScope.sidebarData = $localStorage.userData.LoginUserTypeRights
            var hrefs = ["exportFile"]
            for(var i = 0; i < $rootScope.sidebarData.length; i++){
                var href = $rootScope.sidebarData[i].href
                var subMenu = $rootScope.sidebarData[i].subMenu
                hrefs.push(href)
                for(var j = 0; j < subMenu.length; j++){
                    var href1 = subMenu[j].href
                    hrefs.push(href1)
                }
            }
            if (hrefs.indexOf("concern") > -1) {
                hrefs.push("concernSearch")
            }
            if (hrefs.indexOf("survey") > -1) {
                hrefs.push("surveySearch")
            }
            var arr = hrefs.filter(function(e){return e});
            if (arr.indexOf(urlMenu[1]) > -1) {
                //console.log("In the array")
            } else {
                if(urlMenu[1] != "login"){
                    //console.log("Not the array")
                    swal("","You don't have permission to use this page.", "warning")
                    event.preventDefault();
                }
            }
        }
    });

    /*Checking state fully changed*/
    $rootScope.$on('$stateChangeSuccess', function (event, current, previous) {
        if($localStorage.userData == null){
            /*swal({
                title: 'Invalid Token !',
                text: "Not a valid request !",
                type: 'warning',
                confirmButtonText: 'Ok!',
                confirmButtonClass: "btn btn-success",
                buttonsStyling: false
            }).then(function(result) {
                console.log(result)
                if(result == true){
                    swal({
                        title: 'Reference',
                        text: 'Please login POIS PLUS to continue in Feet On Street :)',
                        type: 'success',
                        confirmButtonClass: "btn btn-success",
                        buttonsStyling: false
                    }).then(function(result) {
                        console.log(result)
                        if(result == true){
                            window.location.href = "https://45.114.79.242/QAgenericComponent";
                        }
                    }).catch(swal.noop)
                }
            })*/
            /*var cURL = current.url;
            switch(cURL){
                case '/':
                    $location.path('/login');
                    break;
                default:
                    $location.path('/');
                    break;
            }*/
        } else {
            $rootScope.sidebarData = $localStorage.userData.LoginUserTypeRights;
        }
    });
    
}]);

/**
*   Define all the routes here
***/
mainApp.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$provide', '$ocLazyLoadProvider', 'JS_REQUIRES',
function ($stateProvider, $urlRouterProvider, $locationProvider, $provide, $ocLazyLoadProvider, jsRequires) {
    /**
    *   Define global method provider
    ***/
    mainApp.value = function (name, value) {
        $provide.value(name, value);
        return (this);
    };

    /*Here I have declear the global app alerts*/
    mainApp.value("appAlerts", {});
    mainApp.value("appMethods", {});


    $ocLazyLoadProvider.config({
        debug: false,
        serie: true,
        modules: [{
            name: 'login',
            files: [
                'assets/modules/login/controller/login-controller.js'
            ],
            serie: true
        }, {
            name: 'dashboard',
            files: [
                'assets/modules/dashboard/controller/dashboard-controller.js'
            ],
            serie: true
        }, {
            name: 'addBranch',
            files: [
                'assets/modules/branch/controller/addBranch-controller.js'
            ],
            serie: true
        }, {
            name: 'role',
            files: [
                'assets/modules/role/controller/role-controller.js'
            ],
            serie: true
        }, {
            name: 'settings',
            files: [
                'assets/modules/settings/controller/settings-controller.js'
            ],
            serie: true
        }, {
            name: 'user',
            files: [
                'assets/modules/user/controller/user-controller.js'
            ],
            serie: true
        }, {
            name: 'menuForm',
            files: [
                'assets/modules/menuForm/controller/menuForm-controller.js'
            ],
            serie: true
        }, {
            name: 'addDealer',
            files: [
                'assets/modules/dealer/controller/addDealer-controller.js'
            ],
            serie: true
        }, {
            name: 'concern',
            files: [
                'assets/modules/concern/controller/concern-controller.js'
            ],
            serie: true
        }, {
            name: 'survey',
            files: [
                'assets/modules/survey/controller/survey-controller.js'
            ],
            serie: true
        }, {
            name: 'addSurvey',
            files: [
                'assets/modules/survey/controller/addSurvey-controller.js'
            ],
            serie: true
        }, {
            name: 'teams',
            files: [
                'assets/modules/teams/controller/teams-controller.js'
            ],
            serie: true
        }, {
            name: 'myTour',
            files: [
                'assets/modules/teams/controller/myTour-controller.js'
            ],
            serie: true
        }, {
            name: 'lock',
            files: [
                'assets/modules/lock/controller/lock-controller.js'
            ],
            serie: true
        }, {
            name: 'dealerSubDealer',
            files: [
                'assets/modules/dealer/controller/dealerSubDealer-controller.js'
            ],
            serie: true
        }, {
            name: 'exportFile',
            files: [
                'assets/modules/exportFile/controller/exportFile-controller.js'
            ],
            serie: true
        }]
    });

    //$urlRouterProvider.otherwise('/login/cff2688c-331f-460a-b334-04f2c29c5b68');
    /**
    *   State defination START
    ***/
    $stateProvider
        // GET ACCESS TOKEN STATES AND NESTED VIEWS ========================================
        .state('login', {
            url: '/login',
            title: 'login',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/login/login.html', controller: 'loginController' },
                'sidebarView@login': { templateUrl: 'assets/templates/partial/sidebar.html'}
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['login'])
                }]
            }
        })
        // GET ACCESS TOKEN STATES AND NESTED VIEWS ========================================
        .state('logintoken', {
            url: '/login/:AccessToken',
            title: 'login',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/login/login.html', controller: 'loginController' },
                'sidebarView@login': { templateUrl: 'assets/templates/partial/sidebar.html'}
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['login'])
                }]
            }
        })
        .state('app', {
            url: '/app',
            title: 'login',
            activeOrder: 1,
            abstract: true,
            views: {
                '': { templateUrl: 'assets/templates/partial/app.html'},
                'contentView@app': { templateUrl: 'assets/templates/partial/content.html'},
                'sidebarView@app': { templateUrl: 'assets/templates/partial/sidebar.html', controller: 'mainController'},
                'headerView@app': { templateUrl: 'assets/templates/partial/header.html', controller: 'mainController'},
                'fixedPluginView@app': { templateUrl: 'assets/templates/partial/fixedPlugin.html', controller: 'mainController'}
            }/*,
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['login'])
                }]
            }*/
        })
        .state('app.dashboard', {
            url: '/dashboard',
            title: 'dashboard',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/dashboard/dashboard.html', controller: 'dashboardController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['dashboard'])
                }]
            }
        })
        .state('app.addBranch', {
            url: '/addBranch',
            title: 'addBranch',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/branch/addBranch.html', controller: 'addBranchController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['addBranch'])
                }]
            }
        })
        .state('app.role', {
            url: '/role',
            title: 'role',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/role/role.html', controller: 'roleController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['role'])
                }]
            }
        })
        .state('app.addRole', {
            url: '/addRole',
            title: 'addRole',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/role/addRole.html', controller: 'roleController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['role'])
                }]
            }
        })
        .state('app.settings', {
            url: '/settings',
            title: 'settings',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/settings/settings.html', controller: 'settingsController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['settings'])
                }]
            }
        })
        .state('app.user', {
            url: '/user',
            title: 'user',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/user/user.html', controller: 'userController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['user'])
                }]
            }
        })
        .state('app.users', {
            url: '/user/:id',
            title: 'user',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/user/user.html', controller: 'userController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['user'])
                }]
            }
        })
        .state('app.userRole', {
            url: '/userRole',
            title: 'userRole',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/user/userRole.html', controller: 'userController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['user'])
                }]
            }
        })
        .state('app.userRoleSearch', {
            url: '/userRole/:id',
            title: 'userRole',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/user/userRole.html', controller: 'userController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['user'])
                }]
            }
        })
        .state('app.resetDevice', {
            url: '/resetDevice',
            title: 'resetDevice',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/user/resetDevice.html', controller: 'userController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['user'])
                }]
            }
        })
        .state('app.menuForm', {
            url: '/menuForm',
            title: 'menuForm',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/menuForm/menuForm.html', controller: 'menuFormController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['menuForm'])
                }]
            }
        })
        .state('app.addDealer', {
            url: '/addDealer',
            title: 'addDealer',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/dealer/addDealer.html', controller: 'addDealerController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['addDealer'])
                }]
            }
        })
        .state('app.concern', {
            url: '/concern',
            title: 'concern',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/concern/concern.html', controller: 'concernController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['concern'])
                }]
            }
        })
        .state('app.concernSearch', {
            url: '/concernSearch/:type/:id',
            title: 'concern',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/concern/concern.html', controller: 'concernController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['concern'])
                }]
            }
        })
        .state('app.concernUserSearch', {
            url: '/concern/:userId',
            title: 'concern',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/concern/concern.html', controller: 'concernController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['concern'])
                }]
            }
        })
        .state('app.survey', {
            url: '/survey',
            title: 'survey',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/survey/survey.html', controller: 'surveyController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['survey'])
                }]
            }
        })
        .state('app.surveySearch', {
            url: '/surveySearch/:type/:id/:FromDashboardScreen',
            title: 'survey',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/survey/survey.html', controller: 'surveyController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['survey'])
                }]
            }
        })
        .state('app.addSurvey', {
            url: '/addSurvey',
            title: 'addSurvey',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/survey/addSurvey.html', controller: 'addSurveyController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['addSurvey'])
                }]
            }
        })
        .state('app.teams', {
            url: '/teams',
            title: 'teams',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/teams/teams.html', controller: 'teamsController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['teams'])
                }]
            }
        })
        .state('app.myTour', {
            url: '/myTour',
            title: 'myTour',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/teams/myTour.html', controller: 'myTourController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['myTour'])
                }]
            }
        })
        .state('app.dealerSubDealer', {
            url: '/dealerSubDealer',
            title: 'dealerSubDealer',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/dealer/dealerSubDealer.html', controller: 'dealerSubDealerController' },
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['dealerSubDealer'])
                }]
            }
        })
        .state('app.exportFile', {
            url: '/exportFile',
            title: 'exportFile',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/exportFile/exportFile.html', controller: 'exportFileController' }
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['exportFile'])
                }]
            }
        })
        .state('lock', {
            url: '/lock',
            title: 'lock',
            activeOrder: 1,
            views: {
                '': { templateUrl: 'assets/modules/lock/lock.html', controller: 'lockController' }
            },
            resolve: { // Any property in resolve should return a promise and is executed before the view is loaded
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(['lock'])
                }]
            }
        })
        $locationProvider.html5Mode(true);
        
        
	
	//check browser support
        if(window.history && window.history.pushState){
            //$locationProvider.html5Mode(true); will cause an error $location in HTML5 mode requires a  tag to be present! Unless you set baseUrl tag after head tag like so: <head> <base href="">

            // to know more about setting base URL visit: https://docs.angularjs.org/error/$location/nobase

            // if you don't wish to set base URL then use this
            /*$locationProvider.html5Mode({
                enabled: true,
                requireBase: false
            });*/
        }

    /**
    *   State defination END
    ***/
    /*Generates a resolve object previously configured in constant.JS_REQUIRES (config.constant.js)*/
    function loadSequence() {
        var _args = arguments;
        return {
            deps: ['$ocLazyLoad', '$q',
            function ($ocLL, $q) {
                var promise = $q.when(1);
                for (var i = 0, len = _args.length; i < len; i++) {
                    promise = promiseThen(_args[i]);
                }
                return promise;

                function promiseThen(_arg) {
                    if (typeof _arg == 'function')
                        return promise.then(_arg);
                    else
                        return promise.then(function () {
                            var nowLoad = requiredData(_arg);
                            if (!nowLoad)
                                return $.error('Route resolve: Bad resource name [' + _arg + ']');
                            return $ocLL.load(nowLoad);
                        });
                }

                function requiredData(name) {
                    if (jsRequires.modules)
                        for (var m in jsRequires.modules)
                            if (jsRequires.modules[m].name && jsRequires.modules[m].name === name)
                                return jsRequires.modules[m];
                    return jsRequires.scripts && jsRequires.scripts[name];
                }
            }]
        };
    }
}]);