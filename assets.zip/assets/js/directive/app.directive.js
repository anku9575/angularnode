/**
*   For checking the combination of two password.
***/
mainApp.directive('confirmPwd', function ($interpolate, $parse) {
    return {
        require: 'ngModel',
        link: function(scope, elem, attr, ngModelCtrl) {

            var pwdToMatch = $parse(attr.confirmPwd);
            var pwdFn = $interpolate(attr.confirmPwd)(scope);

            scope.$watch(pwdFn, function(newVal) {
                ngModelCtrl.$setValidity('password', ngModelCtrl.$viewValue == newVal);
            })

            ngModelCtrl.$validators.password = function(modelValue, viewValue) {
                var value = modelValue || viewValue;
                return value == pwdToMatch(scope);
            };

        }
    }
});

/**
*   For making height for scroll to footer
***/
mainApp.directive("inputVerify", function() {
   return {
      require: "ngModel",
      scope: {
        inputVerify: '='
      },
      link: function(scope, element, attrs, ctrl) {
        scope.$watch(function() {
            var combined;

            if (scope.inputVerify || ctrl.$viewValue) {
               combined = scope.inputVerify + '_' + ctrl.$viewValue; 
            }                    
            return combined;
        }, function(value) {
            if (value) {
                ctrl.$parsers.unshift(function(viewValue) {
                    var origin = scope.inputVerify;
                    if (origin !== viewValue) {
                        ctrl.$setValidity("inputVerify", false);
                        return undefined;
                    } else {
                        ctrl.$setValidity("inputVerify", true);
                        return viewValue;
                    }
                });
            }
        });
     }
   };
});

/**
*   For capture scroll event
***/
mainApp.directive("scroll", function ($window) {
    return function(scope, element, attrs) {
        angular.element("#budgetHeight").bind("scroll", function() {
            var sub = ($($("#budgetHeight").children()[0]).height() * 2);

            var scrollTop = angular.element(this).scrollTop();
            var offsetHeight = $(angular.element(this)[0])[0].offsetHeight;
            var finalCalculation = scrollTop+offsetHeight;
            var scrollHeight = angular.element(this)[0].scrollHeight-sub;

            if(finalCalculation > scope.finalCalculation){
                if( scrollHeight < finalCalculation && (scrollHeight+10) > finalCalculation){
                    scope.GetGroupWithMember();
                }
            }
            scope.finalCalculation = finalCalculation;

            scope.$apply();
        });
        angular.element("#budgetGroupHeight").bind("scroll", function() {
            var sub = ($($("#budgetGroupHeight").children()[0]).height() * 2);

            var scrollTop = angular.element(this).scrollTop();
            var offsetHeight = $(angular.element(this)[0])[0].offsetHeight;
            var finalCalculation = scrollTop+offsetHeight;
            var scrollHeight = angular.element(this)[0].scrollHeight-sub;

            if(finalCalculation > scope.finalCalculation){
                if( scrollHeight < finalCalculation && (scrollHeight+10) > finalCalculation){
                    /*scope.GetGroupWithMemberInBudget();*/
                }
            }
            scope.finalCalculation = finalCalculation;

            scope.$apply();
        });
        angular.element("#budgetListHeight").bind("scroll", function() {

            if(scope.isSelected == false){
                var sub = ($($("#budgetListHeight").children()[0]).height() * 2);

                var scrollTop = angular.element(this).scrollTop();
                var offsetHeight = $(angular.element(this)[0])[0].offsetHeight;
                var finalCalculation = scrollTop+offsetHeight;
                var scrollHeight = angular.element(this)[0].scrollHeight-sub;

                if(finalCalculation > scope.finalCalculation){
                    if( scrollHeight < finalCalculation && (scrollHeight+10) > finalCalculation){
                        scope.GetMyBudgetList();
                    }
                }
                scope.finalCalculation = finalCalculation;
                scope.$apply();
            }
        });
    };
});

mainApp.directive('progressbar', [function() {
    return {
        restrict: 'A',
        scope: {
            'progress': '=progressbar'
        },
        controller: function($scope, $element, $attrs) {
            $element.progressbar({
                value: $scope.progress
            })
            $scope.$watch(function() {
                $element.progressbar({value: $scope.progress})
            })
        }
    }
}])

/*** Directive for adding buttons on click that show an alert on click ***/
mainApp.directive("changefloating", function($compile,$timeout){
    return {
        restrict: "A",
        link:  function(scope, element, attrs){
            $timeout(function(){
                var dd = (parseFloat(attrs.subAmount)%1).toFixed(2).split(".");
                if(localStorage.getItem("LanguageKey") == null || localStorage.getItem("LanguageKey") == 'en'){
                    element.html("<sup>.</sup><sup>"+dd[1]+"</sup>");
                } else if(localStorage.getItem("LanguageKey") == 'de'){
                    element.html("<sup>,</sup><sup>"+dd[1]+"</sup>");
                }
            },500);
        }
    }
});

/*** Directive for adding buttons on click that show an alert on click ***/
mainApp.directive("changefloatingbeforedecimal", function($compile,$timeout){
    return {
        restrict: "A",
        link:  function(scope, element, attrs){
            $timeout(function(){
                function numberWith(x, saprator) {
                    var parts = x.toString().split(".");
                    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, saprator);
                    return parts.join(".");
                }
                
                if(localStorage.getItem("LanguageKey") == null || localStorage.getItem("LanguageKey") == 'en'){
                    element.html(numberWith(parseInt(attrs.subAmount), ","));
                    //element.html(numberWith(attrs.subAmount, ","));
                } else if(localStorage.getItem("LanguageKey") == 'de'){
                    element.html(numberWith(parseInt(attrs.subAmount), "."));
                    //element.html(numberWith(attrs.subAmount, "."));
                }
            },500);
        }
    }
});

/*** Make mobile responsve bubble count ***/
mainApp.directive("makeMobileHamburgerMenu", function(){
    return {
        restrict: "E",
        template:  '<div class="float-xs-left"> <a href="javascript:void(0);" data-activates="slide-out" class="button-collapse"><i class="fa fa-bars"></i><p class="number-count-hamburger" ng-if="HomePageCounts.TotalCount > 0"> {{HomePageCounts.TotalCount}} </p> </a> </div>'
    }
});

/*** Binding events on amount input fields ***/
mainApp.directive("bindAmountEvents", function(){
    return {
        restrict : "A",
        require: 'ngModel',
        link: function($scope, $element, $attrs, ctrl) {
            $element.bind("blur", function(e){
                var dd = ctrl.$viewValue;
                if(dd != ""){
                    if(dd.indexOf(".") > -1){
                        if(!checkNumber(dd)){
                            applyScope($scope, $element, $attrs, ctrl, e, dd, ".");
                        }
                    } else if(dd.indexOf(",") > -1){
                        dd = dd.replace(",", ".");
                        if(!checkNumber(dd)){
                            applyScope($scope, $element, $attrs, ctrl, e, dd, ".");
                        }
                    } else {
                        if(!checkNumber(dd)){
                            applyScope($scope, $element, $attrs, ctrl, e, dd, ".");
                        }
                    }

                    function applyScope($scope, $element, $attrs, ctrl, e,  dd, saprator){
                        if(localStorage.getItem("LengKey") == 'en'){
                            ctrl.$setViewValue(makeFloat(dd).replace(saprator, "."));
                            ctrl.$render();
                            e.preventDefault();
                        } else if(localStorage.getItem("LengKey") == 'de'){
                            ctrl.$setViewValue(makeFloat(dd).replace(saprator, ","));
                            ctrl.$render();
                            e.preventDefault();
                        }
                    }

                    function checkNumber(str){
                        return isNaN(str);
                    }

                    function makeFloat(str){
                        return parseFloat(str).toFixed(2);
                    }
                } else {
                    if(localStorage.getItem("LengKey") == 'en'){
                        ctrl.$setViewValue('0.00');
                        ctrl.$render();
                        e.preventDefault();
                    } else if(localStorage.getItem("LengKey") == 'de'){
                        ctrl.$setViewValue('0,00');
                        ctrl.$render();
                        e.preventDefault();
                    }
                }
            });
        }
    }
});

/***
*   Directive to allow and disallow pattrens for form input boxes
**/ 
mainApp.directive('allowPattern', [allowPatternDirective]);

function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function(tElement, tAttrs) {
            return function(scope, element, attrs) {
                // I handle key events
                element.bind("keypress", function(event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.

                    // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                    if(keyCode != 8 && keyCode != 9){
                        if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                            event.preventDefault();
                            return false;
                        } else {
                            /*if(isNaN(keyCodeChar) == true){
                                if(this.id != "useremail"){
                                    var a = this.value ;
                                    if(a.length < 2){
                                        a = a.capitalizeFirstLetter();
                                        this.value = a;
                                    }
                                }
                                if(this.id == "ClientPINCODE"){
                                    var a = this.value ;
                                    a = a.toUpperCase();
                                    this.value = a;
                                }
                            }*/
                        }
                    }
                });
                element.bind("keyup", function(event) {
                    var keyCode = event.which || event.keyCode; // I safely get the keyCode pressed from the event.
                    var keyCodeChar = String.fromCharCode(keyCode); // I determine the char from the keyCode.

                    if(keyCode != 8){
                        // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                        if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                            event.preventDefault();
                            return false;
                        } else {
                            /*if(isNaN(keyCodeChar) == true){
                                if(this.id == "ClientPINCODE" || this.id == "CM_FORPINCODE" || this.id == "CLIENTNEFT1" || this.id == "CLIENTNEFT2" || this.id == "CLIENTNEFT3" || this.id == "CLIENTNEFT4" || this.id == "CLIENTNEFT5" || this.id == "ClientPAN" || this.id == "ClientPAN2" || this.id == "ClientPAN3" || this.id == "ClientGUARDIANPAN"){
                                    var a = this.value ;
                                    a = a.toUpperCase();
                                    this.value = a;
                                }
                            }*/
                        }  
                    }

                });
            };
        }
    };
} 

/*** For limiting text lengeth of input ***/
mainApp.directive("limitTo", [function() {
    return {
        restrict: "A",
        link: function(scope, elem, attrs) {
            var limit = parseInt(attrs.limitTo);
            angular.element(elem).on("keypress", function(e) {
                console.log(attrs);
                if (this.value.length == limit) e.preventDefault();
            });
        }
    }
}]);

/*** trer dropdown directive ***/
mainApp.directive("treeDropdown", ["$document", "$timeout", function($document, $timeout) {
    return {
        restrict:   "E",
        template:   '<div class="dropdown-with-ivhTreeView">' +
                      '<div class="dropDown" ng-show="showDirective == true" ng-click="$broadcast(\'treeDropdown\', { \'case\': \'SH\', event: $event })">' +
                         '{{ (!selectedText || selectedText == "") ? "Please select region and subregion." : selectedText }}' +
                        '<div class="dropDownButton">' +
                          // '<div class="dropDownButtonIcon"></div>' +
                        '</div>' +
                      '</div>' +
                      '<div class="dropDownContent dropDownContentID" id="dropDownContentID" ng-click="$broadcast(\'treeDropdown\', { \'case\': \'stopProp\', event: $event })">' +
                        '<!-- INSERTING ivhTreeView : START -->' +
                        '<input type="text" ng-model="myQuery1" class="searchBox">' +
                        '<div class="ivhTree" ivh-treeview="stuff"' +
                          'ivh-treeview-expand-to-depth="10"' +
                          'ivh-treeview-filter="myQuery1"' +
                          'ivh-treeview-use-checkboxes="true"' +
                          'ivh-treeview-on-cb-change="$broadcast(\'treeDropdown\', { \'case\': \'CB\', event: ivhNode })"' +
                          'style="padding-top: 12px;">' +
                        '</div>' +
                        '<!-- INSERTING ivhTreeView : END -->' +
                      '</div>' +
                    '</div>',
        link: function($scope, elem, attrs) {

            $scope.AssignRegion = [];

            function onClickShowHideIVHDropdown1(e){
                if(attrs.treeItem){
                    $scope.item = JSON.parse(attrs.treeItem);
                    $scope.stuff = $scope.item.stuff;
                }
                if(e.target.classList[0] === "dropDown" && e.target.parentElement.children.length === 2 && e.target.parentElement.children[1].classList[0] === "dropDownContent"){
                    e.target.parentElement.children[1].classList.toggle("show");
                } else if(e.target.classList[0] === "dropDownButton" && e.target.parentElement.parentElement.children.length === 2 && e.target.parentElement.parentElement.children[1].classList[0] === "dropDownContent") {
                    e.target.parentElement.parentElement.children[1].classList.toggle("show");
                } else if(e.target.classList[0] === "dropDownButtonIcon" && e.target.parentElement.parentElement.parentElement.children.length === 2 && e.target.parentElement.parentElement.parentElement.children[1].classList[0] === "dropDownContent") {
                    e.target.parentElement.parentElement.parentElement.children[1].classList.toggle("show");
                }
                var selectedItm = getSelectedFormIVHTreeModel1($scope.stuff);
                e.stopPropagation();
            };

            function onClickShowHideIVHDropdown1Outer(e){
                var indexTree = attrs.treeIndex;
                //indexTree = (($scope.itemsPerPage * ($scope.currentPage-1)) + parseInt(indexTree))
                
                angular.forEach($(".dropDownContentID"), function(item, index){
                    item = $(item);
                    //console.log(index)
                    if(indexTree == index){
                        item.addClass("show");
                    } else {
                        var isClickedElementChildOfPopup = item.hasClass("show");
                        if(isClickedElementChildOfPopup == true){
                            item.toggleClass("show");
                        }
                    }
                });
                if(attrs.treeItem){
                    $scope.item = JSON.parse(attrs.treeItem);
                    $scope.stuff = $scope.item.stuff;
                }
                var selectedItm = getSelectedFormIVHTreeModel1($scope.stuff);
                e.stopPropagation();
            }

            var getSelectedFormIVHTreeModel1 = function(ivhModel){
                var selectedItems = [];
                angular.forEach(ivhModel, function(value){
                    //console.log(value);
                    if(value.selected){
                        selectedItems.push(value.label);
                    }
                    if(angular.isDefined(value.children) && value.children.length > 0)
                    {
                        angular.forEach(getSelectedFormIVHTreeModel1(value.children), function(vle){
                            selectedItems.push(vle);
                        });
                    }
                })
                return selectedItems;
            };

            function changeCallback(node, itemStuff){
                var stuff = $scope.stuff;
                var selectedItm = getSelectedFormIVHTreeModel1(stuff);
                if(selectedItm.length > 0) {
                   $scope.selectedText = selectedItm.join(", ");
                } else {
                  $scope.selectedText = "";
                }

                if(attrs.treeItem){
                    $scope.item.stuff = stuff;
                    
                    attrs.treeItem = JSON.stringify($scope.item);
                    var indexTree = attrs.treeIndex;
                    indexTree = (($scope.itemsPerPage * ($scope.currentPage-1)) + parseInt(indexTree));
                    
                    $scope.allSurvey[parseInt(indexTree)].selectedText = $scope.selectedText;
                    $scope.allSurvey[parseInt(indexTree)].stuff = $scope.stuff;
                }
            }

            function stopProp(e){
                e.stopPropagation();
            }

            function makeRegionChildren (item){
                var tempArray = [];
                angular.forEach(item.GetSubRegion, function(row){
                    tempArray.push({
                        label: row.SubRegionName,
                        id: row.SubRegionId,
                        selected: (row.SubRegionChecked == true) ? true : false
                    });
                });
                return tempArray;
            }

            function makeDefaultSelectedText(){
                angular.forEach($scope.allSurvey, function(itemRow){
                    var stuff = itemRow.stuff;
                    var selectedItm = getSelectedFormIVHTreeModel1(stuff);
                    if(selectedItm.length > 0) {
                        var selectedText = selectedItm.join(", ");
                    } else {
                        var selectedText = "";
                    }
                    itemRow.selectedText = selectedText;
                });
            }

            function makeICHData(data, item){
                var stuff = [];
                angular.forEach(data, function(item){
                    stuff.push({
                        label: item.RegionName,
                        id: item.RegionId,
                        selected: (item.RegionChecked == true) ? true : false,
                        children: makeRegionChildren(item)
                    });
                });

                if(item){
                    item.stuff = stuff;
                    $timeout(function(){
                        makeDefaultSelectedText();
                        if(attrs.treeItem){
                            $scope.showDirective = false;
                        } else {
                            $scope.showDirective = true;
                        }
                    }, 1000 );
                } else {
                    $scope.stuff = stuff;
                    $scope.showDirective = true;
                }
            }

            function makePostParams (data, callback){
                console.log(data);
                angular.forEach(data, function(item){
                    var tempList = [];
                    angular.forEach(item.children, function(innerItem){
                        if(innerItem.selected == true){
                            tempList.push(innerItem.id);
                        }
                    });
                    if(tempList.length > 0){
                        $scope.AssignRegion.push({
                            'RegionId': item.id,
                            'SubRegionId': tempList
                        });
                    }
                });
            }
              
            $document.bind('click', function(event){
                angular.forEach($(".dropDownContentID"), function(item){
                    item = $(item);
                    var isClickedElementChildOfPopup = item.hasClass("show");
                    if(isClickedElementChildOfPopup == true){
                        item.toggleClass("show");
                    }
                });
            });

            $scope.$on('treeDropdown', function(event, data){
               //call directive function here
               switch(data.case){
                    case 'SH':
                        onClickShowHideIVHDropdown1(data.event);
                        break;
                    case 'SHOuter':
                        onClickShowHideIVHDropdown1Outer(data.event);
                        break;
                    case 'CB':
                        changeCallback(data.event);
                        break;
                    case 'stopProp':
                        stopProp(data.event);
                        break;
                    case 'makeData':
                        makeICHData(data.data, data.item);
                        break;
                    case 'postParams':
                        makePostParams(data.data, data.callBack);
                        break;
                }
            })
        }
    }
}]);