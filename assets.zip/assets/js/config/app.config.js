/**
*	Defin all global configuration
***/
mainApp.run(['$rootScope', function ($rootScope) {
    //$rootScope.serviceURL = 'http://111.118.241.110/FleetManagementApi/';
    //$rootScope.serviceURL = 'http://111.118.241.110/FleetManagementV3Api/';
    // $rootScope.serviceURL = 'http://111.118.241.110/UATFOS/';
    $rootScope.serviceURL = 'https://45.114.79.242/fosapi/';
    // $rootScope.serviceURL = 'https://poisplus.in.eww.panasonic.com/fosapi/';
    // $rootScope.serviceURL = 'http://find-coach.com/';
    // $rootScope.serviceURL = 'http://111.118.241.110/FOS/';
    // $rootScope.serviceURL = 'http://18.222.149.95/';
    $rootScope.webpath = 'http://localhost/live/public/';
}]);

mainApp.constant('JS_REQUIRES', {
    //*** Scripts
    scripts: {
        //*** Controllers
        'loginContrller ': 'assets/modules/login/controller/login-controller.js'
    },
    //*** angularJS Modules
    modules: []
});

mainApp.config(['$localStorageProvider',
function ($localStorageProvider) {
    $localStorageProvider.setKeyPrefix('mainApp');
    // console.log($localStorageProvider);
}]);

mainApp.filter('extractAllFirstLatters', function() {
    return function(input) {
        if(input){
            if(input.search(" ") > 0){
                var splitArr = input.split(" ");
                return (!!input) ? splitArr[0].charAt(0).toUpperCase()+splitArr[1].charAt(0).toUpperCase() : '';
            } else {
                return (!!input) ? input.charAt(0).toUpperCase() : '';
            }
        }
    }
});

mainApp.filter('extractAllFirstName', function() {
    return function(input) {
        if(input){
            var splitArr = input.split(" ");
            return (!!input) ? splitArr[0] : '';
        }
    }
});


/*Angular-Loading-Bar
configuration*/
mainApp.config(['cfpLoadingBarProvider',
function (cfpLoadingBarProvider) {
    cfpLoadingBarProvider.includeBar = true;
    cfpLoadingBarProvider.includeSpinner = true;
}]);

mainApp.config(function(ivhTreeviewOptionsProvider) {
    ivhTreeviewOptionsProvider.set({
        defaultSelectedState: false,
        validate: true,
        twistieExpandedTpl: '<span class="arrow-down"></span>',
        twistieCollapsedTpl: '<span class="arrow-right"></span>',
        twistieLeafTpl: '&nbsp;&nbsp;',
    });
});