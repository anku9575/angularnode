/**
*	Including all the dependencies
***/
var mainApp = angular.module('mainApp', [
	'ui.router', 
	'angularUtils.directives.dirPagination',
	'oc.lazyLoad', 
	'ngCookies', 
	'ngStorage', 
	'ngSanitize',
	'angular-loading-bar',
	'ngMaterial', 
	'ngMessages', 
	'angular.filter',
	'md.time.picker',
	'ngMap',
	'mdColorPicker',
	'vAccordion',
	'ivh.treeview',
	'ivh.dropdown',
	'bootstrapLightbox',
	'naif.base64'

]);
