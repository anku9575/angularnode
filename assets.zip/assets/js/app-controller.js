mainApp.controller('mainController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "appMethods", "$localStorage", "$timeout", "$window", "$state", "$sessionStorage", "$compile", "$window", "$interval", function($scope, $rootScope, $http, $location, appAlerts, appMethods, $localStorage, $timeout, $window, $state, $sessionStorage, $compile, $window, $interval){
    
    var dynamics = $('#dynamics');
    $scope.$watch(function() {
        angular.element(dynamics.html('.pagination>.page-item.active>a, .pagination>.page-item.active>a:focus, .pagination>.page-item.active>a:hover, .pagination>.page-item.active>span, .pagination>.page-item.active>span:focus, .pagination>.page-item.active>span:hover {background-color: ' + $localStorage.sideBarColor + '; border-color: #9c27b0; color: #fff; box-shadow: 0 4px 5px 0 rgba(156, 39, 176, .14), 0 1px 10px 0 rgba(156, 39, 176, .12), 0 2px 4px -1px rgba(156, 39, 176, .2);}'));
        $compile(dynamics.contents())($scope);
    });

    if($localStorage.titleColor && $localStorage.sideBarColor && $localStorage.changeBackground && $localStorage.sideBarImage){
        $rootScope.titleColor = $localStorage.titleColor;
        $rootScope.sideBarColor = $localStorage.sideBarColor
        $rootScope.changeBackground = $localStorage.changeBackground
        $rootScope.sideBarImage = $localStorage.sideBarImage
    } else {
        $localStorage.titleColor = "success"
        $rootScope.titleColor = $localStorage.titleColor;

        $localStorage.sideBarColor = "#4caf50"
        $rootScope.sideBarColor = $localStorage.sideBarColor;

        $localStorage.changeBackground = "black"
        $rootScope.changeBackground = $localStorage.changeBackground
    
        $localStorage.sideBarImage = "3"
        $rootScope.sideBarImage = $localStorage.sideBarImage
    }

    $scope.colorPicker = function(Color, sideBarColor){
        if(Color != undefined || Color != null || sideBarColor != undefined || sideBarColor != null){
            $localStorage.titleColor = Color;
            $rootScope.titleColor = $localStorage.titleColor;
            
            $localStorage.sideBarColor = sideBarColor;
            $rootScope.sideBarColor = $localStorage.sideBarColor;
        }
    }

    $scope.sideBarBackground = function(bColor){
        $localStorage.changeBackground = bColor
        $rootScope.changeBackground = $localStorage.changeBackground
    }

    $scope.sideBarImageChange = function(imageName){
        $localStorage.sideBarImage = imageName
        $rootScope.sideBarImage = $localStorage.sideBarImage
        $window.location.reload()
    }

	$scope.countResetDevice = function(){
        $scope.countData = []
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserDetail").then(function(response) {
            $scope.UserDetail = response.data.GetUserDetail;
            for(var i = 0; i < $scope.UserDetail.length; i++){
                if($scope.UserDetail[i].DeviceReset == true){
                    $scope.countData.push($scope.UserDetail[i])
                }
            }
            $scope.resetDeviceCount = $scope.countData.length;
        })        
    }
    $scope.countResetDevice();

    $scope.topInfo = function(){
        if($localStorage.userData){
            $scope.UserName = $localStorage.userData.UserName;
        	$scope.LastLoginDate = $localStorage.userData.LastLoginDate;
        }
    }
    $scope.topInfo();

    $scope.myOrderBy = 'UserName';
    $scope.reverse = false;
    $scope.orderByMe = function(col){
        $scope.myOrderBy = col;
        if($scope.reverse){
            $scope.reverse = false;
            // $scope.reverseclass = 'arrow-up';
        } else {
            $scope.reverse = true;
            // $scope.reverseclass = 'arrow-down';
        }
    } 

    $scope.sortClass = function(col){
        if($scope.myOrderBy == col ){
            if($scope.reverse){
                // return 'arrow-down'; 
            } else {
                // return 'arrow-up';
            }
        } else {
            return '';
        }
    }

    $scope.showNotification = function(from, align, ErrorMessage){
        color = Math.floor((Math.random() * 4) + 1);
        $.notify({
            icon:"notifications",
            message: ErrorMessage
        },{
            type: type[color],
            timer: 1000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    /* logout all modules */
	$scope.logout = function(){
        swal({
            title: 'Are you sure?',
            text: "want to logout from Feet On Street !",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, log me out!',
            cancelButtonText: 'Not now !',
            confirmButtonClass: "btn btn-success",
            cancelButtonClass: "btn btn-danger",
            reverseButtons: true,
            buttonsStyling: false
        }).then(function() {
            swal({
                title: 'Logged Out',
                text: 'Successfully logout :)',
                type: 'success',
                confirmButtonClass: "btn btn-success",
                allowOutsideClick: false,
                buttonsStyling: false
            }).catch(swal.noop)
            $timeout(function(){
                delete $localStorage.userData;
                delete $localStorage.AccessToken;
                // $location.path("https://45.114.79.242/QAgenericComponent");
                window.location.href = "https://45.114.79.242/QAgenericComponent";
            }, 100);
        }, function(dismiss) {
            // dismiss can be 'overlay', 'cancel', 'close', 'esc', 'timer'
            if (dismiss === 'cancel') {
                swal({
                    title: 'Continue &',
                    text: 'Enjoy your ride :)',
                    type: 'success',
                    confirmButtonClass: "btn btn-info",
                    buttonsStyling: false
                }).catch(swal.noop)
            }
        })
    }

    $scope.toggleMenu = function(toggleMenu){
        if(toggleMenu == undefined){
            var url = $window.location.href
            var href = url.split("/");
            if(href.indexOf("concernSearch") > -1){
                $scope.lastElement = "concern";
            } else if(href.indexOf("surveySearch") > -1){
                $scope.lastElement = "survey"
            } else if(href.indexOf("concern") > -1){
                $scope.lastElement = "concern";
            } else if(href.indexOf("userRole") > -1){
                $scope.lastElement = "userRole";
            } else {
                $scope.lastElement = href[href.length - 1];
            }
        }else if(toggleMenu == 'javascript:void(0)'){
            // alert(0)
        } else {
            $scope.lastElement = toggleMenu;
        }

        if($scope.lastElement == "user" || $scope.lastElement == "resetDevice" || $scope.lastElement == "userRole"){
            setTimeout(function() {
                $('#Users').collapse('show');
            }, 1000);
        }else if($scope.lastElement == "teams" || $scope.lastElement == "myTour"){
            setTimeout(function() {
                $('#Team').collapse('show');
            }, 1000);
        }else if($scope.lastElement == "survey" || $scope.lastElement == "addSurvey"){
            setTimeout(function() {
                $('#Survey').collapse('show');
            }, 1000);
        }else if($scope.lastElement == "role" || $scope.lastElement == "addRole"){
            setTimeout(function() {
                $('#Roles').collapse('show');
            }, 1000);
        }
    }
    $interval(function(){
        $scope.toggleMenu()
    }, 1000)

    /*if($scope.lastElement == "user" || $scope.lastElement == "resetDevice" || $scope.lastElement == "userRole"){
        setTimeout(function() {
            $('#Users').collapse('show');
        }, 1000);
    }else if($scope.lastElement == "teams" || $scope.lastElement == "myTour"){
        setTimeout(function() {
            $('#Team').collapse('show');
        }, 1000);
    }else if($scope.lastElement == "survey" || $scope.lastElement == "addSurvey"){
        setTimeout(function() {
            $('#Survey').collapse('show');
        }, 1000);
    }else if($scope.lastElement == "role" || $scope.lastElement == "addRole"){
        setTimeout(function() {
            $('#Roles').collapse('show');
        }, 1000);
    }else{
        setTimeout(function() {
            $('#Users').collapse('hide');
            $('#Team').collapse('hide');
            $('#Survey').collapse('hide');
            $('#Roles').collapse('hide');
        }, 2000);
    }*/
}]);