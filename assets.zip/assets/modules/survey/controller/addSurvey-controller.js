/**
* Purpose – For adding survey.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('addSurveyController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state", "$document",  function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state, $document) {
    
    $('html').removeClass('nav-open');
    $scope.questions = [];
    $scope.date = {
        today: new Date(),
        minDate: new Date(),
        maxDate: new Date()
    }

    $scope.AddSurveyQues = [
        {
            'Question':'',
            'IsActive': '',
            'yes': '',
            'no': '',
            'dontknow': '',
            'options' : "",
            'ExtraOptionName': []
        }
    ];

    /**
    *   adding a new row questions and parameters.
    ***/
    $scope.addNew = function(){
        console.log($scope.AddSurveyQues);
        $scope.AddSurveyQues.push({ 
            'Question':'',
            'IsActive': '',
            'yes': '',
            'no': '',
            'dontknow': '',
            'options' : "",
            'ExtraOptionName': []
        });
    };

    /**
    *   deleting a row of questions and parameters.
    ***/
    $scope.delete = function(index){
        $scope.AddSurveyQues.splice(index, 1)
    }

    $scope.addOptions = function(row, index){
        row.queExtraOptions = true;
        row.ExtraOptionsButton = false
        row.options = [];
    }

    $scope.broadcastDirective = function(event, data){
        $scope.$broadcast(event, data);
    }

    //Showing Roles on add survey
    $scope.roles = function(){
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            $scope.role = response.data.GetRoleRights;
        });
    }
    $scope.roles();

    /**
    *   getting role ids from before creating survey.
    ***/
    $scope.id = [];
    $scope.RoleIds = [];
    // Getting RoleId on add survey
    $scope.change = function(roles){
        $scope.RoleIds = roles.map(Number).filter(Number);
    }

    /**
    *   showing region and sub region on select box on add survey page.
    ***/
    $scope.regionSubRegion = function(){
        $scope.filterRegions = []
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
            $scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.filterRegions.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
            // var GetRegionWithSubRegion = response.data.GetRegionWithSubRegion;
            var GetRegionWithSubRegion = $scope.filterRegions;

            $scope.$broadcast('treeDropdown', { 'case': 'makeData', 'data': GetRegionWithSubRegion })
        });
    }
    $scope.regionSubRegion();

    /**
    *   getting region ids before creating survey.
    ***/
    $scope.RegionIds = '';
    $scope.SubRegions = [];
    $scope.subRegionData = function(data){
        $scope.RegionIds = data.RegionId;
        $scope.SubRegions = data.GetSubRegion;
    }

    /**
    *   getting sub region ids before creating survey.
    ***/
    $scope.subId = [];
    $scope.subRegionIds = [];
    $scope.changeSubRegion = function(SubRegionData){
        $scope.subRegionIds = SubRegionData.map(Number).filter(Number);
    }

    /**
    *   showing preview of questions and parameters.
    ***/
    $scope.formData = {};
    $scope.formData.IsActive = false;
    $scope.extraOptions = [];
    $scope.previewData = function(isValid){
        if(isValid){
            console.log("$scope.AddSurveyQues");
            console.log($scope.AddSurveyQues);
            if($scope.AddSurveyQues){
                for(i = 0; i < $scope.AddSurveyQues.length; i++){
                    if($scope.AddSurveyQues[i].yes != true && $scope.AddSurveyQues[i].no != true && $scope.AddSurveyQues[i].dontknow != true && $scope.AddSurveyQues[i].options.length == 0){
                        var count = i+1;
                        $scope.showNotification(from = 'bottom', align='right', 'Please Select atleast 1 option or 1 extra options for question '+ count +'.');
                        return false;
                    }
                }
            }
            //return false;
            for(var i = 0; i < $scope.AddSurveyQues.length; i++){
                if($scope.AddSurveyQues[i].yes == true){
                    $scope.AddSurveyQues[i].yes = "Yes"
                } else if($scope.AddSurveyQues[i].yes == false || $scope.AddSurveyQues[i].yes == ""){
                    $scope.AddSurveyQues[i].yes = ""
                }

                if($scope.AddSurveyQues[i].no == true){
                    $scope.AddSurveyQues[i].no = "No"
                } else if($scope.AddSurveyQues[i].no == false || $scope.AddSurveyQues[i].no == ""){
                    $scope.AddSurveyQues[i].no = ""
                }

                if($scope.AddSurveyQues[i].dontknow == true){
                    $scope.AddSurveyQues[i].dontknow = "Don't Know"
                } else if($scope.AddSurveyQues[i].dontknow == false || $scope.AddSurveyQues[i].dontknow == ""){
                    $scope.AddSurveyQues[i].dontknow = ""
                }
            }
            
            for(var j = 0; j < $scope.AddSurveyQues.length; j++){
                $scope.AddSurveyQues[j].optionss = [];
                $scope.AddSurveyQues[j].ExtraOptionName = [];
                if($scope.AddSurveyQues[j].options.length > 0){
                    console.log("$scope.AddSurveyQues[j].options")
                    console.log($scope.AddSurveyQues[j].options)
                    $scope.AddSurveyQues[j].optionss = $scope.AddSurveyQues[j].options.join(", ");
                }
                    if($scope.AddSurveyQues[j].optionss.length > 0){
                        $scope.AddSurveyQues[j].ExtraOptionName = $scope.AddSurveyQues[j].optionss.split(',');
                        console.log("ssplit")
                        console.log($scope.AddSurveyQues[j].ExtraOptionName)
                    }
                    $scope.AddSurveyQues[j].ExtraOptionName.push($scope.AddSurveyQues[j].yes, $scope.AddSurveyQues[j].no, $scope.AddSurveyQues[j].dontknow)
                    $scope.AddSurveyQues[j].ExtraOptionName = $scope.AddSurveyQues[j].ExtraOptionName.filter(Boolean)
                    $.each($scope.AddSurveyQues[j].ExtraOptionName, function(i, el){
                    if($.inArray(el, $scope.AddSurveyQues[j].ExtraOptionName) === -1){
                        $scope.AddSurveyQues[j].ExtraOptionName.push(el);
                    } 
                });
            } 
            console.log("perfect")

            $scope.formData.RoleId = $scope.RoleIds;
            $scope.formData.AddSurveyQues = $scope.AddSurveyQues;
            $scope.formData.AssignRegion = $scope.AssignRegion;
            $scope.formData.StartDate = moment($scope.formData.StartDate).format('YYYY/MM/DD');  
            $scope.formData.EndDate = moment($scope.formData.EndDate).format('YYYY/MM/DD');  
            $('#previewModal').modal({backdrop: 'static', keyboard: false});
            /*console.log("JSON.stringify($scope.formData)");
            console.log($scope.formData);
            return false
            $http.post($rootScope.serviceURL+"api/FleetManagement/AddSurvey", $scope.formData).then(function(response){
            var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $location.path('survey');
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                }
            }).catch(function(error){
                console.log(error);
            });*/
        } else {
            $scope.submitted = true;
        }
    }

    /**
    *   closing preview pop up and putting parameters value.
    ***/
    $scope.closePreview = function(){
        for(var p = 0; p < $scope.AddSurveyQues.length; p++){
            if($scope.formData.AddSurveyQues[p].yes == "Yes"){
                $scope.formData.AddSurveyQues[p].yes = true
            } else {
                $scope.formData.AddSurveyQues[p].yes = false
            }

            if($scope.formData.AddSurveyQues[p].no == "No"){
                $scope.formData.AddSurveyQues[p].no = true
            } else {
                $scope.formData.AddSurveyQues[p].no = false
            }

            if($scope.formData.AddSurveyQues[p].dontknow == "Don't Know"){
                $scope.formData.AddSurveyQues[p].dontknow = true
            } else {
                $scope.formData.AddSurveyQues[p].dontknow = false
            }
        }    
        console.log("$scope.formData");
        console.log($scope.formData);
    }

    /**
    *   creating a survey from add survey page.
    ***/
    $scope.saveSurvey = function(){
        $scope.$broadcast('treeDropdown', { 'case': 'postParams', 'data': $scope.stuff, 'callBack' : [] })
        console.log($scope.formData);

        $http.post($rootScope.serviceURL+"api/FleetManagement/AddSurvey", $scope.formData).then(function(response){
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $location.path('app/survey');
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                //$state.reload();
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    /**
    *   showing status notification while posting data in DB.
    ***/
    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);