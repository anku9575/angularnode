/**
* Purpose – For showing survey and updating survey region and sub regions.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('surveyController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "NgMap" , "$state", "$anchorScroll", "$compile", "$stateParams", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, NgMap, $state, $anchorScroll, $compile, $stateParams) {
    
    $('html').removeClass('nav-open');
    $scope.redirect = function(url){
        $location.path(url);
    }

    NgMap.getMap().then(function(map) {
        $scope.map = map;
        $timeout(() => {google.maps.event.trigger(map, 'resize')}, 1000)
    });

    var map = this;

    $scope.roleFilter = function(){
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            return $scope.filterRoles = response.data.GetRoleRights;
        });
    }
    $scope.roleFilter();
    
    /**
    *   showing region and sub region on select box on concerns page for filter.
    ***/
    $scope.regionFilter = function(){
        $scope.filterRegions = []
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
            // $scope.filterRegions = response.data.GetRegionWithSubRegion;
            $scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.filterRegions.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
            return $scope.filterRegions
        }).then(function(){
            $scope.GetAllSurvey();
        });
    }
    
    
    $scope.RegionData = {}
    $scope.subRegionFilter = function(RegionId, GetSubRegion){
        $scope.RegionIds = RegionId;
        $scope.fSubRegion = GetSubRegion;
    }

    $scope.dashboardTrue
    $scope.filterUser = function(value){
        $scope.dashboardTrue = value
        $scope.GetAllSurvey();
    }

    /**
    *  Showing all survey on survey page
    ***/
    $scope.GetAllSurvey = function(){
        if($scope.dashboardTrue != false){
            if($stateParams.FromDashboardScreen){
                $scope.FromDashboardScreen = true
            }
        } else {
            $scope.FromDashboardScreen = false
        }
        console.log($scope.FromDashboardScreen)
       // return false
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetAllSurvey", {
            RegionId : ($stateParams.id)?$stateParams.id:$scope.RegionIds,   
            SubRegionId : $scope.SubRegionId,
            RoleId : $scope.RoleId,
            FromDashboardScreen : $scope.FromDashboardScreen,
            UserId : 0,
        }).then(function(response){
            var allSurvey = response.data.GetAllSurvey;

            angular.forEach(allSurvey, function(item){
                var filterRoles = angular.copy($scope.filterRoles);
                item.RoleModelTemp = [];
                angular.forEach(item.RoleModel, function(itemRoleModelItem){
                    item.RoleModelTemp.push(itemRoleModelItem.RoleId);
                });
                angular.forEach(filterRoles, function(filterRolesItem){
                    if(item.RoleModelTemp.indexOf(filterRolesItem.RoleId) > -1){
                        filterRolesItem.RoleChecked = true;
                    } else {
                        filterRolesItem.RoleChecked = false;
                    }
                    delete filterRolesItem.GetRights;
                });
                delete item.RoleModelTemp;
                item.RoleModel = filterRoles;

                var filterRegions = angular.copy($scope.filterRegions);
                angular.forEach(filterRegions, function(regionItem){
                    if(item.RegionIds.indexOf(regionItem.RegionId) > -1){
                        regionItem.RegionChecked = true;
                    } else {
                        regionItem.RegionChecked = false;
                    }
                    angular.forEach(regionItem.GetSubRegion, function(getSubRegionItem){
                        if(item.SubRegionIds.indexOf(getSubRegionItem.SubRegionId) > -1){
                            getSubRegionItem.SubRegionChecked = true;
                        } else {
                            getSubRegionItem.SubRegionChecked = false;
                        }
                        delete getSubRegionItem.GetBranch;
                    });
                });
                item.RegionWithSubRegion = filterRegions;

                // console.log("item.RegionWithSubRegion", item.RegionWithSubRegion);

                item.RegionId = [];
                item.SubRegionId = [];
                item.RoleId = [];

                setTimeout(function() {
                    $scope.$broadcast('treeDropdown', { 'case': 'makeData', 'data': item.RegionWithSubRegion, 'item':  item})
                }, 100);
                
                angular.forEach(item.RegionWithSubRegion, function(region){
                    if(region.RegionChecked == true){
                        if(region.RegionId){
                            if(item.RegionId.indexOf(region.RegionId) == -1){
                                item.RegionId.push(region.RegionId);
                                $scope.assignRegionId(region.RegionId, region.GetSubRegion, item);

                                angular.forEach(region.GetSubRegion, function(subRegion){
                                    if(subRegion.SubRegionChecked == true){
                                        item.SubRegionId.push(subRegion.SubRegionId);
                                    }
                                });
                            }
                        }
                    }
                });

                angular.forEach(item.RoleModel, function(role){
                    if(role.RoleChecked == true){
                        item.RoleId.push(role.RoleId);
                    }
                });
            });

            
            $scope.allSurvey = allSurvey;
        });
    }

    /**
    *   close pop up of survey result and populating all survey again.
    ***/
    $scope.dismiss = function(){
        //$state.reload();
        //$scope.GetAllSurvey();
        $scope.RegionId = 0
        $scope.SubRegionId = 0
        $scope.RoleId = 0

    }

    /**
    *   Showing all survey on survey page
    ***/
    $scope.surveyId;
    $scope.points = [];
    $scope.msg = '';
    $scope.GetSurveyResult = function(SurveyId){
        $scope.surveyId = SurveyId
        var surveyData = {
          "SurveyId": SurveyId,
          "RegionId": 0,
          "SubRegionId": 0,
          "RoleId": 0
        }
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetSurveyResult", surveyData).then(function(response){
            $scope.renders = true;
            $scope.SurveyResult = response.data.GetSurveyResult;
            $scope.points = $scope.SurveyResult[0].SurveyPlace;
            console.log($scope.SurveyResult)
            //console.log($scope.points)
            
        });
    }

    $scope.showPieChart = function(Option, index){
        //alert(index)
        //console.log(Option)
        $scope.attempt = 0
        $scope.array = [['Task', 'Hours per Day']]
        for(var i = 0; i < Option.length; i++){
            var Opt = Option[i].Option
            var OptionValue = Option[i].OptionValue
            $scope.attempt += Option[i].OptionValue
            $scope.array.push([Opt, OptionValue])
        }
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(pieRegion);

        function pieRegion() {

            var data = google.visualization.arrayToDataTable($scope.array);

            var options = {
                title: '',
                pieSliceText: 'value',
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'+index));
            chart.draw(data, options);
            
            // google.visualization.events.addListener(chart, 'click', clickHandlerRegionForSurvey);
        }
    }   

    $scope.GetSurveyResultFilter = function(){
        var surveyData = {
          "SurveyId": $scope.surveyId,
          "RegionId": $scope.RegionId,
          "SubRegionId": $scope.SubRegionId,
          "RoleId": $scope.RoleId
        }
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetSurveyResult", surveyData).then(function(response){
            $scope.renders = true;
            $scope.SurveyResult = response.data.GetSurveyResult;
            $scope.points = $scope.SurveyResult[0].SurveyPlace;
            console.log($scope.SurveyResult)
            //console.log($scope.points)
            
        });
    }

    /**
    *   getting region ids from survey page to assign.
    ***/
    $scope.AssignRegionId = [];
    $scope.assignRegionId = function(RegionId, GetSubRegion, survey){
        survey.AssignRegionId = RegionId;
        if(survey.ASubRegion == undefined || survey.ASubRegion.length == 0){
            survey.SubRegionId = [];
            survey.ASubRegion = [];
            angular.forEach(GetSubRegion, function(item){
                item.RegionId = RegionId;
                survey.ASubRegion.push(item);
            });
        } else {
            angular.forEach(GetSubRegion, function(item){
                item.RegionId = RegionId;
                survey.ASubRegion.push(item);
            });
        }
    }

    /**
    *   getting sub region ids from survey page to assign.
    ***/
    $scope.AssignSubRegionId = [];
    $scope.assignSubRegion = function(assignSubRegionId, survey){
        console.log(assignSubRegionId);
    }

    /*
    *   getting role ids from survey page to assign
    ***/
    $scope.AssignRoleId = [];
    $scope.assignRole = function(assignRoleId){
        //$scope.AssignRoleId = assignRoleId.map(Number).filter(Number)
    }

    /**
    *   assign survey 
    ***/
    $scope.currentPage = 1;
    $scope.itemsPerPage = 10;
    $scope.Assign = {};
    $scope.Assign.IsActive = false;
    $scope.assignSurvey = function(surveyId, survey){

        console.log($scope.stuff);
        console.log(survey);
        
        $scope.AssignRegion = [];
        angular.forEach(survey.stuff, function(item){
            var tempList = [];
            angular.forEach(item.children, function(innerItem){
                if(innerItem.selected == true){
                    tempList.push(innerItem.id);
                }
            });
            if(tempList.length > 0){
                $scope.AssignRegion.push({
                    'RegionId': item.id,
                    'SubRegionId': tempList
                });
            }
        });
        
        /* angular.forEach(survey.RegionWithSubRegion, function(item){
            var tempList = [];
            if(item.RegionChecked == true){
                angular.forEach(item.GetSubRegion, function(innerItem){
                    if(innerItem.RegionId == item.RegionId){
                        if(innerItem.SubRegionChecked == true){
                            tempList.push(innerItem.SubRegionId);
                        }
                    }
                });
            }

            if(tempList.length > 0){
                $scope.AssignRegion.push({
                    'RegionId': item.RegionId,
                    'SubRegionId': tempList
                });
            }
        });*/

        var sendData = {
            "SurveyId": survey.SurveyId,
            "IsActive": survey.IsActive,
            "RoleId": survey.RoleId,
            "AssignRegion": $scope.AssignRegion
        }

        console.log("sendData")
        console.log(sendData)
    
        $http.post($rootScope.serviceURL+"api/FleetManagement/AssignSurvey", sendData).then(function(response){
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.GetAllSurvey();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.GetAllSurvey();UserId
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    $scope.gotoTop = function() {
         // $location.hash('top');
         // $anchorScroll();
         // $(window).scrollTop(0)
        var obj = $('html').scrollTop() !== 0 ? 'html' : 'body';
        $(obj).animate({ scrollTop: 0 }, "slow");
    };

    $scope.init = function(){
        if($stateParams.type){
            // alert("if")
            $scope.regionFilter().then(function(){
                $scope.roleFilter().then(function(){
                    console.log($scope.filterRegions);
                    angular.forEach($scope.filterRegions, function(item){
                        console.log(item)
                        if(item.RegionId == $stateParams.id){
                            $scope.RegionId = item.RegionId;
                            $scope.RegionData = item.GetSubRegion;
                            $scope.subRegionFilter($scope.RegionId, $scope.RegionData);
                        }
                    })
                })
            })
            $scope.GetAllSurvey()
        } else {
            // alert("else")
            $scope.roleFilter();
            $scope.regionFilter();
        }
    }    
    $scope.init();

}]);