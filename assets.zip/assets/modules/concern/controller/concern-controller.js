/**
* Purpose – showing concerns.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('concernController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "NgMap", "$stateParams", "Lightbox", "$compile", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, NgMap, $stateParams, Lightbox, $compile) {
    
    /**
    * declare variables
    **/
    $('html').removeClass('nav-open');
    
    NgMap.getMap().then(function(map) {
        $scope.map = map;
        $timeout(() => {google.maps.event.trigger(map, 'resize')}, 1000)
    });

    $scope.date = {
        today: new Date(),
        minDate: new Date(),
        maxDate: new Date()
    }
    var map = this;
    $scope.filterGo = true


    /**
    * redirection from one state to another state
    **/
    $scope.redirect = function(url){
        $location.path(url);
    }

    /**
    * showing roles in filters
    **/
    $scope.roleFilter = function(){
        $scope.filterRoles = [];
        /*return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            $scope.filterRoles = response.data.GetRoleRights;
            return $scope.filterRoles;
        });*/
        return $http.post($rootScope.serviceURL+"api/FleetManagement/GetRoleWithUnderRole", {"RoleId": $localStorage.userData.RoleId}).then(function(response){
            return $scope.filterRoles = response.data.GetRoleWithUnderRoleModel
        })
    }

    /**
    *   showing region and sub region on select box on concerns page for filter.
    ***/
    $scope.regionFilter = function(){
        $scope.filterRegions = [];
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
            // $scope.filterRegions = response.data.GetRegionWithSubRegion;
            $scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.filterRegions.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
            return $scope.filterRegions;
        });
    }


    /**
    * showing sub regions in filters
    **/
    $scope.RegionData = {}
    $scope.subRegionFilter = function(data){
        $scope.filterGo = false
        $scope.RegionData = data;
        $scope.fSubRegion = data.GetSubRegion;
    }


    /**
    * showing branch in filters
    **/
    $scope.branchFilter = function(branch){
        $scope.filterGo = false
        $scope.fBranch = branch.GetBranch
        console.log("$scope.fBranch")
        console.log($scope.fBranch)
    }

    /**
    * showing save button when changes in data
    **/
    $scope.rolefilterGo = function(){
        $scope.filterGo = false
    }

    /**
    * showing concerns
    **/
    $scope.getConcerns = function(isLoad){
        $scope.concerns = [];
        $scope.concernFilter = {};
        if(isLoad == true){
            $scope.fromFilterDate = null;
            $scope.toFilterDate = null;
        } else {
            if($scope.fromDate == undefined || $scope.toDate == undefined){
                $scope.fromFilterDate = null;
                $scope.toFilterDate = null;
            } else {
                $scope.fromFilterDate = moment($scope.fromDate).format('YYYY/MM/DD');
                $scope.toFilterDate = moment($scope.toDate).format('YYYY/MM/DD');
            }
        }
        $scope.concernFilter = 
            {
                RegionId : $scope.RegionData.RegionId,   
                SubRegionId : $scope.SubRegionId,
                RoleId : $scope.RoleId,
                BranchId : $scope.BranchId,
                UserId : ($stateParams.userId) ? $stateParams.userId : 0,
                ActiveFrom : $scope.fromFilterDate,
                ActiveTill : $scope.toFilterDate
            }
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetConcerns", $scope.concernFilter).then(function(response){
            $scope.concerns = response.data.GetUserWiseConcerns;
        });
    }

    $scope.dismiss = function(){
        //$route.reload();
        //$scope.getConcerns();
        $scope.modelOpen = false;
        $scope.ScheduleDateWise = undefined;
    }

    /**
    * showing tour schedule
    **/
    $scope.route = [];
    $scope.concernData = {};
    $scope.imgURL = [];
    $scope.img = [];
    $scope.modelOpen = false;
    $scope.userIdForSurvey
    //$scope.pos = [];
    $scope.scheduleDW = function(UserId, ScheduleId, tourName){
        $scope.tourName = tourName;
        $scope.modelOpen = true;

        $scope.concernData.UserId = UserId;
        $scope.concernData.ScheduleId = ScheduleId;
        $http.post($rootScope.serviceURL+"api/FleetManagement/ConcernsView", $scope.concernData).then(function(response){
            console.log(response);
            $scope.render = true;
            $scope.route = [];
            $scope.concernDetail = response.data;
            $scope.userIdForSurvey = $scope.concernDetail.UserId;
            var ScheduleDateWise = $scope.concernDetail.ScheduleDateWise;
            

            angular.forEach(ScheduleDateWise, function(row){
                row.route = [];
                row.img = [];
                angular.forEach(row.GetSchedule, function(item){
                    item.img = [];
                    $scope.SubDealerName = item.SubDealerName;
                    //$scope.imgURL = item.ImagePath;
                    $scope.imgURL = item.ScheduleDetailUploadImage;


                    row.route.push({ 
                        title: item.SubDealerName, 
                        pos : [ item.Latitude , item.Longitude], 
                        onRoute: true
                    });

                    /*for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].replace(/\\/g, "/");
                        item.img.push({url:$scope.i});
                    }*/
                    for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].UploadImage;
                        $scope.iDate = $scope.imgURL[k].Snapdate;
                        item.img.push({url:$scope.i, snapDate: $scope.iDate});
                    }
                });

                if(row.route.length > 1 ){
                    row.start = row.route[0];
                    row.theWaypoints = [];
                    if(row.route.length > 1 ){
                        for (var i = 1; i < row.route.length - 1; i++ ){
                            var obj = {
                                location:{
                                    lat: parseFloat(row.route[i].pos[0]),
                                    lng: parseFloat(row.route[i].pos[1])
                                },
                                stopover: true
                            };
                            row.theWaypoints.push(obj);
                        }
                    }
                    row.end = row.route[row.route.length-1];
                } else {
                    row.start = {};
                    row.end = {};
                }
            });
            //console.log(ScheduleDateWise);

            $scope.ScheduleDateWise = ScheduleDateWise;

            $timeout(function(){
                NgMap.getMap().then(function(map) {
                    google.maps.event.trigger(map, 'resize');
                });
            }, 2000);
        });
    } 

    /**
    * showing finish address on map of a location
    **/
    $scope.wrongRouteDistance = function(addressName, lat, long, wrongLat, wrongLong){
        $('#mySidenav').width('100%');
        $scope.wrongRoute = [];
        $scope.addressName = addressName;
        $scope.Latitude = lat 
        $scope.Longitude = long
        $scope.wlat = wrongLat
        $scope.wlong = wrongLong

        $timeout(function(){
            NgMap.getMap().then(function(map) {
                google.maps.event.trigger(map, 'resize');
                $scope.wrongRoute.push({ title: $scope.addressName, pos : [ $scope.Latitude, $scope.Longitude], onRoute: true }, { title: "Finish Address", pos : [ $scope.wlat, $scope.wlong], onRoute: true });
            });
        }, 1000);
    }

    $scope.wrongstart = {};
    $scope.wrongtheWaypoints = [];
    $scope.wrongend = {};
    
    $scope.$watchCollection('wrongRoute', function () {
        if($scope.wrongRoute.length > 1 ){
            $scope.wrongstart = $scope.wrongRoute[0];
            $scope.wrongtheWaypoints = [];
            if($scope.wrongRoute.length > 1 ){
                for (var i = 1; i < $scope.wrongRoute.length - 1; i++ ){
                var obj = {
                    location:{
                        lat: $scope.wrongRoute[i].pos[0],
                        lng: $scope.wrongRoute[i].pos[1]
                    },
                    stopover: true
                };
                $scope.wrongtheWaypoints.push(obj);
            }
        }
            $scope.wrongend = $scope.wrongRoute[$scope.wrongRoute.length-1];
        } else {
            $scope.wrongstart = {};
            $scope.wrongend = {};
        }
    });

    $scope.ApproveRaise = function(ScheduleDetailId, ApproveRaise){
        $scope.ar = {};
        $scope.ar.ScheduleDetailId = ScheduleDetailId;
        $scope.ar.ApproveRaise = ApproveRaise;
            console.log($scope.ar.ScheduleDetailId);
            console.log($scope.ar.ApproveRaise);
        $http.post($rootScope.serviceURL+"api/FleetManagement/ApproveRaise", $scope.ar).then(function(response){
            console.log(response);
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    /**
    * showing noification
    **/
    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    /**
    * showing concerns from dashboard
    **/
    $scope.concerns = [];
    $scope.getAllConcerns = function(){
        if($stateParams.userId){
            var postParams = {
                UserId : $stateParams.userId
            }
        } else {
            var postParams = {}
        }

        $http.post($rootScope.serviceURL+"api/FleetManagement/GetConcerns", postParams).then(function(response){
            $scope.concerns = response.data.GetUserWiseConcerns;
        }).then(function(){
            $scope.regionFilter();
        }).then(function(){
            $scope.roleFilter();
        });
    }

    $scope.init = function(){
        if($stateParams.type){
            $scope.regionFilter().then(function(){
                $scope.roleFilter().then(function(){
                    if($stateParams.type == 1){
                        angular.forEach($scope.filterRoles, function(item){
                            if(item.RoleId == $stateParams.id){
                                $scope.RoleId = item.RoleId;
                                $scope.RoleName = item.RoleName;
                            }
                        })
                    } else if($stateParams.type == 2) {
                        angular.forEach($scope.filterRegions, function(item){
                            if(item.RegionId == $stateParams.id){
                                $scope.RegionId = item;
                                $scope.RegionData = item;
                                $scope.subRegionFilter(item);
                            }
                        })
                    }
                    $scope.getConcerns(true);
                });
            });
        } else {
            $scope.getAllConcerns();
        }
    }

    /**
    * showing survey summary
    **/
    $scope.getSurvey = function(date, scheculeId){
        $('#rightSideNav').width('100%');
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetLocationWiseSurvey", {
            "UserId": $scope.userIdForSurvey,
            "ScheduleDate": date,
            "ScheduleDetailId": scheculeId,
            "Creator": 4,
            "Modifier": 5
        }).then(function(response){
            console.log(response)
            $scope.surveyModel = response.data.GetsurveyModel
        })
    }

    $scope.init();

    /**
    * showing tour images
    **/
    $scope.openLightboxModal = function (scheduleData) {
        $('#leftNavImages').width('100%');
        $scope.surveyImages = scheduleData.img;
    };

    $scope.expandSelected = function(concern){
        $scope.concerns.forEach(function(val){
            val.expanded = false;
        })
        concern.expanded = true;
    }

    $scope.myOrderBy = 'UserName';
    $scope.reverse = false;
    $scope.orderByMe = function(col){
        $scope.myOrderBy = col;
        if($scope.reverse){
            $scope.reverse = false;
            // $scope.reverseclass = 'arrow-up';
        } else {
            $scope.reverse = true;
            // $scope.reverseclass = 'arrow-down';
        }
    } 

    $scope.sortClass = function(col){
        if($scope.myOrderBy == col ){
            if($scope.reverse){
                // return 'arrow-down'; 
            } else {
                // return 'arrow-up';
            }
        } else {
            return '';
        }
    }

    $scope.gotoTop = function() {
         // $location.hash('top');
         // $anchorScroll();
         // $(window).scrollTop(0)
        var obj = $('html').scrollTop() !== 0 ? 'html' : 'body';
        $(obj).animate({ scrollTop: 0 }, "slow"); 
    };
    
}]).controller('RowCtrl', function ($scope) {    

    $scope.toggleRow = function () {
        $scope.selected = !$scope.selected;
    };

    $scope.isSelected = function (concernData) {
        return $scope.selected;
    };
});