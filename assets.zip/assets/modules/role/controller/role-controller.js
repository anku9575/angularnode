/**
* Purpose – For showing roles and changing permission on roles.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('roleController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state",  function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {
    
    $('[data-toggle="tooltip"]').tooltip(); 
    $('html').removeClass('nav-open');
    
    $scope.roleData = {
        "RoleRight": []
    };
    
    $scope.redirect = function(url){
        $location.path(url);
    }
    
    $scope.giveSaveAccess = function(row){
        row.actionaccess = false    
    }
    
    /**
    *   showing all sub menus on add role page. 
    ***/
    $scope.GetSubMenu
    $scope.rig = []; 
    $scope.init = function(){
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetSubMenu").then(function(respnose){
            $scope.GetSubMenu = respnose.data.GetSubMenu;
            console.log($scope.GetSubMenu);
            for(var i = 0; i < $scope.GetSubMenu.length; i++){
                $scope.rig.push({ Allow:$scope.GetSubMenu[i].Allow = false, "SubMenuId":$scope.GetSubMenu[i].SubMenuId, "SubMenuName":$scope.GetSubMenu[i].SubMenuName});
            }
        });
    }
    $scope.init();

    /**
    *   getting role rights from add role form. 
    ***/
    $scope.Rig = [];
    $scope.r = [];
    $scope.rolesRight = function(index, Allow){
        if($scope.rig[index].Allow == true){
            $scope.rig[index].Allow = false;
        } else if($scope.rig[index].Allow == false){
            $scope.rig[index].Allow = true;
        } 
        
        if($scope.rig[index].Allow == true){
            $scope.r.push({"Allow":$scope.rig[index].Allow, "SubMenuId":$scope.rig[index].SubMenuId})
        } else if($scope.rig[index].Allow == false){
            $scope.r.splice(index, 1)
        }
    }

    $scope.viewUserWithRoles = function(row){
        $location.path("app/userRole/" + row.RoleId);
    }
    
    $scope.saveRole = function(isValid){
        if(isValid){
            $scope.roleData.RoleRight = $scope.r;
            $http.post($rootScope.serviceURL+"api/FleetManagement/AddRole", $scope.roleData).then(function(response){
                var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $location.path('app/role');
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                }
            }).catch(function(error){
                console.log(error);
            });
        } else {
            $scope.submitted = true;
        }    
    }

    /**
    *   showing role rights on role page. 
    ***/
    $scope.GetRoleWithRights = [];
    $scope.roleTemplete = function(){
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            $scope.GetRoleWithRights = response.data.GetRoleRights;
        });
    }
    $scope.roleTemplete();

    $scope.changeAllow = function(RoleId,data,index){
        return $.grep($scope.GetRoleWithRights,function(t){
            if(t.RoleId == RoleId){
                console.log(t.RoleId , RoleId)
                if(t.GetRights[index].Allow == true ){
                    t.GetRights[index].Allow = false;
                    t.GetRights[index].Mandatory = false;
                    console.log(t);
                }else{ 
                    t.GetRights[index].Allow = true;
                    console.log(t);
                }
            } 
            return t;
        })
    }

    $scope.changeMandatory = function(RoleId,data,index){
        return $.grep($scope.GetRoleWithRights,function(t){
            if(t.RoleId == RoleId){
                console.log(t.RoleId , RoleId)
                if(t.GetRights[index].Allow == false){
                    t.GetRights[index].Mandatory = false;
                } else {
                    if(t.GetRights[index].Mandatory == true ){
                        t.GetRights[index].Mandatory = false;
                        console.log(t);
                    }else {
                        t.GetRights[index].Mandatory = true;
                        console.log(t);
                    }
                }
            } 
            return t;
        })
    }

    $scope.updateRole = function(data){
        $scope.updateData = {};
        $scope.rightData = [];
        $scope.updateData.RoleId = data.RoleId;
        $scope.updateData.IsActive = true;
        
        for(var a = 0; a < data.GetRights.length; a++){
            $scope.rightData.push({ "SubMenuId":data.GetRights[a].SubMenuId, "Allow":data.GetRights[a].Allow, "Mandatory":data.GetRights[a].Mandatory })            
        }

        $scope.updateData.RoleRight = $scope.rightData;

        $http.post($rootScope.serviceURL+"api/FleetManagement/UpdateRole", $scope.updateData).then(function(response){
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.roleTemplete();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.roleTemplete();
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);