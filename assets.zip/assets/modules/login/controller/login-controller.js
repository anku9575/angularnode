/**
* Purpose – For login.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('loginController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$stateParams", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $stateParams) {
    
    
	console.log($stateParams)
	$scope.init = function(){
		if($stateParams.AccessToken){
			$http.post("https://45.114.79.242/QAComponentService/ComponentsService.svc/IsValidateUserByFOSLoginSession", {"loginSession" : $stateParams.AccessToken}).then(function(response){
				var accessTokenResponse = response.data
				if(accessTokenResponse.IsSuccess == true){
					$rootScope.isVerified = true;
					$localStorage.AccessToken = accessTokenResponse.SingleResult.LoginSession
					$scope.formData = {
						"LoginFrom": "w",
						"EmailId": accessTokenResponse.SingleResult.Email,
						// "EmailId": "sandeep.sehgal@in.panasonic.com",
						"Password": "password" 
					}
					console.log($scope.formData)
					$http.post($rootScope.serviceURL+"api/FleetManagement/Login", $scope.formData).then(function(response){
						var data = response.data;
						if(data.ErrorCode == 200 && data.success == true){
							$localStorage.userData = data;
							$scope.showNotification(from = 'bottom', align='right', "Login Successfull !!!");
							// $location.path("dashboard");
							setTimeout(function() {
								window.location = $("base").attr('href') + "app/dashboard";
							}, 1000);
						} else {
							$scope.showNotification(from = 'bottom', align='right', "Invalid email or password !!!");
						}
					}).catch(function(err){
						return err;
					})	
				} else {
					if(accessTokenResponse.IsSuccess == false){
						$scope.InvalidToken()
					}
				}
			})
		} else {
			$scope.InvalidToken()
		}
	}
	
	$scope.InvalidToken = function(){
		swal({
            title: 'Invalid Token !',
            text: "Not a valid request !",
            type: 'warning',
            confirmButtonText: 'Ok',
            confirmButtonClass: "btn btn-success",
            buttonsStyling: false
        }).then(function(result) {
        	console.log(result)
        	if(result == true){
	            swal({
	                title: 'Reference',
	                text: 'Please login POIS PLUS to continue in Feet On Street :)',
	                type: 'success',
	                confirmButtonClass: "btn btn-success",
	                allowOutsideClick: false,
	                buttonsStyling: false
	            }).then(function(result) {
	            	console.log(result)
	            	if(result == true){
	            		window.location.href = "https://45.114.79.242/QAgenericComponent";
	            	}
	            }).catch(swal.noop)
        	}
        })
	}
	$scope.init();
	   
    $scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);