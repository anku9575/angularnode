/**
* Purpose – For adding and saving branch.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('addBranchController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state",  function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {
    
	$('html').removeClass('nav-open');
    
	$scope.formData = {};

	/**
	* showing region and sub regions in filters
	**/
	$scope.regionWithSubregion = function(){
		$scope.region = [];
		$http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
			// $scope.region = response.data.GetRegionWithSubRegion
			$scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.region.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
			console.log($scope.region)
			$scope.subRegion = [];
			for(i = 0; i < $scope.region.length; i++){
				for(j = 0; j < $scope.region[i].GetSubRegion.length; j++){
					var SubRegionId = $scope.region[i].GetSubRegion[j].SubRegionId
					var SubRegionName = $scope.region[i].GetSubRegion[j].SubRegionName
					$scope.subRegion.push({"SubRegionId": SubRegionId, "SubRegionName": SubRegionName})
				}
			}
		})
	}
	$scope.regionWithSubregion();

	/**
	* saving branch
	**/
	$scope.saveBranch = function(isValid){
		if(isValid){
			$http.post($rootScope.serviceURL+"api/FleetManagement/AddBranch", $scope.formData).then(function(response){
				var data = response.data;   
	            if(data.ErrorCode == 200){
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            	$state.reload();
	            } else {
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            }	
			})
		} else {
			$scope.submitted = true;
		}
	}

	/**
	* showing notification
	**/
	$scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);