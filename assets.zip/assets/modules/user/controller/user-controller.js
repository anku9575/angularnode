/**
* Purpose – For showing and updating user list, reset device and user permission.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('userController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$stateParams", "$compile", "$window", "$anchorScroll", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $stateParams, $compile, $window, $anchorScroll) {

    $('[data-toggle="tooltip"]').tooltip();
    $('html').removeClass('nav-open');
    if($localStorage.lastSelectedPage){
        $scope.currentpage = angular.copy($localStorage.lastSelectedPage);
    } else {
        $scope.currentpage = 1;
    }

    $scope.pageChangeHandler = function(num) {
        $localStorage.lastSelectedPage = num;
    };

    $scope.giveSaveAccess = function(row){
        row.actionaccess = false    
    }


    $scope.zoneData = [];
    $scope.zoneRegionData = [];
    $scope.zoneSubRegionData = [];
    $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
        $scope.zoneRegion = response.data.GetRegionZoneModel;
        for(var i = 0; i < $scope.zoneRegion.length; i++){
            var ZoneId = $scope.zoneRegion[i].ZoneId
            var ZoneName = $scope.zoneRegion[i].ZoneName
            var region = $scope.zoneRegion[i].GetRegionWithSubRegionModel
            $scope.zoneData.push({"ZoneId":ZoneId, "ZoneName":ZoneName})
            for(var j = 0; j < region.length; j++){
                var RegionId = region[j].RegionId
                var RegionName = region[j].RegionName
                var GetSubRegion = region[j].GetSubRegion
                $scope.zoneRegionData.push({"RegionId":RegionId, "RegionName":RegionName, checked: false})
                for(var k = 0; k < GetSubRegion.length; k++){
                    var SubRegionId = GetSubRegion[k].SubRegionId
                    var SubRegionName = GetSubRegion[k].SubRegionName
                    $scope.zoneSubRegionData.push({"SubRegionId":SubRegionId, "SubRegionName":SubRegionName})
                }
            }
        }
    });    
    
    $scope.redirect = function(url){
        $location.path(url);
    }

    $scope.roleFilter = function(){
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            $scope.filterRoles = response.data.GetRoleRights;
            return $scope.filterRoles;
        });
    }

    $scope.stateChange = function(pageName, id){
        $location.path(pageName + "/" + id);
    }

    $scope.getUserWiseDetail = function(id){
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserWiseDetail", {
            "UserId": id,
            "Creator": 2,
            "Modifier": 3
        }).then(function(response){
            $scope.userWiseDeatil = response.data;
        });
    }

    /**
    *   showing region and sub region on select box on concerns page for filter.
    ***/
    $scope.regionFilter = function(){
        $scope.filterRegions = [];
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
            //$scope.filterRegions = response.data.GetRegionWithSubRegion;
            $scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.filterRegions.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
            return $scope.filterRegions;
        });
    }
    
    $scope.RegionData = {}
    $scope.subRegionFilter = function(RegionId, GetSubRegion){
        console.log($scope.SubRegionId);
        $scope.RegionIds = RegionId;
        $scope.fSubRegion = GetSubRegion;
    }

    $scope.LoggedInUser = null
    $scope.filterUser = function(){
        $scope.userFilter = {
            "RegionId" : $scope.RegionIds,   
            "SubRegionId" : $scope.SubRegionId,
            "RoleId": $scope.RoleId,
            "LoggedInUser": $scope.LoggedInUser,
            "UserId": 0
        };

        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserDetail", $scope.userFilter).then(function(response) {
            /*$scope.GetUserDetail = response.data.GetUserDetail;
            console.log($scope.GetUserDetail);*/
            var GetUserDetail = response.data.GetUserDetail;

            angular.forEach(GetUserDetail, function(item, i){
                var UserZones = [];
                var SubRegionId = [];
                var Region = [];
                var zoneData = angular.copy($scope.zoneData)
                angular.forEach(item.UserZones, function(uzItem, index){
                    UserZones.push(uzItem.ZoneId);
                });
                angular.forEach(item.SubRegion, function(uzItem, index){
                    SubRegionId.push(uzItem.SubRegionId);
                });

                item.ZoneId = UserZones;
                item.zoneData = angular.copy($scope.zoneData);
                item.SubRegionId = SubRegionId;
                angular.forEach($scope.filterRegions, function(rItem){
                    angular.forEach(item.Region, function(regionItem){
                        Region.push(regionItem.RegionId);
                        if(rItem.RegionId == regionItem.RegionId){
                            item.zoneSubRegionData = rItem.GetSubRegion
                        }
                    })
                })
                item.RegionId = Region
                //item.zoneSubRegionData = angular.copy($scope.zoneSubRegionData);
            });

            $scope.GetUserDetail = GetUserDetail;
            console.log($scope.GetUserDetail)
        });
    }

    $scope.allow = [];
    $scope.GetUserDetail
    $scope.rightsdetails = new Array();
    $scope.changeAllow = function(UserId,data,index){
        return $.grep($scope.GetUserDetail,function(t){
            if(t.UserId == UserId){
                if(t.GetAddUserRights[index].Allow==true){
                    t.GetAddUserRights[index].Allow = false;
                    t.GetAddUserRights[index].Mandatory = false;
                    console.log(t);
                }else{
                    t.GetAddUserRights[index].Allow = true;
                    console.log(t);
                }
            } 
            return t;
        })
    }
      

    $scope.changeMandatory = function(UserId,data,index){
        return $.grep($scope.GetUserDetail,function(t){
            if(t.UserId == UserId){
                if(t.GetAddUserRights[index].Allow == false){
                    t.GetAddUserRights[index].Mandatory = false;
                } else {
                    if(t.GetAddUserRights[index].Mandatory==true){
                        t.GetAddUserRights[index].Mandatory = false;
                        console.log(t);
                    }else{
                        t.GetAddUserRights[index].Mandatory = true;
                        console.log(t);
                    }
                }    
            } 
            return t;
        })
    }

    $scope.data = {};
    $scope.saveUserDetail = function(data){
        $scope.data.UserId = data.UserId;
        $scope.data.IsActive = data.IsActive;
        $scope.data.AddUserRights = data.GetAddUserRights;
        $http.post($rootScope.serviceURL+"api/FleetManagement/UpdateUserActivity", $scope.data).then(function(response){
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

    $scope.GetUserDetailFun = function(){
        if($stateParams.id){
            console.log($stateParams.id)
            $scope.regionFilter().then(function(){
                $scope.roleFilter().then(function(){
                    if($stateParams.id == 'true'){
                        $scope.LoggedInUser = true
                        $scope.filterUser(true);
                    } else if($stateParams.id == 'false'){
                        $scope.LoggedInUser = false
                        // $scope.RoleId = $stateParams.id;
                        $scope.filterUser(true);
                    } else {
                        $scope.RoleId = $stateParams.id;
                        $scope.filterUser(true);
                    }
                });
            });
        } else {
            $scope.regionFilter().then(function(){
                $scope.roleFilter();
                $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserDetail").then(function(response) {
                    var GetUserDetail = response.data.GetUserDetail;

                    angular.forEach(GetUserDetail, function(item, i){
                        var UserZones = [];
                        var SubRegionId = [];
                        var Region = [];
                        var zoneData = angular.copy($scope.zoneData)
                        angular.forEach(item.UserZones, function(uzItem, index){
                            UserZones.push(uzItem.ZoneId);
                        });
                        angular.forEach(item.SubRegion, function(uzItem, index){
                            SubRegionId.push(uzItem.SubRegionId);
                        });
                        //console.log("details :::::::::::::: ", UserZones);

                        angular.forEach(zoneData, function(uzItem, index){
                            if(UserZones.indexOf(uzItem.ZoneId) > -1){
                                console.log(uzItem.ZoneId);
                                uzItem.checked = true;
                            }
                        });

                        item.ZoneId = UserZones;
                        item.zoneData = angular.copy($scope.zoneData);
                        item.SubRegionId = SubRegionId;
                        angular.forEach($scope.filterRegions, function(rItem){
                            angular.forEach(item.Region, function(regionItem){
                                Region.push(regionItem.RegionId);
                                if(rItem.RegionId == regionItem.RegionId){
                                    item.zoneSubRegionData = rItem.GetSubRegion
                                }
                            })
                        })
                        item.RegionId = Region
                        /*setTimeout(function() {
                            item.zoneSubRegionData = angular.copy($scope.zoneSubRegionData);
                        }, 500);*/

                    });
                    $scope.GetUserDetail = GetUserDetail;
                    console.log("$scope.GetUserDetail", $scope.GetUserDetail)

                }).then(function(){
                    $scope.regionFilter();
                }).then(function(){
                    $scope.roleFilter();
                });    
            })
        }
    }

    $('#stamps').hide();
    $scope.resetDevice = function(userId, resetDeviceValue){
        var note = "Once reset, you will not be able to undo the reset device !";
        swal({
            title: "Are you sure?",
            text: note,
            icon: "warning",
            buttons: true,
            dangerMode: true,
            showCancelButton: true,
            reverseButtons: true,
        }).then((willDelete) => {
            $scope.approveBtn = true 
            if (willDelete) {
                $('#stamps').show().addClass('stamp');
                setTimeout(function(){
                    $('#stamps').removeClass('stamp');
                    $scope.isResetDevice(userId, resetDeviceValue);
                }, 8000);
            }
        });
    }

    $scope.isResetDevice = function(userId, resetDeviceValue){
        $('#stamps').hide();
        $http.post($rootScope.serviceURL+"api/FleetManagement/AdminResetDevice", {"UserId": userId, "ResetDevice": resetDeviceValue}).then(function(response){
            var data = response.data;
            if(data.ErrorCode == 200){
                $scope.approveBtn = false
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
                $window.location.reload();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
            }
        })
    }

    $scope.GetResetDevice = function(){
        $scope.GetResetDeviceUserDetail = []
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserDetail").then(function(response) {
            $scope.UserDetail = response.data.GetUserDetail;
            for(var i = 0; i < $scope.UserDetail.length; i++){
                if($scope.UserDetail[i].DeviceReset == true){
                    $scope.GetResetDeviceUserDetail.push($scope.UserDetail[i])
                }
            }
        })        
    }

    $scope.resetDevicefilterUser = function(){
        $scope.userFilter = {
            "RegionId" : $scope.RegionIds,   
            "SubRegionId" : $scope.SubRegionId,
            "RoleId": $scope.RoleId,
            "UserId": 0
        };
        $scope.GetResetDeviceUserDetail = []
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUserDetail", $scope.userFilter).then(function(response) {
            $scope.UserDetail = response.data.GetUserDetail;
            for(var i = 0; i < $scope.UserDetail.length; i++){
                if($scope.UserDetail[i].DeviceReset == true){
                    $scope.GetResetDeviceUserDetail.push($scope.UserDetail[i])
                }
            }
        })
    }

    $scope.editZoneRegion = function(userid, zone, region, subregion){
        console.log(zone)
        console.log(region)
        console.log(subregion)
        $scope.data = {}
        $scope.data.UserId = userid;
        $scope.data.ZoneId = zone;
        $scope.data.RegionId = region;
        $scope.data.SubRegionId = subregion;
        console.log($scope.data)
        $http.post($rootScope.serviceURL+"api/FleetManagement/UpdateZoneRegionSubRegion", $scope.data).then(function(response){
            var data = response.data;
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.init();
            }
        })
    }

    $scope.gotoTop = function() {
         // $location.hash('top');
         // $anchorScroll();
         // $(window).scrollTop(0)
        var obj = $('html').scrollTop() !== 0 ? 'html' : 'body';
        $(obj).animate({ scrollTop: 0 }, "slow");
    
    };

    $scope.init = function(){
        $scope.GetUserDetailFun();
        $scope.GetResetDevice();
    }
    $scope.init();
}]);