/**
* Purpose – For showing hierarchy wise tour, schedules and survey summary.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('teamsController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$stateParams", "Lightbox", "$compile" , "NgMap", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $stateParams, Lightbox, $compile, NgMap) {

    $('html').removeClass('nav-open');

    if($localStorage.userData.UserTypeId == 1 || $localStorage.userData.UserTypeId == 8){
        $scope.regionAccess = false
    } else {
        $scope.regionAccess = true
    }

    $scope.date = {
        today: new Date(),
        minDate: new Date(),
        maxDate: new Date()
    }
    
    $scope.roleFilter = function(){
        $scope.filterRoles = [];
        /*return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRoleWithRights").then(function(response){
            $scope.filterRoles = response.data.GetRoleRights;
            return $scope.filterRoles;
        });*/
        return $http.post($rootScope.serviceURL+"api/FleetManagement/GetRoleWithUnderRole", {"RoleId": $localStorage.userData.RoleId}).then(function(response){
            return $scope.filterRoles = response.data.GetRoleWithUnderRoleModel
        })
    }
    
    /**
    *   showing region and sub region on select box on concerns page for filter.
    ***/
    $scope.filterRegions = [];
    $scope.regionFilter = function(){
        return $http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
            // $scope.filterRegions = response.data.GetRegionWithSubRegion;
            $scope.zone = response.data.GetRegionZoneModel;
            for(var i = 0; i < $scope.zone.length; i++){
                for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
                    $scope.filterRegions.push($scope.zone[i].GetRegionWithSubRegionModel[j])
                }
            }
            return $scope.filterRegions;
        });
    }

    $scope.RegionData = {}
    $scope.subRegionFilter = function(data){
        $scope.RegionData = data;
        $scope.fSubRegion = data.GetSubRegion;
    }

    $scope.branchFilter = function(branch){
        $scope.fBranch = branch.GetBranch
    }

    $scope.currentRoleName = function(data){
        $scope.loggedInRoleName = data.RoleName
    }

    $scope.TUser
    $scope.GetUnderUserInfoAdmin = function(isValid){
        $scope.TourDetail = []
        if(isValid){
            if($scope.fromDate == undefined || $scope.toDate == undefined){
                $scope.fromFilterDate = null;
                $scope.toFilterDate = null;
            } else {
                $scope.fromFilterDate = moment($scope.fromDate).format('YYYY/MM/DD');
                $scope.toFilterDate = moment($scope.toDate).format('YYYY/MM/DD');
            }
            if($scope.RoleId == 1 || $scope.RoleId == 8){
                $scope.BranchId = 0
            }

/*            console.log("RegionId, " + $scope.RegionData.RegionId)
            console.log("SubRegionId," + $scope.SubRegionId)
            console.log("RoleId, " + $scope.RoleId)
            console.log("BranchId, " + $scope.BranchId)
*/
            $http.post($rootScope.serviceURL+"api/FleetManagement/GetUnderUserInfoAdmin", {
                "RegionId": $scope.RegionData.RegionId,
                "SubRegionId": $scope.SubRegionId,
                "BranchId": $scope.BranchId,
                "RoleId": $scope.RoleId,
                "UserId": 0,
                "FromDate": $scope.fromFilterDate,
                "ToDate": $scope.toFilterDate,
                "Creator": 6,
                "Modifier": 7
            }).then(function(response){
                console.log("response")
                console.log(response)
                $scope.TUser = response.data.TUser
                $scope.UnderRole = response.data.UnderRole
                $scope.BranchId = response.data.TUser[0].BranchId[0]
            
            })
        } else {
            $scope.submitted = true
        }
    }

    $scope.filterData
    $scope.subData = function(role, index){
        $scope.subRoleName = role.RoleName
        $scope.TUser[index].expanded = true;
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUnderUserInfoAdmin", {
            "RegionId": $scope.RegionData.RegionId,
            "SubRegionId": $scope.SubRegionId,
            "BranchId": $scope.BranchId,
            "RoleId": role.RoleId,
            "ParentRoleId":$scope.RoleId,
            "UserId": 0,
            "FromDate": $scope.fromFilterDate,
            "ToDate": $scope.toFilterDate,
            "Creator": 6,
            "Modifier": 7
        }).then(function(response){
            console.log("response")
            console.log(response)
            $scope.filterData = response.data.TUser
            $scope.filterDataUnderRole = response.data.UnderRole
        })
    }

    $scope.filterData1
    $scope.sub1Data = function(role, index){
        $scope.sub1RoleName = role.RoleName
        $scope.filterData[index].expanded = true;
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUnderUserInfoAdmin", {
            "RegionId": $scope.RegionData.RegionId,
            "SubRegionId": $scope.SubRegionId,
            "BranchId": $scope.BranchId,
            "RoleId": role.RoleId,
            "ParentRoleId":$scope.RoleId,
            "UserId": 0,
            "FromDate": $scope.fromFilterDate,
            "ToDate": $scope.toFilterDate,
            "Creator": 6,
            "Modifier": 7
        }).then(function(response){
            console.log("response")
            console.log(response)
            $scope.filterData1 = response.data.TUser
            $scope.filterDataUnderRole1 = response.data.UnderRole
        })
    }

    $scope.filterData2
    $scope.sub2Data = function(role, index){
        $scope.sub2RoleName = role.RoleName
        $scope.filterData1[index].expanded = true;
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetUnderUserInfoAdmin", {
            "RegionId": $scope.RegionData.RegionId,
            "SubRegionId": $scope.SubRegionId,
            "BranchId": $scope.BranchId,
            "RoleId": role.RoleId,
            "ParentRoleId":$scope.RoleId,
            "UserId": 0,
            "FromDate": $scope.fromFilterDate,
            "ToDate": $scope.toFilterDate,
            "Creator": 6,
            "Modifier": 7
        }).then(function(response){
            console.log("response")
            console.log(response)
            $scope.filterData2 = response.data.TUser
            $scope.filterDataUnderRole2 = response.data.UnderRole
        })
    }

    $scope.userid
    $scope.getTour = function(userId, PC){
        $scope.scheduleDetail = []
        $scope.surveyModel = []
        $scope.userid = userId
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetTour", {"UserId": $scope.userid}).then(function(response){
            if(PC == "C"){
                $scope.TourDetail = []
                $scope.TourDetail = [
                    {
                        "tourtype": "Current Tour",
                        "TourDetails": response.data.CurrentTure
                    }
                ]
            } else if(PC == "P"){
                $scope.TourDetail = []
                $scope.TourDetail = [
                    {
                        "tourtype": "Past Tour",
                        "TourDetails": response.data.PastTure
                    }
                ]
            }
        })
    }

    $scope.route = [];
    $scope.getSchedule = function(ScheduleId, tourName){
        $scope.tourName = tourName;

        // $scope.concernData.UserId = UserId;
        // $scope.concernData.ScheduleId = ScheduleId;
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetMyTourDetail", {"ScheduleId": ScheduleId}).then(function(response){
            console.log(response);
            $scope.render = true;
            $scope.route = [];
            $scope.concernDetail = response.data;
            // $scope.userIdForSurvey = $scope.concernDetail.UserId;
            var ScheduleDateWise = $scope.concernDetail.ScheduleDateWise;
            

            angular.forEach(ScheduleDateWise, function(row){
                row.route = [];
                row.img = [];
                angular.forEach(row.GetSchedule, function(item){
                    item.img = [];
                    $scope.SubDealerName = item.SubDealerName;
                    //$scope.imgURL = item.ImagePath;
                    $scope.imgURL = item.ScheduleDetailUploadImage;


                    row.route.push({ 
                        title: item.SubDealerName, 
                        pos : [ item.Latitude , item.Longitude], 
                        onRoute: true
                    });

                    /*for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].replace(/\\/g, "/");
                        item.img.push({url:$scope.i});
                    }*/
                    for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].UploadImage;
                        $scope.iDate = $scope.imgURL[k].Snapdate;
                        item.img.push({url:$scope.i, snapDate: $scope.iDate});
                    }
                });

                if(row.route.length > 1 ){
                    row.start = row.route[0];
                    row.theWaypoints = [];
                    if(row.route.length > 1 ){
                        for (var i = 1; i < row.route.length - 1; i++ ){
                            var obj = {
                                location:{
                                    lat: parseFloat(row.route[i].pos[0]),
                                    lng: parseFloat(row.route[i].pos[1])
                                },
                                stopover: true
                            };
                            row.theWaypoints.push(obj);
                        }
                    }
                    row.end = row.route[row.route.length-1];
                } else {
                    row.start = {};
                    row.end = {};
                }
            });
            //console.log(ScheduleDateWise);

            $scope.ScheduleDateWise = ScheduleDateWise;

            $timeout(function(){
                NgMap.getMap().then(function(map) {
                    google.maps.event.trigger(map, 'resize');
                });
            }, 2000);
        });
    }

    $scope.openLightboxModal = function (scheduleData) {
        $('#leftNavImages').width('100%');
        $scope.surveyImages = scheduleData.img;
    };

    $scope.getSurvey = function(date, scheculeId){
        $('#rightSideNavForLoc').width('100%');
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetLocationWiseSurvey", {
            "UserId": $scope.userid,
            "ScheduleDate": date,
            "ScheduleDetailId": scheculeId,
            "Creator": 4,
            "Modifier": 5
        }).then(function(response){
            $scope.surveyModelForLocation = response.data.GetsurveyModel
        })
    }

    $scope.GetTourWiseSurvey = function(userid, scheculeId){
        $('#rightSideNav').width('100%');
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetTourWiseSurvey", {
          "UserId": userid,
          "ScheduleId": scheculeId
        }).then(function(response){
            console.log(response)
            $scope.surveyModel = response.data.GetsurveyModel
        })
    }

    $scope.init = function(){
        $scope.regionFilter().then(function(){
            $scope.roleFilter().then(function(){
                console.log($localStorage.userData)
                console.log($scope.filterRegions);
                angular.forEach($scope.filterRegions, function(item){
                    if(item.RegionId == $localStorage.userData.RegionId){
                        $scope.RegionId = item;
                        $scope.RegionData = item;
                        $scope.subRegionFilter(item);
                    }
                })
                console.log($scope.filterRoles)
            	var i = $scope.filterRoles.indexOf($localStorage.userData.RoleId)
            	console.log(i)

            	var index = $scope.functiontofindIndexByKeyValue($scope.filterRoles, "RoleId", $localStorage.userData.RoleId);
				$scope.filterRoles.splice(index, 1);

                /*angular.forEach($scope.filterRoles, function(item){
                    if(item.RoleId == $localStorage.userData.RoleId){
                    	$scope.filterRoles.splice(item.RoleId, 1);
                        $scope.RoleId = item.RoleId;
                        $scope.RoleName = item.RoleName;
                    }
                })*/
            })
        })
    }

    $scope.functiontofindIndexByKeyValue = function(arraytosearch, key, valuetosearch) {
		for (var i = 0; i < arraytosearch.length; i++) {
			if (arraytosearch[i][key] == valuetosearch) {
				return i;
			}
		}
		return null;
	}

    $scope.wrongRouteDistance = function(addressName, lat, long, wrongLat, wrongLong){
        $('#mySidenav').width('100%');
        $scope.wrongRoute = [];
        $scope.addressName = addressName;
        $scope.Latitude = lat 
        $scope.Longitude = long
        $scope.wlat = wrongLat
        $scope.wlong = wrongLong

        $timeout(function(){
            NgMap.getMap().then(function(map) {
                google.maps.event.trigger(map, 'resize');
                $scope.wrongRoute.push({ title: $scope.addressName, pos : [ $scope.Latitude, $scope.Longitude], onRoute: true }, { title: "Finish Address", pos : [ $scope.wlat, $scope.wlong], onRoute: true });
            });
        }, 1000);
        
        $scope.wrongstart = {};
        $scope.wrongtheWaypoints = [];
        $scope.wrongend = {};
        
        $scope.$watchCollection('wrongRoute', function () {
            if($scope.wrongRoute.length > 1 ){
                $scope.wrongstart = $scope.wrongRoute[0];
                $scope.wrongtheWaypoints = [];
                if($scope.wrongRoute.length > 1 ){
                    for (var i = 1; i < $scope.wrongRoute.length - 1; i++ ){
                    var obj = {
                        location:{
                            lat: $scope.wrongRoute[i].pos[0],
                            lng: $scope.wrongRoute[i].pos[1]
                        },
                        stopover: true
                    };
                    $scope.wrongtheWaypoints.push(obj);
                }
            }
                $scope.wrongend = $scope.wrongRoute[$scope.wrongRoute.length-1];
            } else {
                $scope.wrongstart = {};
                $scope.wrongend = {};
            }
        });
    }

    $scope.init();
}]);