/**
* Purpose – For showing my tour, schedules and survey summary.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('myTourController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$stateParams", "Lightbox", "$compile", "NgMap", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $stateParams, Lightbox, $compile, NgMap) {

    $('html').removeClass('nav-open');
    $scope.getTour = function(userId, PC){
        $scope.userid = userId
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetTour", {"UserId": $localStorage.userData.UserId}).then(function(response){
            $scope.TourDetail = [
                {
                    "tourtype": "Current Tour",
                    "TourDetails": response.data.CurrentTure
                }, {
                    "tourtype": "Past Tour",
                    "TourDetails": response.data.PastTure
                }/*, {
                    "tourtype": "UpComming Tour",
                    "TourDetails": response.data.UpCommingTure
                }*/
            ]
            console.log($scope.TourDetail);
        })
    }
    
    $scope.route = [];
    $scope.getSchedule = function(ScheduleId, tourName){
        $scope.tourName = tourName;

        // $scope.concernData.UserId = UserId;
        // $scope.concernData.ScheduleId = ScheduleId;
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetMyTourDetail", {"ScheduleId": ScheduleId}).then(function(response){
            console.log(response);
            $scope.render = true;
            $scope.route = [];
            $scope.concernDetail = response.data;
            // $scope.userIdForSurvey = $scope.concernDetail.UserId;
            var ScheduleDateWise = $scope.concernDetail.ScheduleDateWise;
            

            angular.forEach(ScheduleDateWise, function(row){
                row.route = [];
                row.img = [];
                angular.forEach(row.GetSchedule, function(item){
                    item.img = [];
                    $scope.SubDealerName = item.SubDealerName;
                    //$scope.imgURL = item.ImagePath;
                    $scope.imgURL = item.ScheduleDetailUploadImage;


                    row.route.push({ 
                        title: item.SubDealerName, 
                        pos : [ item.Latitude , item.Longitude], 
                        onRoute: true
                    });

                    /*for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].replace(/\\/g, "/");
                        item.img.push({url:$scope.i});
                    }*/
                    for(var k = 0; k < $scope.imgURL.length; k++){
                        $scope.i = $scope.imgURL[k].UploadImage;
                        $scope.iDate = $scope.imgURL[k].Snapdate;
                        item.img.push({url:$scope.i, snapDate: $scope.iDate});
                    }
                });

                if(row.route.length > 1 ){
                    row.start = row.route[0];
                    row.theWaypoints = [];
                    if(row.route.length > 1 ){
                        for (var i = 1; i < row.route.length - 1; i++ ){
                            var obj = {
                                location:{
                                    lat: parseFloat(row.route[i].pos[0]),
                                    lng: parseFloat(row.route[i].pos[1])
                                },
                                stopover: true
                            };
                            row.theWaypoints.push(obj);
                        }
                    }
                    row.end = row.route[row.route.length-1];
                } else {
                    row.start = {};
                    row.end = {};
                }
            });
            //console.log(ScheduleDateWise);

            $scope.ScheduleDateWise = ScheduleDateWise;

            $timeout(function(){
                NgMap.getMap().then(function(map) {
                    google.maps.event.trigger(map, 'resize');
                });
            }, 2000);
        });
    }

    $scope.openLightboxModal = function (scheduleData) {
        $('#leftNavImages').width('100%');
        $scope.surveyImages = scheduleData.img;
    };

    $scope.getSurvey = function(date, scheculeId){
        $('#rightSideNavForLoc').width('100%');
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetLocationWiseSurvey", {
            "UserId": $localStorage.userData.UserId,
            "ScheduleDate": date,
            "ScheduleDetailId": scheculeId,
            "Creator": 4,
            "Modifier": 5
        }).then(function(response){
            $scope.surveyModelForLocation = response.data.GetsurveyModel
        })
    }

    $scope.GetTourWiseSurvey = function(userid, scheculeId){
        $('#rightSideNav').width('100%');
        console.log(userid)
        console.log(scheculeId)
        $http.post($rootScope.serviceURL+"api/FleetManagement/GetTourWiseSurvey", {
          "UserId": userid,
          "ScheduleId": scheculeId
        }).then(function(response){
            console.log(response)
            $scope.surveyModel = response.data.GetsurveyModel
        })
    }

    $scope.wrongRouteDistance = function(addressName, lat, long, wrongLat, wrongLong){
        $('#mySidenav').width('100%');
        $scope.wrongRoute = [];
        $scope.addressName = addressName;
        $scope.Latitude = lat 
        $scope.Longitude = long
        $scope.wlat = wrongLat
        $scope.wlong = wrongLong

        $timeout(function(){
            NgMap.getMap().then(function(map) {
                google.maps.event.trigger(map, 'resize');
                $scope.wrongRoute.push({ title: $scope.addressName, pos : [ $scope.Latitude, $scope.Longitude], onRoute: true }, { title: "Finish Address", pos : [ $scope.wlat, $scope.wlong], onRoute: true });
            });
        }, 1000);
        
        $scope.wrongstart = {};
        $scope.wrongtheWaypoints = [];
        $scope.wrongend = {};
        
        $scope.$watchCollection('wrongRoute', function () {
            if($scope.wrongRoute.length > 1 ){
                $scope.wrongstart = $scope.wrongRoute[0];
                $scope.wrongtheWaypoints = [];
                if($scope.wrongRoute.length > 1 ){
                    for (var i = 1; i < $scope.wrongRoute.length - 1; i++ ){
                    var obj = {
                        location:{
                            lat: $scope.wrongRoute[i].pos[0],
                            lng: $scope.wrongRoute[i].pos[1]
                        },
                        stopover: true
                    };
                    $scope.wrongtheWaypoints.push(obj);
                }
            }
                $scope.wrongend = $scope.wrongRoute[$scope.wrongRoute.length-1];
            } else {
                $scope.wrongstart = {};
                $scope.wrongend = {};
            }
        });
    }

    $scope.getTour()
}]);