/**
* Purpose – showing charts on dashboard.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('dashboardController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage",  function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage) {
    
    $('html').removeClass('nav-open');
    $('[data-toggle="tooltip"]').tooltip();
    $scope.redirect = function(url){
        $location.path(url);
    }

    $scope.stateChange = function(pageName, id){
        $location.path(pageName + "/" + id);
    }

    $scope.redirectUserList = function(pageName, value){
        $location.path(pageName + "/" + value);
    }

    /**
    *   showing dashboard data
    ***/
    $scope.view2D3D = false
    $scope.roles = ["Month"];
    $scope.concerns = ["Roles"];
    $scope.region = ["Month"];
    $scope.regionConcerns = ["Regions"];
    $scope.dashboard = function(val){
        if(val == true){
            $scope.enabledDisable = true
            $scope.view2D3D = true
        } else {
            $scope.enabledDisable = true
            $scope.view2D3D = false
        }
        $scope.roles = ["Month"];
        $scope.concerns = ["Roles"];
        $scope.region = ["Month"];
        $scope.regionConcerns = ["Regions"];
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetDashboard").then(function(response){
            $scope.GetDashboard = response.data;
            
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChartUser);

            function drawChartUser() {

                var data = google.visualization.arrayToDataTable([
                    ['Task', 'Hours per Day'],
                    ['Login user', $scope.GetDashboard.TotalLogin],
                    ['Logout user', $scope.GetDashboard.TotalLogout]
                ]);

                var options = {
                    title: 'Users',
                    pieSliceText: 'value',
                    is3D: val
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechartUser'));
                // chart.draw(data, options);

                // initial value
                var percent = 0;
                var totPercentage = 0;
                var tempArray = [];
                var rowNum = $scope.arrayRole.length;
                var handler = setInterval(function(){
                    percent += 1;
                    
                    if(percent == 1){
                        for(var i=0; i<rowNum; i++){
                            tempArray.push(parseInt(data.getValue(i, 1)));
                        }
                    }

                    for(var i=0; i<rowNum; i++){
                        if(tempArray[i] >= percent){
                            data.setValue(i, 1, percent);
                        }
                    }

                    chart.draw(data, options);
                    if (percent > Math.max(...tempArray)){
                        google.visualization.events.addListener(chart, 'click', clickHandlerUserLoggedIn);
                        clearInterval(handler);
                    }
                }, 30);
            
                
            }
// ======================================================================================
            /* Role Wise concern bar chart start */
            $scope.RoleWiseConcerns = response.data.RoleWiseConcerns;
            for(var i = 0; i < $scope.RoleWiseConcerns.length; i++){
                $scope.roles.push($scope.RoleWiseConcerns[i].RoleName)
                $scope.concerns.push($scope.RoleWiseConcerns[i].ConcernsCount)
            }
  
            google.charts.load('current', {'packages':['corechart', 'bar']});
            google.charts.setOnLoadCallback(drawVisualization);

            function drawVisualization() {
                // Some raw data (not necessarily accurate)
                var data = google.visualization.arrayToDataTable([$scope.roles, $scope.concerns,]);

                var options = {
                    title : 'Concerns on Roles',
                    vAxis: {title: 'No. of Concerns'},
                    hAxis: {title: 'Roles'},
                    seriesType: 'bars',
                    series: {5: {type: 'line'}}
                };

                var materialOptions = {
                    chart: {
                        title: 'Concerns on Roles',
                        subtitle: ''
                    },
                    axes: {
                        y: {
                            distance: {label: 'No. of Concerns'}, // Left y-axis.
                            brightness: {side: 'right', label: ''} // Right y-axis.
                        },
                        x: {
                            distance: {label: 'Roles'}, // Left y-axis.
                            brightness: {side: 'top', label: ''} // Right y-axis.
                        }
                    },
                    animation: {
                        duration: 1500,
                        startup: true //This is the new option
                    },
                    legend: { position: 'bottom', maxLines: 0 }
                };

                /*var chart = new google.charts.Bar(document.getElementById('chart_div'));
                chart.draw(data, google.charts.Bar.convertOptions(materialOptions));*/

                chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                chart.draw(data, materialOptions);

                google.visualization.events.addListener(chart, 'click', clickHandlerRole);
            }
            /* Role Wise concern bar chart end */

            /* Role Wise concern pie chart start */
            $scope.arrayRole = [['Task', 'Hours per Day']]
            for(var i = 0; i < $scope.RoleWiseConcerns.length; i++){
                var RoleName = $scope.RoleWiseConcerns[i].RoleName
                var RoleCount = $scope.RoleWiseConcerns[i].RoleCount
                $scope.arrayRole.push([RoleName, RoleCount])
            }
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChartRoleCount);

            function drawChartRoleCount() {

                var data = google.visualization.arrayToDataTable($scope.arrayRole);

                var options = {
                    title: 'Roles',
                    pieSliceText: 'value',
                    // width:400,
                    height:300,
                    is3D: val
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechartRoleCount'));
                //chart.draw(data, options);

                // initial value
                var percent = 0;
                var totPercentage = 0;
                var tempArray = [];
                var rowNum = $scope.arrayRole.length;
                var handler = setInterval(function(){
                    percent += 1;
                    
                    if(percent == 1){
                        for(var i=0; i<rowNum; i++){
                            tempArray.push(parseInt(data.getValue(i, 1)));
                        }
                    }

                    for(var i=0; i<rowNum; i++){
                        if(tempArray[i] >= percent){
                            data.setValue(i, 1, percent);
                        }
                    }

                    chart.draw(data, options);
                    if (percent > Math.max(...tempArray)){
                        google.visualization.events.addListener(chart, 'click', clickHandlerRegionRolePie);
                        clearInterval(handler);
                    }
                }, 30);

            
            }
            /* Role Wise concern pie chart end */
// =================================================================================================
            /* Region Wise concern bar chart start */
            $scope.RegionWiseConcerns = response.data.RegionWiseConcerns;
            for(var j = 0; j < $scope.RegionWiseConcerns.length; j++){
                $scope.region.push($scope.RegionWiseConcerns[j].RegionName)
                $scope.regionConcerns.push($scope.RegionWiseConcerns[j].ConcernsCount)
            }

            google.charts.load('current', {'packages':['corechart', 'bar']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                // Some raw data (not necessarily accurate)
                var data = google.visualization.arrayToDataTable([$scope.region, $scope.regionConcerns,]);

                var materialOptions = {
                    chart: {
                        title: 'Top Concern',
                        subtitle: ''
                    },
                    axes: {
                        y: {
                            distance: {label: 'No. of Concerns'}, // Left y-axis.
                            brightness: {side: 'right', label: ''} // Right y-axis.
                        },
                        x: {
                            distance: {label: 'Regions'}, // Left y-axis.
                            brightness: {side: 'top', label: ''} // Right y-axis.
                        }
                    },
                    animation: {
                        duration: 1500,
                        startup: true //This is the new option
                    },
                    legend: { position: 'bottom', maxLines: 0 }
                };

                materialChart = new google.visualization.ColumnChart(document.getElementById('chart_div_top'));
                materialChart.draw(data, materialOptions);

                google.visualization.events.addListener(materialChart, 'click', clickHandlerRegion);
            }
            /* Region Wise concern bar chart end */

            /* Region Wise concern pie chart start */
            $scope.RegionWiseSurvey = response.data.RegionWiseSurvey;
            $scope.array = [['Task', 'Hours per Day']]
            for(var i = 0; i < $scope.RegionWiseSurvey.length; i++){
                var RegionName = $scope.RegionWiseSurvey[i].RegionName
                var SurveyCount = $scope.RegionWiseSurvey[i].SurveyCount
                $scope.array.push([RegionName, SurveyCount])
            }
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(pieRegion);

            function pieRegion() {

                var data = google.visualization.arrayToDataTable($scope.array);

                var options = {
                    title: 'Surveys',
                    pieSliceText: 'value',
                    is3D: val
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                // chart.draw(data, options);

                // initial value
                var percent = 0;
                var totPercentage = 0;
                var tempArray = [];
                var rowNum = $scope.arrayRole.length;
                var handler = setInterval(function(){
                    percent += 1;
                    
                    if(percent == 1){
                        for(var i=0; i<rowNum; i++){
                            tempArray.push(parseInt(data.getValue(i, 1)));
                        }
                    }

                    for(var i=0; i<rowNum; i++){
                        if(tempArray[i] >= percent){
                            data.setValue(i, 1, percent);
                        }
                    }

                    chart.draw(data, options);
                    if (percent > Math.max(...tempArray)){
                        google.visualization.events.addListener(chart, 'click', clickHandlerRegionForSurvey);
                        clearInterval(handler);
                    }
                }, 30);
                
                
            }  
            /* Region Wise concern pie chart end */  

            $(window).resize(function(){
                drawChartUser()
                drawVisualization()
                drawChartRoleCount()
                drawChart()
                pieRegion()
            });
        });
    
        setTimeout(function() {
            $scope.enabledDisable = false
        }, 5000);

    }
    $scope.dashboard(false);

    function clickHandlerUserLoggedIn(e) {
        console.log(e)
        var target = e.targetID.split("#");
        if(target[0] == "legendscrollbutton"){

        } else {
            if(target.length == 3){
                var row = parseInt(target[2]);
                var column = parseInt(target[1]);
            } else {
                var column = parseInt(target[1]);
            }
            console.log(target[1])
            if(target[1] == 1){
                $timeout(function(){
                    $location.path("app/user/false");
                }, 500);
            } else {
                $timeout(function(){
                    $location.path("app/user/true");
                }, 500);
            }
        }    
    }

    function clickHandlerRole(e) {
        console.log(e);
        var target = e.targetID.split("#");
        if(target[0] == "legendscrollbutton"){

        } else {
            if(target.length == 3){
                var row = parseInt(target[2]);
                var column = parseInt(target[1]);
            } else {
                var column = parseInt(target[1]);
            }
            $localStorage.charClickData = $scope.RoleWiseConcerns[column];
            console.log($localStorage.charClickData);
            $timeout(function(){
                $location.path("app/concernSearch/1/" + $scope.RoleWiseConcerns[column].RoleId);
            }, 500);
        }
    }
    function clickHandlerRegion(e) {
        console.log(e);
        var target = e.targetID.split("#");
        if(target[0] == "legendscrollbutton"){

        } else {
            if(target.length == 3){
                var row = parseInt(target[2]);
                var column = parseInt(target[1]);
            } else {
                var column = parseInt(target[1]);
            }
            $localStorage.charClickData = $scope.RegionWiseConcerns[column];
            console.log($localStorage.charClickData);
            $timeout(function(){
                $location.path("app/concernSearch/2/" + $scope.RegionWiseConcerns[column].RegionId);
            }, 500);
        }    
    }

    function clickHandlerRegionForSurvey(e) {
        console.log(e);
        var target = e.targetID.split("#");
        if(target[0] == "legendscrollbutton"){

        } else {
            if(target.length == 3){
                var row = parseInt(target[2]);
                var column = parseInt(target[1]);
            } else {
                var column = parseInt(target[1]);
            }
            $localStorage.charClickData = $scope.RegionWiseConcerns[column];
            console.log($localStorage.charClickData);
            $timeout(function(){
                $location.path("app/surveySearch/2/" + $scope.RegionWiseSurvey[column].RegionId+"/true");
            }, 500);
        }    
    }

    function clickHandlerRegionRolePie(e) {
        console.log(e);
        var target = e.targetID.split("#");
        if(target[0] == "legendscrollbutton"){

        } else {
            if(target.length == 3){
                var row = parseInt(target[2]);
                var column = parseInt(target[1]);
            } else {
                var column = parseInt(target[1]);
            }
            $localStorage.charClickData = $scope.RoleWiseConcerns[column];
            console.log($localStorage.charClickData);
            $timeout(function(){
                $location.path("app/userRole/" + $scope.RoleWiseConcerns[column].RoleId);
            }, 500);
        }    
    }

    /*$(window).resize(function(){
        $scope.roles = ["Month"];
        $scope.concerns = ["Roles"];
        $scope.region = ["Month"];
        $scope.regionConcerns = ["Regions"];
        $timeout(function() {
            $scope.dashboard();
        }, 100);    
    });*/

}]);