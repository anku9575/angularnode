/**
* Purpose – .
* @author - Inwizards
* Created on August 14, 2018
* Modified on 
**/

angular.module("mainApp").controller('exportFileController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state", "$window", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state, $window) {
    
	$('html').removeClass('nav-open');
    
	$scope.onChange = function (e, fileList) {
	    alert('this is on-change handler!');
	};

	var uploadedCount = 0;

	$scope.files = [];
	  
	$scope.onLoad = function (e, reader, file, fileList, fileOjects, fileObj) {
		// console.log(fileObj.base64)
		$http.post($rootScope.serviceURL + "api/FleetManagement/ExcelUpload", {"ExcelType": "D","ExcelBase64": fileObj.base64}).then(function(response){
			console.log(response)
			var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $state.reload()
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
            	$state.reload()
            }
		})
	};

	$scope.getDealers = function(){
		$http.get($rootScope.serviceURL + "api/FleetManagement/GetAllDealer").then(function(response){
			console.log(response)
			$scope.getAllDealer = re
		})
	}
	$scope.getDealers()

	$scope.export = function(){
		$http.post($rootScope.serviceURL + "api/FleetManagement/DealerExport").then(function(response){
			console.log(response.data)
			$scope.exportURL = response.data.DealerExcelUrl
		})
	}


	/**
	* showing notification //$scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	**/
	$scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);