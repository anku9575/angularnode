/**
* Purpose – For changing menu settings and permissions.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('menuFormController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state",  function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {
    
    $('html').removeClass('nav-open');
    $scope.UserTypeId
	$scope.getUserType = function(){
		$http.post($rootScope.serviceURL+"api/FleetManagement/GetUserTypePriority", {"LoginUserTypeId": $localStorage.userData.UserTypeId}).then(function(response){
			$scope.userType = response.data.GetUserType
			console.log($scope.userType)
		})
	}
	$scope.getUserType();

	$scope.GetModuleWithMenu = function(){
		$http.get($rootScope.serviceURL+"api/FleetManagement/GetModuleWithMenu").then(function(response){
			$scope.menuSubmenu = response.data.GetUserTypeWiseRightModules
			console.log($scope.menuSubmenu)
		})
	}
	$scope.GetModuleWithMenu()

	$scope.setUserType = function(UserTypeId){
		console.log(UserTypeId)
		$scope.UserTypeId = UserTypeId
		$http.post($rootScope.serviceURL+"api/FleetManagement/GetUserTypeWiseRight", {
		  "UserTypeId": UserTypeId,
		  "Creator": 2,
		  "Modifier": 3
		}).then(function(response){
			$scope.menuSubmenu = response.data.GetUserTypeWiseRightModules
			console.log($scope.menuSubmenu)
		})
	}

	$scope.updateMenuSubmenu = function(isValid){
		console.log("$scope.menuSubmenu")
		console.log($scope.menuSubmenu)
		if(isValid){
			var MenuId = []
			for(var i = 0; i < $scope.menuSubmenu.length; i++){
				var GetUserTypeWiseRightMenus = $scope.menuSubmenu[i].GetUserTypeWiseRightMenus
				for(var j = 0; j < GetUserTypeWiseRightMenus.length; j++){
					if(GetUserTypeWiseRightMenus[j].Access == true){
						MenuId.push(GetUserTypeWiseRightMenus[j].MenuId)
					}
				}
			}
			var data = {
			    "UserTypeId": $scope.UserTypeId,
			    "Description": $scope.Description,
			    "MenuId": MenuId,
			    "Creator": 3,
			    "Modifier": 4
			}
			console.log(data)

			$http.post($rootScope.serviceURL+"api/FleetManagement/SetUserTypeRight", data).then(function(response){
				var data = response.data;   
	            if(data.ErrorCode == 200){
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            	$state.reload();
	            } else {
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            }
			})	
		} else {
			$scope.submitted = true;
		}
	}

	/**
    *   showing status notification while posting data in DB.
    ***/
    $scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

}]);