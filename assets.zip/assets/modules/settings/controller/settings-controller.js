/**
* Purpose – For showing color of markers in app, set geo fencing and visit suggestion radius, set email for adding new location and time spent for per visit .
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('settingsController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {

    $('html').removeClass('nav-open');    
    $scope.redirect = function(url){
        $location.path(url);
    }

    /**
    *   Set Geo Fencing Radius 
    ***/
    $scope.geoFancingData = {};
    $scope.saveGeoFancing = function(isValid){
        if(isValid){
            $http.post($rootScope.serviceURL+"api/FleetManagement/SetGeoFencingRadius", $scope.geoFancingData).then(function(response){
                var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.geoFancingData.geoFencingRadius = '';
                    $scope.submittedd = false;
                    $scope.VisitRole();
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.VisitRole();
                }
            }).catch(function(error){
                console.log(error);
            });
        } else {
            $scope.submittedd = true;
        }
    }

    /**
    *   Set Radius For Visit Suggestion 
    ***/
    $scope.visitSuggestionData = {};
    $scope.saveRadiusVisit = function(isValid){
        if(isValid){
            $http.post($rootScope.serviceURL+"api/FleetManagement/SetVisitSuggestion", $scope.visitSuggestionData).then(function(response){
                var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.visitSuggestionData.VisitSuggestionRadius = '';
                    $scope.submitted = false;
                    $scope.VisitRole();
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.VisitRole();
                }
            }).catch(function(error){
                console.log(error);
            });
        } else {
            $scope.submitted = true;
        }
    }

    /**
    *   showing all visit roles on settings page.  
    ***/
    $scope.VisitRole = function(){
        $http.get($rootScope.serviceURL+"api/FleetManagement/GetVisitRole").then(function(response){
            $scope.currentRadiusForGF = response.data.GeoFencingRadius;
            $scope.currentRadiusForVS = response.data.VisitSuggestionRadius;
            $scope.currentAdminEmail = response.data.AdminEmail;
            $scope.currentTimeSpent = response.data.TimeSpent;
            $scope.GetVisitRole = response.data.GetVisitRole;
        });
    }
    $scope.VisitRole();

    $scope.changeSettings = {};
    $scope.changeColor = [];
    $scope.saveSettings = function(VisitRoleId, data, index, color, colorRetainDays){
        $scope.data = data;
        if($scope.data != null || $scope.data != "" || $scope.data != undefined){
            $scope.changeColor.push({"VisitRoleId": VisitRoleId, "Color": color, "ColorRetaindays": colorRetainDays})
        }
        $scope.changeSettings.UpdateVisitRoleModel = $scope.changeColor;
        $http.post($rootScope.serviceURL+"api/FleetManagement/UpdateVisitRole", $scope.changeSettings).then(function(response){
            var data = response.data;   
            if(data.ErrorCode == 200){
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                $scope.changeColor = [];
                $scope.VisitRole();
            } else {
                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
            }
        }).catch(function(error){
            console.log(error);
        });
    }

    $scope.saveEmail = function(isValid, email){
        if(isValid){
            $scope.data.UpdateEmailTime = email;
            $http.post($rootScope.serviceURL+"api/FleetManagement/SetAdminEmailId", $scope.data).then(function(response){
                var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.data = {"AdminEmail": '', "TimeSpent": ''};
                    $scope.emailSubmitted = false;   
                    $scope.VisitRole();
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                }
            }).catch(function(err){
                return err;
            });
        } else {
            $scope.emailSubmitted = true;
        }
    }

    $scope.saveTimeSpent = function(isValid, timeSpent){
        if(isValid){
            $scope.data.UpdateEmailTime = timeSpent;
            $http.post($rootScope.serviceURL+"api/FleetManagement/SetAdminEmailId", $scope.data).then(function(response){
                var data = response.data;   
                if(data.ErrorCode == 200){
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                    $scope.data = {"AdminEmail": '', "TimeSpent": ''};
                    $scope.timeSpentSubmitted = false;   
                    $scope.VisitRole();
                } else {
                    $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
                }
            }).catch(function(err){
                return err;
            });
        } else {
            $scope.timeSpentSubmitted = true;
        }
    }

    $scope.showNotification = function(from, align, ErrorMessage) {
        type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }
}]);