/**
* Purpose – For company and saving company.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('addDealerController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {

	$('html').removeClass('nav-open');

	$scope.dealerLocation = true;

	$scope.regionWithSubregion = function(){
		$scope.region = []
		$http.get($rootScope.serviceURL+"api/FleetManagement/GetRegionWithSubRegion").then(function(response){
			// $scope.region = response.data.GetRegionWithSubRegion
			$scope.zone = response.data.GetRegionZoneModel;
			for(var i = 0; i < $scope.zone.length; i++){
				for(var j = 0; j < $scope.zone[i].GetRegionWithSubRegionModel.length; j++){
					$scope.region.push($scope.zone[i].GetRegionWithSubRegionModel[j])
				}
			}
		})
	}
	$scope.regionWithSubregion();

	$scope.subRegions = function(data){
		$scope.subRegion =  data.GetSubRegion
	}

	$scope.branches = function(bdata){
		$scope.Branches =  bdata.GetBranch
	}
	
  	$scope.formData = {
		"DelearName": "",
		"Website": "",
		"EmailId": "",
		"PhoneNo": "",
		"MobileNo": "",
		"Address": "",
		"RegionId": "",
		"Latitude": "",
		"longitude": "",
		"IsActive": false,
		"SubRegionId": "",
		"BranchId": "",
		"SubDealers": [
		    {
		      "SubDelearName": "",
		      "Website": "",
		      "EmailId": "",
		      "PhoneNo": "",
		      "MobileNo": "",
		      "Address": "",
		      "Latitude": "",
		      "longitude": "",
		      "subDealerLocation": true	
		    }
		]
	}

	$scope.addNew = function(){
        $scope.formData.SubDealers.push(
        	{
		      "SubDelearName": "",
		      "Website": "",
		      "EmailId": "",
		      "PhoneNo": "",
		      "MobileNo": "",
		      "Address": "",
		      "Latitude": "",
		      "longitude": "",
		      "subDealerLocation": true
		    }
        );
        $timeout(function(){
			$("#subAddress" + ($scope.formData.SubDealers.length) ).geocomplete({details:""});
        }, 10);
    };	

    $scope.showDealerLocation = function(){
    	$scope.dealerLocation = true;
    }

    $scope.getLocation = function(address) {
    	$scope.formData.Latitude = ""
	    $scope.formData.longitude = ""
	    var geocoder = new google.maps.Geocoder();
	    geocoder.geocode( { 'address': address}, function(results, status) {

		    if (status == google.maps.GeocoderStatus.OK) {
		        $scope.formData.Latitude = results[0].geometry.location.lat();
		        $scope.formData.longitude = results[0].geometry.location.lng();
		        console.log("latitude, longitude");
		        console.log($scope.formData.Latitude, $scope.formData.longitude);
	        	if($scope.formData.Latitude || $scope.formData.longitude){
	        		$scope.$apply(function(){
	        			$scope.dealerLocation = false;
	        		})
	        	}
	        } 
	    }); 
	}

	$scope.showSubDealerLocation = function(row){
		row.subDealerLocation = true;
	}

	$scope.getSubLocation = function(address, row) {
		var geocoder = new google.maps.Geocoder();
	    geocoder.geocode( { 'address': address}, function(results, status) {

		    if (status == google.maps.GeocoderStatus.OK) {
		        row.Latitude = results[0].geometry.location.lat();
		        row.longitude = results[0].geometry.location.lng();
		        console.log("latitude, longitude");
		        console.log($scope.formData);
		        if(row.Latitude || row.longitude){
	        		$scope.$apply(function(){
	        			row.subDealerLocation = false;
	        		})
	        	}
	        } 
	    }); 
	}

    $scope.saveDealer = function(isValid){
    	if(isValid){
    		$http.post($rootScope.serviceURL+"api/FleetManagement/AddDealer", $scope.formData).then(function(response){
    			var data = response.data;   
	            if(data.ErrorCode == 200){
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            	$state.reload();
	            } else {
	                $scope.showNotification(from = 'bottom', align='right', data.ErrorMessage);
	            }
    		})
    	} else {
    		$scope.submitted = true;
    	}
    }

    $scope.deleteRow = function(index){
    	$scope.formData.SubDealers.splice(index, 1);
    }

    /**
    *   showing status notification while posting data in DB.
    ***/
    $scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

}]);