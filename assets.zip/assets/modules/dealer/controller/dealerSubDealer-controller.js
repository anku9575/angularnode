/**
* Purpose – For company and saving company.
* @author - Inwizards
* Modified on August 02, 2018
**/

angular.module("mainApp").controller('dealerSubDealerController', ["$scope", "$rootScope", "$http", "$location", "appAlerts", "$timeout", "$localStorage", "appMethods", "$sessionStorage", "$state", function ($scope, $rootScope, $http, $location, appAlerts, $timeout, $localStorage, appMethods, $sessionStorage, $state) {

	$('html').removeClass('nav-open');

    /**
    *   showing status notification while posting data in DB.
    ***/
    $scope.showNotification = function(from, align, ErrorMessage) {
    	type = ['', 'info', 'success', 'warning', 'danger', 'rose', 'primary'];

        color = Math.floor((Math.random() * 6) + 1);

        $.notify({
            icon: "notifications",
            message: ErrorMessage

        }, {
            type: type[color],
            timer: 3000,
            placement: {
                from: from,
                align: align
            }
        });
    }

}]);