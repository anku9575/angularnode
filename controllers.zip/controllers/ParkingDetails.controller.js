var config         = require('../config'),
    User = require('../models/user.model'),
    Parking = require('../models/Parking.model'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');


exports.getparkingDetails = function(req, res){

        console.log("Get parking details ");

        //var parking_id = (req.query.parking_id)?req.query.parking_id:false;
        //exports.getparkingDetails = function(req, res){
        var parking_id = (req.query.parking_id)?req.query.parking_id:false;
    
        var park = Parking.forge().query(function (qb) {
        qb.select('*');
        qb.where('tbl_parking.parking_id', '=', parking_id);
        /*var park = User.forge().query(function (qb) {
        
        qb.select('tbl_parking.latitude','tbl_parking.longitude',
               'tbl_parking.cycle_parking_available',
               'tbl_parking.cycle_parking_booked',
               'tbl_parking.cycle_parking_price',
               'tbl_parking.bike_parking_booked',
               'tbl_parking.bike_parking_available',
               'tbl_parking.bike_parking_price',
               'tbl_parking.car_parking_available',
               'tbl_parking.car_parking_booked',
               'tbl_parking.car_parking_price',
               'tbl_parking.parking_owner_id',
               'user.contact_no','tbl_parking.place',
               'tbl_parking.parking_id');
        qb.innerJoin('tbl_parking', function() {
        qb.where('tbl_parking.parking_id', '=', 1);
        qb.distinct('tbl_parking.parking_id');
        })*/
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
           return {
                "parking_owner_id": addy.get("parking_owner_id"),
                "contact_no": addy.get("contact_no"),
                "place": addy.get("place"),
                "Parking": [{
                "vehicle_type": "CYCLE",   
                "Available": addy.get("cycle_parking_available"),
                "Booked": addy.get("cycle_parking_booked"),
                "Price": addy.get("cycle_parking_price"),
                
                },
                {
                "vehicle_type": "BIKE",
                "Available": addy.get("bike_parking_available"),
                "Booked": addy.get("bike_parking_booked"),
                "Price": addy.get("bike_parking_price"),
               
                },
                {
                "vehicle_type": "CAR",
                "Available": addy.get("car_parking_available"),
                "Booked": addy.get("car_parking_booked"),
                "Price": addy.get("car_parking_price"),
                
                }],
                "latitude": addy.get("latitude"),
                "longitude": addy.get("longitude"),
                "parking_id": addy.get("parking_id"),                             
            }
        })
    });
    park.then(function (park) {
        if(park.length == 0){
        
            var park = [];
            res.json({"error":false, status:"success","message":"No records are found", result:park});
        }else{
       
            res.json({"error":false, status:"success","message":"These are the records", result:park});
           
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};

exports.getVehicleparkingPrice = function(req, res){
        //var parking_id = (req.query.parking_id)?req.query.parking_id:false;
        //exports.getparkingDetails = function(req, res){
            
        var parking_id = (req.query.parking_id)?req.query.parking_id:false;
        var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    
        var park = Parking.forge().query(function (qb) {
        qb.select('*');
        qb.where('parking_id', '=', parking_id);
        /*var park = User.forge().query(function (qb) {
        
        qb.select('tbl_parking.latitude','tbl_parking.longitude',
               'tbl_parking.cycle_parking_available',
               'tbl_parking.cycle_parking_booked',
               'tbl_parking.cycle_parking_price',
               'tbl_parking.bike_parking_booked',
               'tbl_parking.bike_parking_available',
               'tbl_parking.bike_parking_price',
               'tbl_parking.car_parking_available',
               'tbl_parking.car_parking_booked',
               'tbl_parking.car_parking_price',
               'tbl_parking.parking_owner_id',
               'user.full_name','user.contact_no',
               'tbl_parking.place');
        qb.innerJoin('tbl_parking', function() {
        this.on('tbl_parking.parking_owner_id', '=', 'user.id')
        qb.where('tbl_parking.parking_id', '=', parking_id);
        })*/
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){

            
            if(vehicle_type=="Car")
            {

                return {
                "parking_owner_id": addy.get("parking_owner_id"),
                "place": addy.get("place"),
                "parking_type": addy.get("parking_type"),
                "available": addy.get("car_parking_available"),
                "booked": addy.get("car_parking_booked"),
                "price": addy.get("car_parking_price"),
                "latitude": addy.get("latitude"),
                "longitude": addy.get("longitude"),
                "parking_id": addy.get("parking_id"),   

                
                }


            }

            else if(vehicle_type=="Bike"){

                return {
                "parking_owner_id": addy.get("parking_owner_id"),    
                "place": addy.get("place"),
                "parking_type": addy.get("parking_type"),
                "available": addy.get("bike_parking_available"),
                "booked": addy.get("bike_parking_booked"),
                "price": addy.get("bike_parking_price"),
                "latitude": addy.get("latitude"),
                "longitude": addy.get("longitude"),
                "parking_id": addy.get("parking_id"),  

                }


            }
            else{

                return {
                "parking_owner_id": addy.get("parking_owner_id"),    
                "place": addy.get("place"),
                "parking_type": addy.get("parking_type"),
                "available": addy.get("cycle_parking_available"),
                "booked": addy.get("cycle_parking_booked"),
                "price": addy.get("cycle_parking_price"),
                "latitude": addy.get("latitude"),
                "longitude": addy.get("longitude"),
                "parking_id": addy.get("parking_id"),  

                }

            }
           
        })
    });
    park.then(function (park) {
        if(park.length == 0){
        
            var park = [];
            res.json({"error":false, status:"success","message":"No records are found", result:park});
        }else{
       
            res.json({"error":false, status:"success","message":"These are the records", result:park});
           
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};
