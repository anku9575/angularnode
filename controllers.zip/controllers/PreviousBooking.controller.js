var config         = require('../config'),
    User = require('../models/user.model'),
    Booking = require('../models/Booking.model'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');



exports.getPreviousBookingDetails = function(req, res){

        
        var customer_id = (req.query.customer_id)?req.query.customer_id:false;  
        var park = User.forge().query(function (qb) {
        
        qb.select('tbl_booking.date',
                  'tbl_booking.duration',
                  'tbl_parking.longitude',
                  'tbl_parking.latitude',
                  'tbl_parking.parking_owner_id',
                  'tbl_booking.vehicle_type',
                  'tbl_booking.parking_id',
                  'tbl_booking.place',
                  'tbl_booking.parking_price',
                  'tbl_booking.customer_id',
                  'user.username','user.contact_no');
        qb.innerJoin('tbl_booking', function() {
        this.on('tbl_booking.customer_id', '=', 'user.id')
        })
        qb.innerJoin('tbl_parking', function() {
            this.on('tbl_parking.parking_id', '=', 'tbl_booking.parking_id')
        })

        qb.where('tbl_booking.customer_id', '=', customer_id);
        qb.orderBy('tbl_booking.booking_id', 'desc');

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
           return {
                "duration": addy.get("duration"),
                "date": addy.get("date"),
                //"time": addy.get("time"),
                "vehicle_type": addy.get("vehicle_type"),
                "parking_id": addy.get("parking_id"),
                "parking_owner_id": addy.get("parking_owner_id"),
                "user": addy.get("username"),
                "customer_id": addy.get("customer_id"),
                "place": addy.get("place"),
                "contact_no": addy.get("contact_no"),
                "parking_price": addy.get("parking_price"),
                "latitude":addy.get("latitude"),
                "longitude":addy.get("longitude"),
                                           
            }
        })
    });
    park.then(function (park) {
        if(park.length == 0){
        
            var park = [];
            res.json({"error":false, status:"success","message":"No records are found", result:park});
        }else{
       
            res.json({"error":false, status:"success","message":"These are the records", result:park});
           
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};

/*exports.getPreviousBookingDetails = function(req, res){

        
        var customer_id = (req.query.customer_id)?req.query.customer_id:false;  
        var park = User.forge().query(function (qb) {
        
        qb.select('tbl_booking.date','tbl_booking.duration','tbl_booking.latitude',
            'tbl_booking.longitude',
                  'tbl_booking.vehicle_type','tbl_booking.parking_id',
                  'tbl_booking.place','tbl_booking.parking_price',
                  'tbl_booking.customer_id','user.username','user.contact_no');
        qb.innerJoin('tbl_booking', function() {
        this.on('tbl_booking.customer_id', '=', 'user.id')
        qb.where('tbl_booking.customer_id', '=', customer_id);
        })

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
           return {
                "duration": addy.get("duration"),
                "date": addy.get("date"),
                "parking_id": addy.get("parking_id"),
               
                "vehicle_type": addy.get("vehicle_type"),
                "user": addy.get("username"),
                "customer_id": addy.get("customer_id"),
                "contact_no": addy.get("contact_no"),
                "place": addy.get("place"),
                "parking_price": addy.get("parking_price"),
                                           
            }
        })
    });
    park.then(function (park) {
        if(park.length == 0){
        
            var park = [];
            res.json({"error":false, status:"success","message":"No records are found", result:park});
        }else{
       
            res.json({"error":false, status:"success","message":"These are the records", result:park});
           
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};*/
