var config         = require('../config'),
    User = require('../models/user.model'),
    Parking = require('../models/Parking.model'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');

exports.add = function(req, res){
    console.log("add Customer");
    //var username = (req.body.username)?req.body.username:false;
    var contact_no = (req.body.contact_no)?req.body.contact_no:false;
    var password = (req.body.password)?req.body.password:false;
    //var full_name = (req.body.full_name)?req.body.full_name:false;
    var email = (req.body.email)?req.body.email:false;

    console.log("All parameters are now "+req.body);
    //var userType = (req.body.userType)?req.body.userType:false;
   
   
  
    var user = User.forge().query(function (qb) {
        qb.select('Id', 'password','username','contact_no' ,'code','user_type');
        qb.where('username', '=', email);
        qb.orWhere({contact_no:  contact_no})
        //qb.orWhere({userType:  userType})
        //qb.orWhere({email:  email})
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
        })
    });

    user.then(function (user) {
        if(user.length == 0){
            return CustomerServices.add(req.body).then(function(Customer){
            if(Customer)
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"New Customer created successfully!"}); 
            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
        })
            var user = [];
            res.json({"error":false, status:"success","ResponseMessage":"User is already exists", result:user});
        }else{

            res.json({"error":false, status:"success","ResponseMessage":"User is already exists"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};

/*exports.getnearByLocation = function(req, res){

    var startPoint = {
        latitude:req.body.lat,
        longitude:req.body.lng
    };
     var areaDist = (req.body.areaDist)?req.body.areaDist:false;

     
    //var park = Parking.forge().query(function (qb) {
        //qb.select('*');
        var park = User.forge().query(function (qb) {
        qb.select('tbl_parking.latitude','tbl_parking.longitude',
               'tbl_parking.cycle_parking_available',
               'tbl_parking.cycle_parking_booked',
               'tbl_parking.bike_parking_booked',
               'tbl_parking.bike_parking_available',
               'tbl_parking.car_parking_available',
               'tbl_parking.car_parking_booked',
               'user.contact_no','tbl_parking.place',
               'tbl_parking.parking_owner_id',
               'tbl_parking.parking_id');
        qb.innerJoin('tbl_parking', function() {
        this.on('tbl_parking.parking_owner_id', '=', 'user.id')
        })
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
            var latitude = addy.get("latitude");
            var longitude = addy.get("longitude");
          
            var endPoint = 
                {
                 latitude:latitude,
                 longitude:longitude
                };
            var distance = CustomerServices.getDistance(startPoint,endPoint,2);
                if(distance <= areaDist){
                    addy.attributes.status = 200;
                    return addy;
                }else{
                    return {"status":300};
                }
        }).then(function(data){
            return data;
        }).then(function(list){
            res.json({"error":false,"status" : "success", "message" :"Success","result":list});
        });
    }).catch(function(err) {
        res.json({"error":true,"status" : "error", "message" : err.message,"result":err.message});
    });

};*/

exports.getnearByLocation = function(req, res){
    var newArray = [];
    var startPoint = {
        latitude:req.body.lat,
        longitude:req.body.lng
    };
     var areaDist = (req.body.areaDist)?req.body.areaDist:false;

     
    //var park = Parking.forge().query(function (qb) {
        //qb.select('*');
        var park = User.forge().query(function (qb) {
        qb.select('tbl_parking.latitude','tbl_parking.longitude',
               'tbl_parking.cycle_parking_available',
               'tbl_parking.cycle_parking_booked',
               'tbl_parking.bike_parking_booked',
               'tbl_parking.bike_parking_available',
               'tbl_parking.car_parking_available',
               'tbl_parking.car_parking_booked',
               'user.contact_no','tbl_parking.place',
               'tbl_parking.parking_owner_id',
               'tbl_parking.parking_id');
        qb.innerJoin('tbl_parking', function() {
        this.on('tbl_parking.parking_owner_id', '=', 'user.id')
        //qb.distinct('tbl_parking.place');
        })
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){
                var latitude = addy.get("latitude");
                var longitude = addy.get("longitude");

                var endPoint = 
                {
                    latitude:latitude,
                    longitude:longitude
                };
                var distance = CustomerServices.getDistance(startPoint,endPoint,2);

                console.log("user insert distance is"+areaDist);
                console.log("ADddy lenth is "+addy.length);
                console.log("distance "+distance);
                if(distance <= areaDist){
                    console.log("ADddy lenth is "+addy.length);
                    addy.attributes.status = 200;
                    newArray.push(addy);
                    // return addy;
                    
                }
                return addy;
            })
        }else{
           return addy;
        }
        
    }).then(function(result){
        
        
           if(newArray.length)
                res.json({"error":false,"status" : "success", "message" :"","result":newArray});
            else
                res.json({"error":true,"status" : "error", "message" :"No records founds.","result":newArray});
        

    }).catch(function(err) {
        res.json({"error":true,"status" : "error", "message" : err.message,"result":err.message});
    });

};

exports.show_all_location = function(req, res){
    var newArray = [];
    var startPoint = {
        latitude:req.body.lat,
        longitude:req.body.lng
    };
     var areaDist = 5;

     
    //var park = Parking.forge().query(function (qb) {
        //qb.select('*');
        var park = User.forge().query(function (qb) {
        qb.select('tbl_parking.latitude','tbl_parking.longitude',
               'tbl_parking.cycle_parking_available',
               'tbl_parking.cycle_parking_booked',
               'tbl_parking.bike_parking_booked',
               'tbl_parking.bike_parking_available',
               'tbl_parking.car_parking_available',
               'tbl_parking.car_parking_price',
               'tbl_parking.car_parking_booked',
               'user.contact_no','tbl_parking.place',
               'tbl_parking.parking_owner_id',
               'tbl_parking.parking_id');
        qb.innerJoin('tbl_parking', function() {
        this.on('tbl_parking.parking_owner_id', '=', 'user.id')
        qb.distinct('tbl_parking.place');
        })
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){
                var latitude = addy.get("latitude");
                var longitude = addy.get("longitude");

                var endPoint = 
                {
                    latitude:latitude,
                    longitude:longitude
                };
                var distance = CustomerServices.getDistance(startPoint,endPoint,2);

                console.log("user insert distance is"+areaDist);
                console.log("ADddy lenth is "+addy.length);
                console.log("distance "+distance);
                if(distance <= areaDist){
                    console.log("ADddy lenth is "+addy.length);
                    //addy.attributes.status = 200;
                    newArray.push(addy);
                    // return addy;
                    
                }
                return addy;
            })
        }else{
           return addy;
        }
        
    }).then(function(result){
        
        
           if(newArray.length)
                res.json({"error":false,"status code":200, "status" : "success", "message" :"","result":newArray});
            else
                res.json({"error":true,"status" : "error", "message" :"No records founds.","result":newArray});
        

    }).catch(function(err) {
        res.json({"error":true,"status" : "error", "message" : err.message,"result":err.message});
    });

};