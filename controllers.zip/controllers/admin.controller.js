var config = require('../config'),
    Parking = require('../models/Parking.model'),
    Booking = require('../models/Booking.model'),
    User = require('../models/user.model'),
    adminServices = require('../services/admin.service'),
    moment = require('moment'),
    moment_tz = require('moment-timezone'),
    fs = require("fs"),
    bPromise = require("bluebird"),
    orm = require('../orm');
var DateDiff = require('date-diff');
var crypto = require('crypto');
var request = require('request');

/**
 *	Admin Adding a parking in DB.
 ***/

exports.addparking = function(req, res) {
    console.log("controller add parking");
    return adminServices.findLatLong(req.body).then(function(userData) {
        if (!userData) {
            return adminServices.addparking(req.body).then(function(parkingdetail) {
                if (parkingdetail) {
                    res.json({
                        "StatusCode": 200,
                        "parkingdetail": parkingdetail,
                        "ResponseMessage": "Parking successfully added !!!"
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            }).catch(function(err) {
                res.json({
                    "StatusCode": err.status,
                    "parkingdetail": [],
                    "ResponseMessage": err.messages
                });
            });
        } else {
            res.json({
                "StatusCode": 301,
                "ResponseMessage": "Parking already exists"
            });
        }
    }).catch(function(err) {
        res.json({
            "StatusCode": 301,
            "ResponseMessage": "Parking already exists"
        });
    });    
}

/**
 *  Updating a parking in DB.
 ***/

exports.editparking = function(req, res) {
    console.log("controller edit parking");
    var parking_id = (req.query.parking_id) ? req.query.parking_id : false;
    return adminServices.editparking(req.body.parking_id,req.body).then(function(parkingdetail) {
        if (parkingdetail) {
            res.json({
                    "StatusCode": 200,
                    "parkingdetail": parkingdetail,
                    "ResponseMessage": "Parking successfully updated !!!"
                });
        } else {
            res.json({
                "StatusCode": 301,
                "Message": "An error has occurred."
            });
        }
    }).catch(function(err) {
        res.json({
            "StatusCode": err.status,
            "parkingdetail": [],
            "ResponseMessage": err.messages
        });
    });
}

/**
 *	Get all parking of particular Admin from DB.
 ***/

exports.getparking = function(req, res) {
    console.log("get parking");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where("parking_owner_id", "=", parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_id = addy.get("parking_id");
            var parking_owner_id = addy.get("parking_owner_id");
            var show_parking_status = addy.get("show_parking_status");
            var cycle_parking_available = addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");
            var cycle_parking_price = addy.get("cycle_parking_price");
            var total_cycle_parking = cycle_parking_available + cycle_parking_booked;
            var bike_parking_available = addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
            var bike_parking_price = addy.get("bike_parking_price");
            var total_bike_parking = bike_parking_available + bike_parking_booked;
            var car_parking_available = addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var car_parking_price = addy.get("car_parking_price");
            var total_car_parking = car_parking_available + car_parking_booked;
            var place = addy.get("place");
            var date = addy.get("date");
            return {
                parking_id: parking_id,
                parking_owner_id: parking_owner_id,
                total_cycle_parking: total_cycle_parking,
                show_parking_status: show_parking_status,
                cycle_parking_available: cycle_parking_available,
                cycle_parking_booked: cycle_parking_booked,
                cycle_parking_price: cycle_parking_price,
                total_bike_parking: total_bike_parking,
                bike_parking_available: bike_parking_available,
                bike_parking_booked: bike_parking_booked,
                bike_parking_price: bike_parking_price,
                total_car_parking: total_car_parking,
                car_parking_available: car_parking_available,
                car_parking_booked: car_parking_booked,
                car_parking_price: car_parking_price,
                place: place,
                date: date
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: parking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Deleting a parking from DB.
 ***/

exports.deleteparking = function(req, res) {
    console.log("controller delete parking");
    var parking_id = (req.query.parking_id) ? req.query.parking_id : false;
    return orm.bookshelf.transaction(function(trx) {
        return adminServices.deleteparking(parking_id).then(function(formate) {
            return formate;
        }).then(function(formate) {
            return formate;
        }).catch(function(err) {
            return errors.returnError(err, res);
        });
    }).then(function(data) {
        res.json({
            "error": false,
            "Status": "Success",
            "ResponseMessage": "Record Deleted Successfully.",
            "result": data
        });
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Car Parking info from DB.
 ***/

exports.carparking = function(req, res) {
    console.log("controller car parking");
    var currentTime = moment(new Date()).subtract(1, 'day').format("YYYY-MM-DD");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
        //qb.andWhere('date', '=', currentTime);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            var car_parking_available = addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var total_parking = car_parking_available + car_parking_booked;
            var place = addy.get("place");
            var date = addy.get("date");
            var percentage = car_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                parking_owner_id: parking_owner_id,
                car_parking_available: car_parking_available,
                car_parking_booked: car_parking_booked,
                total_parking: total_parking,
                place: place,
                percentage: percentage,
                date: date
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: parking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Bike Parking info from DB.
 ***/

exports.bikeparking = function(req, res) {
    console.log("controller bike parking");
    var currentTime = moment(new Date()).subtract(1, 'day').format("YYYY-MM-DD");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
        //qb.andWhere('date', '=', currentTime);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            var bike_parking_available = addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
            var total_parking = bike_parking_available + bike_parking_booked;
            var place = addy.get("place");
            var date = addy.get("date");
            var percentage = bike_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                parking_owner_id: parking_owner_id,
                bike_parking_available: bike_parking_available,
                bike_parking_booked: bike_parking_booked,
                total_parking: total_parking,
                place: place,
                percentage: percentage,
                date: date
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: parking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Bicycle Parking info from DB.
 ***/

exports.bicycleparking = function(req, res) {
    console.log("controller bicycle parking");
    var currentTime = moment(new Date()).subtract(1, 'day').format("YYYY-MM-DD");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
        //qb.andWhere('date', '=', currentTime);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            var cycle_parking_available = addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");
            var total_parking = cycle_parking_available + cycle_parking_booked;
            var place = addy.get("place");
            var date = addy.get("date");
            var percentage = cycle_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                parking_owner_id: parking_owner_id,
                cycle_parking_available: cycle_parking_available,
                cycle_parking_booked: cycle_parking_booked,
                total_parking: total_parking,
                place: place,
                percentage: percentage,
                date: date
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: parking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Parking Revenue for Market Place info from DB.
 ***/

exports.parkingRevenueMarketPlace = function(req, res) {
    console.log("controller parking revenue market place");
    var paymentAmount = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var booking = Booking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            paymentAmount += parseInt(addy.get("paymentAmount"));
            var marketPlace = paymentAmount;
            return {
                marketPlace: marketPlace,
            }
        });
    });

    booking.then(function(booking) {
        if (booking.length == 0) {
            var booking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: booking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: paymentAmount
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Parking Revenue for Last Week info from DB.
 ***/

exports.parkingRevenueLastWeek = function(req, res) {
    console.log("controller parking revenue last week");

    var lastMonday = moment().day(-7 + 1).format('DD-MMM-YYYY');     // Monday last week
    var lastTuesday = moment().day(-7 + 2).format('DD-MMM-YYYY');    // Tuesday last week
    var lastWednesday = moment().day(-7 + 3).format('DD-MMM-YYYY');  // Wednesday last week
    var lastThursday = moment().day(-7 + 4).format('DD-MMM-YYYY');   // Thursday last week
    var lastFriday = moment().day(-7 + 5).format('DD-MMM-YYYY');     // Friday last week
    var lastSaturday = moment().day(-7 + 6).format('DD-MMM-YYYY');   // Saturday last week
    var lastSunday = moment().day(-7 + 7).format('DD-MMM-YYYY');     // Sunday last week
    
    var paymentAmount = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var booking = Booking.forge().query(function(qb) {
        qb.select("*");
        qb.whereIn('date', [lastMonday, lastTuesday, lastWednesday, lastThursday, lastFriday, lastSaturday, lastSunday]);
        qb.andWhere('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            paymentAmount += parseInt(addy.get("paymentAmount"));
            date = addy.get("date");
            var marketPlace = paymentAmount;
            return {
                marketPlace: marketPlace,
            }
        });
    });

    booking.then(function(booking) {
        if (booking.length == 0) {
            var booking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: booking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: paymentAmount
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Parking Revenue for Last Month info from DB.
 ***/

exports.parkingRevenueLastMonth = function(req, res) {
    console.log("controller parking revenue last month");
    var array = [];
    var element;
    var lastMonthStartDate = moment().subtract(1, 'month').startOf('months').format('DD-MMM-YYYY');
        for(var i = 1; i <= 29; i++){
            element = moment(lastMonthStartDate).add(i, 'days').format('DD-MMM-YYYY');
            array.push(element);
        }
    //console.log(array)

    var lastMonthEndDate = moment().subtract(1, 'month').endOf('months').format('DD-MMM-YYYY');
    var paymentAmount = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var booking = Booking.forge().query(function(qb) {
        qb.select("*");
        qb.whereIn('date', [lastMonthStartDate, array, lastMonthEndDate]);
        qb.andWhere('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            paymentAmount += parseInt(addy.get("paymentAmount"));
            date = addy.get("date");
            duration = addy.get("duration");
            var marketPlace = paymentAmount;
            return {
                marketPlace: marketPlace,
            }
        });
    });

    booking.then(function(booking) {
        if (booking.length == 0) {
            var booking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: booking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: paymentAmount
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get current passowrd of Admin from DB.
 ***/

exports.currentPassword = function(req, res) {
    console.log("current Password controller");
    var id = (req.query.id) ? req.query.id : false;
    var user = User.forge().query(function(qb) {
        qb.select("*");
        qb.where("id", "=", id);
    }).fetch().then(function(addy) {
        return addy;
    });

    user.then(function(user) {
        if (user.length == 0) {
            var user = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: user
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: user
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Updating Passowrd of Admin in DB.
 ***/

exports.updatingPassword = function(req, res) {
    console.log("controller updatePassword");
    var id = (req.query.id) ? req.query.id : false;

    console.log("id = " + id);
    console.log("body = " + req.body.password);
    return orm.bookshelf.transaction(function(trx) {
        return adminServices.updatingPassword(id, req.body.password).then(function(editdata) {
            return editdata;
        }).then(function(editdata) {
            return editdata;
        }).catch(function(err) {
            return errors.returnError(err, res);
        });
    }).then(function(data) {
        res.json({
            "error": false,
            "Status": "Success",
            "ResponseMessage": "Password Updated Successfully.",
            "result": data
        });
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Add an Admin by SuperAdmin in DB.
 ***/

exports.addAdmin = function(req, res) {
    console.log("controller add admin");
    return adminServices.find(req.body.username, req.body.contact_no).then(function(userData) {
        if (!userData) {
            return adminServices.addAdmin(req.body).then(function(adminDetail) {
                if (adminDetail) {
                    res.json({
                        "StatusCode": 200,
                        "adminDetail": adminDetail,
                        "ResponseMessage": "Admin successfully added !!!"
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "ResponseMessage": "An error has occurred."
                    });
                }
            }).catch(function(err) {
                res.json({
                    "StatusCode": 301,
                    "ResponseMessage": "An error has occurred."
                });
            });
        } else {
            res.json({
                "StatusCode": 301,
                "ResponseMessage": "user with email or contact number already exists"
            });
        }
    }).catch(function(err) {
        res.json({
            "StatusCode": 301,
            "ResponseMessage": "user with email or contact number already exists"
        });
    });
}

/**
 *	Get all Admin added by Super Admin from DB.
 ***/

exports.getAdmin = function(req, res) {
    console.log("get all admin");
    var admin = Parking.forge().query(function(qb) {
        qb.select("*")
        qb.rightJoin('user', function() {
            this.on('tbl_parking.parking_owner_id', '=', 'user.id')
            qb.where('user.user_type', '=', "Admin")
        });
        //qb.groupBy("user.user_type");
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            var username = addy.get("username");
            var cycle_parking_available = addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");
            var cycle_parking_price = addy.get("cycle_parking_price");
            var total_cycle_parking = cycle_parking_available + cycle_parking_booked;
            var bike_parking_available = addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
            var bike_parking_price = addy.get("bike_parking_price");
            var total_bike_parking = bike_parking_available + bike_parking_booked;
            var car_parking_available = addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var car_parking_price = addy.get("car_parking_price");
            var total_car_parking = car_parking_available + car_parking_booked;
            var latitude = addy.get("latitude");
            var longitude = addy.get("longitude");
            var place = addy.get("place");
            var date = addy.get("date");
            return {
                parking_owner_id: parking_owner_id,
                username: username,
                cycle_parking_available: cycle_parking_available,
                cycle_parking_booked: cycle_parking_booked,
                cycle_parking_price: cycle_parking_price,
                total_cycle_parking: total_cycle_parking,
                bike_parking_available: bike_parking_available,
                bike_parking_booked: bike_parking_booked,
                bike_parking_price: bike_parking_price,
                total_bike_parking: total_bike_parking,
                car_parking_available: car_parking_available,
                car_parking_booked: car_parking_booked,
                car_parking_price: car_parking_price,
                total_car_parking: total_car_parking,
                latitude: latitude,
                longitude: longitude,
                place: place,
                date: date
            }
        })
    });

    admin.then(function(admin) {
        if (admin.length == 0) {
            var admin = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: admin
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: admin
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all locations of particular Admin from DB.
 ***/

exports.getLocation = function(req, res) {
    console.log("get location");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parkingLoc = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where("parking_owner_id", "=", parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_id = addy.get("parking_id");
            var place = addy.get("place");
            var cycle_parking_available = addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");
            var total_cycle_parking = cycle_parking_available + cycle_parking_booked;
            var bike_parking_available = addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
            var total_bike_parking = bike_parking_available + bike_parking_booked;
            var car_parking_available = addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var total_car_parking = car_parking_available + car_parking_booked;
            var latitude = addy.get("latitude");
            var longitude = addy.get("longitude");
            return {
                parking_id: parking_id,
                name: place,
                cycle_parking_available: cycle_parking_available,
                cycle_parking_booked: cycle_parking_booked,
                total_cycle_parking: total_cycle_parking,
                bike_parking_available: bike_parking_available,
                bike_parking_booked: bike_parking_booked,
                total_bike_parking: total_bike_parking,
                car_parking_available: car_parking_available,
                car_parking_booked: car_parking_booked,
                total_car_parking: total_car_parking,
                latitude: latitude,
                longitude: longitude
            }
        })
    });

    parkingLoc.then(function(parkingLoc) {
        if (parkingLoc.length == 0) {
            var parkingLoc = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: parkingLoc
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: parkingLoc
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all locations of Admin for Super Admin from DB.
 ***/

exports.getAllLocation = function(req, res) {
    console.log("get All Super Admin location");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var superAdminParkingLoc = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.innerJoin('user', function() {
            this.on("tbl_parking.parking_owner_id", "=", "user.id")
            qb.where('user.user_type', '=', 'Admin')
        });
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_id = addy.get("parking_id");
            var place = addy.get("place");
            var cycle_parking_available = addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");
            var total_cycle_parking = cycle_parking_available + cycle_parking_booked;
            var bike_parking_available = addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
            var total_bike_parking = bike_parking_available + bike_parking_booked;
            var car_parking_available = addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var total_car_parking = car_parking_available + car_parking_booked;
            var latitude = addy.get("latitude");
            var longitude = addy.get("longitude");
            return {
                parking_id: parking_id,
                name: place,
                cycle_parking_available: cycle_parking_available,
                cycle_parking_booked: cycle_parking_booked,
                total_cycle_parking: total_cycle_parking,
                bike_parking_available: bike_parking_available,
                bike_parking_booked: bike_parking_booked,
                total_bike_parking: total_bike_parking,
                car_parking_available: car_parking_available,
                car_parking_booked: car_parking_booked,
                total_car_parking: total_car_parking,
                latitude: latitude,
                longitude: longitude
            }
        })
    });

    superAdminParkingLoc.then(function(superAdminParkingLoc) {
        if (superAdminParkingLoc.length == 0) {
            var superAdminParkingLoc = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: superAdminParkingLoc
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: superAdminParkingLoc
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all Customer parking info of particular Admin from DB.
 ***/

exports.customerInfo = function(req, res) {
    console.log("get customer Info parking");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var booking = Booking.forge().query(function(qb) {
        qb.select("*");
        //qb.where("parking_owner_id", "=", parking_owner_id);
        qb.innerJoin('user', function() {
            this.on('tbl_booking.customer_id', '=', 'user.id')
            qb.where('tbl_booking.parking_owner_id', '=', parking_owner_id)
        });
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                username: addy.get("username"),
                duration: addy.get("duration"),
                start_time: addy.get("start_time"),
                end_time: addy.get("end_time"),
                vehicle_type: addy.get("vehicle_type"),
                vehicle_no: addy.get("vehicle_no"),
                parking_price: addy.get("parking_price"),
                place: addy.get("place"),
                paymentAmount: addy.get("paymentAmount"),
                date_time: addy.get("date_time")
            }
        })
    });

    booking.then(function(booking) {
        if (booking.length == 0) {
            var booking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: booking
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: booking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Car Parking status Completion info(in %) from DB.
 ***/

exports.carParkingStatus = function(req, res) {
    console.log("controller car Parking Status parking");
    var car_parking_available = 0;
    var car_parking_booked = 0;
    var total_parking = 0;
    var percentage = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            car_parking_available += parseInt(addy.get("car_parking_available"));
            car_parking_booked += parseInt(addy.get("car_parking_booked"));
            total_parking = car_parking_available + car_parking_booked;
            percentage = car_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                percentage: percentage
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: percentage
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Bike Parking status Completion info(in %) from DB.
 ***/

exports.bikeParkingStatus = function(req, res) {
    console.log("controller bike Parking Status parking");
    var bike_parking_available = 0;
    var bike_parking_booked = 0;
    var total_parking = 0;
    var percentage = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            bike_parking_available += parseInt(addy.get("bike_parking_available"));
            bike_parking_booked += parseInt(addy.get("bike_parking_booked"));
            total_parking = bike_parking_available + bike_parking_booked;
            percentage = bike_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                percentage: percentage
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: percentage
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Getting Bicycle Parking status Completion info(in %) from DB.
 ***/

exports.bicycleParkingStatus = function(req, res) {
    console.log("controller bike Parking Status parking");
    var cycle_parking_available = 0;
    var cycle_parking_booked = 0;
    var total_parking = 0;
    var percentage = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var parking_owner_id = addy.get("parking_owner_id");
            cycle_parking_available += parseInt(addy.get("cycle_parking_available"));
            cycle_parking_booked += parseInt(addy.get("cycle_parking_booked"));
            total_parking = cycle_parking_available + cycle_parking_booked;
            percentage = cycle_parking_booked / total_parking * 100; //(amount ÷ total) × 100 = ["formula used to get percentage(%)"]
            return {
                percentage: percentage
            }
        });
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: percentage
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all Admin added by Super Admin from DB.
 ***/

exports.getAllAdminName = function(req, res) {
    console.log("get admin Customer Booking Info");
    var admin = User.forge().query(function(qb) {
        qb.select("*")
        qb.where('user_type', '=', "Admin")
        qb.groupBy("user.username");
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                id: addy.get("id"),
                username: addy.get("username"),
                /*cycle_parking_available: addy.get("cycle_parking_available"),		
                cycle_parking_booked: addy.get("cycle_parking_booked"),		
                cycle_parking_price: addy.get("cycle_parking_price"),		
                bike_parking_available: addy.get("bike_parking_available"),		
                bike_parking_booked: addy.get("bike_parking_booked"),		
                bike_parking_price: addy.get("bike_parking_price"),		
                car_parking_available: addy.get("car_parking_available"),		
                car_parking_booked: addy.get("car_parking_booked"),		
                car_parking_price: addy.get("car_parking_price"),		
                latitude: addy.get("latitude"),		
                longitude: addy.get("longitude"),		
                place: addy.get("place"),		
                date: addy.get("date")*/
            }
        })
    });

    admin.then(function(admin) {
        if (admin.length == 0) {
            var admin = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: admin
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: admin
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all Booking of particular Admin from DB.
 ***/

exports.adminCustomerInfo = function(req, res) {
    console.log("get admin Customer Info");
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var booking = Booking.forge().query(function(qb) {
        qb.select("*");
        qb.innerJoin('user', function() {
            this.on('tbl_booking.customer_id', '=', 'user.id')
            qb.where('tbl_booking.parking_owner_id', '=', parking_owner_id)
        });
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            return {
                username: addy.get("username"),
                duration: addy.get("duration"),
                start_time: addy.get("start_time"),
                end_time: addy.get("end_time"),
                vehicle_type: addy.get("vehicle_type"),
                vehicle_no: addy.get("vehicle_no"),
                parking_price: addy.get("parking_price"),
                place: addy.get("place"),
                paymentAmount: addy.get("paymentAmount"),
                date_time: addy.get("date_time")
            }
        })
    });

    booking.then(function(booking) {
        if (booking.length == 0) {
            var booking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: booking
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: booking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *	Get all Admins for Super Admin from DB.
 ***/

exports.profile = function(req, res) {
    console.log("get profile");
    var id = (req.query.id) ? req.query.id : false;
    var admin = User.forge().query(function(qb) {
        qb.select("*");
        qb.where("id", "=", id);
    }).fetchAll().then(function(addy) {
        return addy;
    });

    admin.then(function(admin) {
        if (admin.length == 0) {
            var admin = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Record Found",
                result: admin
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: admin
            });
        }
    }).catch(function(err) {
        return error.returnError(err, res);
    });
}

/**
 *	Forgot Password 1st Step & Send OTP Number.
 ***/

/*** Creating a random OTP number ***/
function randomValueHex(len) {
    return crypto.randomBytes(Math.ceil(len / 2))
        .toString('hex') // convert to hexadecimal format
        .slice(0, len); // return required number of characters
}

exports.contactNumber = function(req, res) {
    var code = randomValueHex(7)
    var contact_no = (req.body.contact_no) ? req.body.contact_no : false;
    var user = User.forge().query(function(qb) {
        qb.select('Id', 'password', 'username', 'contact_no', 'code');
        qb.where('contact_no', '=', contact_no);
        qb.orWhere({
            username: contact_no
        })
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var contact_no = addy.get("contact_no");
            request("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList=" + contact_no + "&msgText=This is a otp number please insert this number " + code + "&senderId=OCEANP", function(error, response, body) {
                if (!error && response.statusCode == 200) {
                    console.log(body);
                }
            })
            return {
                "username": addy.get("username"),
                "contact_no": addy.get("contact_no"),
            }
        })
    });

    user.then(function(user) {
        if (user.length == 0) {
            var user = [];
            res.json({
                "error": false,
                Status: "error",
                "ResponseMessage": "User Mobile No is not registered",
                result: user
            });
        } else {
            //console.log(contact_no);
            //console.log(code);
            return adminServices.code_update(contact_no, code).then(function(Customer) {
                if (Customer) {
                    res.json({
                        "error": false,
                        Status: "success",
                        "ResponseMessage": "OTP is send on your mobile no",
                        result: user
                    });
                } else {
                    res.json({
                        "StatusCode": 301,
                        "result": "Something happened wrong.",
                        "ResponseMessage": "Something happened wrong."
                    });
                }
            })
            res.json({
                "error": false,
                Status: "success",
                "ResponseMessage": "OTP is send on your mobile no",
                result: user
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
};

/**
 *	Forgot Password 2nd Step & Update Password in DB using OTP.
 ***/

exports.updatePassword = function(req, res) {
    console.log("controller update Password using otp");
    var flag = 0;
    var code = (req.body.code) ? req.body.code : false;
    var password = (req.body.password) ? req.body.password : false;
    var user = User.forge().query(function(qb) {
        qb.select('Id', 'username', 'contact_no', 'code', 'datetimeOld');
        qb.where('code', '=', code);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            var contact_no = addy.get("contact_no");
            var code = addy.get("code");
            var now = moment(new Date()); //todays date
            var end = addy.get("datetimeOld"); // another date
            var duration = moment.duration(now.diff(end));
            var days = duration.asDays();
            var Hours = duration.asHours();
            var Minutes = duration.asMinutes();
            if (Minutes <= 10) {
                flag = 0;
                return {
                    username: addy.get("username"),
                    contact_no: addy.get("contact_no"),
                }
            } else {
                flag = 1;
            }
        })
    });

    user.then(function(user) {
        if (user.length == 0) {
            var user = [];
            res.json({
                "error": false,
                Status: "error",
                "ResponseMessage": "Wrong OTP Entered",
                result: user
            });
        } else {
            if (flag == 1) {
                res.json({
                    "error": false,
                    Status: "error",
                    "ResponseMessage": "Now this otp no is not valid"
                });
            } else {
                if (flag == 0) {
                    return adminServices.updatePassword(code, password).then(function(Customer) {
                        if (Customer) {
                            res.json({
                                "error": false,
                                Status: "success",
                                "ResponseMessage": "Password Updated Successfully",
                                result: user
                            });
                        } else {
                            res.json({
                                "StatusCode": 301,
                                "result": "Something went wrong.",
                                "ResponseMessage": "Something went wrong."
                            });
                        }
                    })
                } else {
                    res.json({
                        "StatusCode": 301,
                        "result": "Something went wrong.",
                        "ResponseMessage": "Something went wrong."
                    });
                }
            }
            //res.json({"error":false, Status:"success","ResponseMessage":"Success", result:user});
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
};

/**
 *  Get detail of particular id
 ***/

exports.id_for_edit_parking = function(req, res) {
    console.log("get parking");
    var parking_id = (req.query.parking_id) ? req.query.parking_id : false;
    var parking = Parking.forge().query(function(qb) {
        qb.select("*");
        qb.where("parking_id", "=", parking_id);
    }).fetchAll().then(function(addy) {
        return addy;
    });

    parking.then(function(parking) {
        if (parking.length == 0) {
            var parking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: parking
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "These are records",
                result: parking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}

/**
 *  Get detail of Available and Booked parkings of all Places of a particular Admin
 ***/

exports.vehicleAvailableBookedParking = function(req, res) {
    console.log("Available Parking");
    var carBookParking = 0;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var availbookParking = Parking.forge().query(function(qb) {
        qb.select("");
        qb.sum('cycle_parking_available as bicycleAvail');
        qb.sum('cycle_parking_booked as bicyclebook');
        qb.sum('bike_parking_available as bikeAvail');
        qb.sum('bike_parking_booked as bikebook');
        qb.sum('car_parking_available as carAvail');
        qb.sum('car_parking_booked as carbook');
        qb.where("parking_owner_id", "=", parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    });

    availbookParking.then(function(availbookParking) {
        if (availbookParking.length == 0) {
            var availbookParking = [];
            res.json({
                "error": true,
                status: "error",
                "ResponseMessage": "No Records Found",
                result: availbookParking
            });
        } else {
            res.json({
                "error": false,
                status: "success",
                "ResponseMessage": "",
                result: availbookParking
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}    

/**
 *  Update parking status to show parkings from DB
 ***/

exports.showHideParking = function(req, res){
var parking_id = (req.query.parking_id) ? req.query.parking_id : false;
var status = (req.query.status) ? req.query.status : false;
    return adminServices.showHideParking(parking_id, status).then(function(parkingdetail) {
        if (parkingdetail) {
            res.json({
                "StatusCode": 200,
                "parkingdetail": parkingdetail,
                "ResponseMessage": "Parking successfully updated !!!"
            });
        } else {
            res.json({
                "StatusCode": 301,
                "ResponseMessage": "An error has occurred."
            });
        }
    }).catch(function(err) {
        res.json({
            "StatusCode": err.status,
            "parkingdetail": [],
            "ResponseMessage": err.messages
        });
    });
}

/**
*   Update All parking status to show parkings of particular Admin from DB
***/
exports.allShowHide = function(req, res) {
    var parking_owner_id = (req.query.parking_owner_id)?req.query.parking_owner_id : false;
    var status = (req.query.status)?req.query.status : false;
    return adminServices.allShowHide(parking_owner_id, status).then(function(result) {
        if (result){
            res.json({
                "StatusCode": 200,
                "result": result,
                "ResponseMessage ": "Record is updated succesfully"
            });
        } else {
            res.json({
                "StatusCode": 200,
                "result": result,
                "ResponseMessage": "An error has occurred."
            });
        }
    }).catch(function(err) {
        throw err;
    });
}

/**
*   Showing year revenue graph from DB
***/
exports.yearGraph = function(req, res) {
    console.log("year graph");
    var yearlyIncome = 0;
    var array = [];
    var element;
    var currentYear = (new Date()).getFullYear();
    var currentYearStart = moment().startOf('year').format('DD-MMM-YYYY');
        for(var i = 1; i <= 364; i++){
            element = moment(currentYearStart).add('days', i).format('DD-MMM-YYYY');
            array.push(element);
        }
    //console.log(array);
    var currentYearFinish = moment().endOf('year').format('DD-MMM-YYYY');
    console.log(currentYearFinish);
    //return false;
    var parking_owner_id = (req.query.parking_owner_id) ? req.query.parking_owner_id : false;
    var graph = Booking.forge().query(function(qb) {
        qb.select("*");
        qb.whereIn("date", [currentYearStart, array, currentYearFinish]);
        qb.andWhere('parking_owner_id', '=', parking_owner_id);
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy) {
        return bPromise.map(addy.models, function(addy) {
            yearlyIncome += parseInt(addy.get("paymentAmount"));
            console.log("yearlyIncome = " + yearlyIncome);
            return {
                yearlyIncome: yearlyIncome,
                year : currentYear
            }
            currentYear++;
        });
    });

    graph.then(function(graph) {
        if (graph.length == 0) {
            var graph = [];
            res.json({
                "error": true,
                status: "Error",
                "ResponseMessage": "No Records Found",
                result: graph
            });
        } else {
            res.json({
                "error": false,
                status: "Success",
                "ResponseMessage": "",
                result: graph
            });
        }
    }).catch(function(err) {
        return errors.returnError(err, res);
    });
}




