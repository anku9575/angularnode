/**
 * authentication controller, for authentication user
 */
var config         = require('../config'),
    user = require('../models/user.model'),
    user1 = require('../models/user.model'),
    //authService = require('../services/authusers.service'),
    Passport = require('passport');

//Authorise User
exports.authorizseUser = function(req,res,next){
    if (!req.isAuthenticated()) {
        return res.status(401).send({"error":true,"status" : "error", "message" : "User is not authorized","result": "User is not authorized"});
    }

    next();
}
//login
exports.login = function(req, res, next) {
    console.log("login");
           
            var password = (req.body.password)?req.body.password:false;
            var username = (req.body.username)?req.body.username:false;
            user_type = (req.body.user_type)?req.body.user_type:false;
            var server_key = (req.body.server_key)?req.body.server_key:false;
            var token = (req.body.token)?req.body.token:false;
           //id = (req.body.id)?req.body.id:false;

            

           console.log("Password :" + password);
           console.log("User name /Email :" + username);
           console.log("Server Key :" + server_key);
           console.log("Token :" + username);

            if(password)
               req.body.password = password;
           if(!req.body.password || !username){
                return res.json({"StatusCode": 304,"result":"Please send required parameter.","ResponseMessage": "Please send required parameter."});
           }else{
                return Passport.authenticate('local',
                function(err, user, info) {
                    if(err) {
                        return errors.returnError(err,res);
                    }
                    if(!user) {
                        if(info.error == true && info.statusCode == 201){
                            return res.json({"StatusCode": 404,"result": null,"ResponseMessage": "User doesn't exist."});
                        } else if(info.error == true && info.statusCode == 202){
                            return res.json({"StatusCode": 401,"result": [],"ResponseMessage": "Invalid Password."});
                            
                        }
                    }else{
                        return req.logIn(user, function(err) {
                            console.log("login");
                            res.setHeader('auth-key', 'Ak12mr27Xwg@d89ul');
                            params = {
                                "server_key":server_key,
                                "token":token
                            }
                            var updateParams = {
                                patch : true
                            }

                            var data = params;
                            
                            console.log("=====================");
                            console.log(username);
                            console.log("=====================");
                            return user1.forge().query(function(qb){
                                qb.where('username',username);

                            }).fetch().then(function(user1){
                                //return user.save(data, updateParams);
                                user1.save(data, updateParams);
                                return res.json({"StatusCode": 200,"result":user,"ResponseMessage": "Success"});
                            }).catch(function(err){
                                console.log(err);
                                return err;
                            }) 
                            //return res.json({"StatusCode": 200,"result":user,"ResponseMessage": "Success"});
                        });
                    }
                }
             )(req, res, next);
           }   
};

exports.logout = function(req, res){
    console.log("logout");

    var username = (req.body.username)?req.body.username:false;
    params = {
        "server_key":'',
        "token":''
    }
    var updateParams = {
        patch : true
    }

    var data = params;

    console.log("=====================");
    console.log(username);
    console.log("=====================");
    return user1.forge().query(function(qb){
        qb.where('username',username);

    }).fetch().then(function(user1){
    //return user.save(data, updateParams);
        user1.save(data, updateParams);
        return res.json({"StatusCode": 200,"result":user,"ResponseMessage": "Success"});
    }).catch(function(err){
        console.log(err);
        return err;
    }) 
};
