var config         = require('../config'),
    User = require('../models/user.model'),
    Parking = require('../models/Parking.model'),
    Booking = require('../models/Booking.model'),
    BookingServices = require('../services/Booking.service'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');
var gcm = require('node-gcm');
var cron = require('node-cron');

/*cron.schedule('* * * * * *', function(){*/
 /*console.log("Cron is working ");
var park = User.forge().query(function (qb) {
        qb.select('tbl_booking.parking_owner_id',
        'tbl_booking.date_time','tbl_booking.duration',
        'user.username','tbl_booking.parking_status',
        'user.server_key','user.token');
        qb.innerJoin('tbl_booking', function() {
        this.on('tbl_booking.customer_id', '=', 'user.id')
        })
        qb.where('tbl_booking.parking_status', '=', 0);
        qb.limit(1);    
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){
                var now = moment(new Date()); //todays date
                var end = addy.get("date_time"); 
                var dur = addy.get("duration");
                var api_key = addy.get("api_key");
                var token = addy.get("token");
                var booking_id = addy.get("booking_id");

                var duration = moment.duration(now.diff(end));

                console.log("dat diff is " + duration);
                console.log("dur " + dur);

                var days = duration.asDays();
                var Hours = duration.asHours();
                var Minutes = duration.asMinutes();
                var difference = dur-Minutes;
                console.log("Minutes " + Minutes);
                console.log("difference is "+difference);
                if(difference >=10 ||  difference <=12){
                    var parking_owner_id =addy.get("parking_owner_id")
                    var username =addy.get("username")
                    console.log("parking_owner_id is ="+parking_owner_id);
                    console.log("username is ="+username);
                    


                    var serverKey = api_key; //put your server key here 
                    var fcm = new FCM(serverKey);

                    var message = { 
                        to: token, 
                        //token key
                        collapse_key: 'your_collapse_key',

                        notification: {
                            title: 'Parking notification', 
                            body: 'Body of your Parking notification' 
                        },

                        data: { 
                            my_key: 'my value',
                            my_another_key: 'my another value'
                        }
                    };

                    fcm.send(message, function(err, response){
                        if (err) {
                            console.log("Something has gone wrong!");
                        } else {

                            console.log("Successfully sent with response: ", response);
                            return BookingServices.check_validity(booking_id).then(function(Customer){
                                
                            })
                        }
                    });

                        
                }//if close
                    
                
            })
        }else{
           return addy;
        }
        
    })*/
//});             

//cron.schedule('* * * * * *', function(req, res){

            // Cron bracket start
 
exports.all_customers = function(req, res){
console.log("Cron is working ");
var park = Booking.forge().query(function (qb) {
        qb.select('*');
        qb.where('parking_status', '=', 0);
        qb.limit(1);
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){
                var now = moment(new Date()); //todays date
                var end = addy.get("date_time"); 
                var dur = addy.get("duration");
                var api_key = addy.get("api_key");
                var token = addy.get("token");
                var booking_id = addy.get("booking_id");

                console.log("The booking id is "+booking_id);

                var duration = moment.duration(now.diff(end));

                console.log("dat diff is " + duration);
                console.log("dur " + dur);

                var days = duration.asDays();
                var Hours = duration.asHours();
                var Minutes = duration.asMinutes();
                var difference = dur-Minutes;
                console.log("Minutes " + Minutes);
                console.log("difference is "+difference);
                //if(difference >=10 ||  difference <=12){

                        var sender = new gcm.Sender(api_key);


                        var registrationTokens = [];
                        var message = new gcm.Message({
                        data: { key1: 'msg1' }
                        });
                        var regTokens = [token];
                        sender.send(message, { registrationTokens: regTokens }, function (err, response) {
                        if (err) {
                            
                            console.log("error");
                        }    
                        else {
                            console.log("============");
                            console.log(response);
                            console.log("============");
                            res.json({"error":false,"result":response, status:"success","message":"This is a dummy message"});
                            
                            /*console.log("response");
                            return BookingServices.check_validity(booking_id).then(function(Customer){
                                
                            })*/ 
                        }
                        });

                    
                
            })
        }else{
           return addy;
        }
        
    })
}    
//});               // Cron bracket close



exports.bookingNow = function(req, res){

    console.log("==============================");
    console.log("=========Book now web service=======");
    console.log(req.body);
    console.log("===============================");
    var parking_id = (req.body.parking_id)?req.body.parking_id:false;
    var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    var parking_owner_id = (req.body.parking_owner_id)?req.body.parking_owner_id:false;
    var customer_id = (req.body.customer_id)?req.body.customer_id:false;

    var parking_price = (req.body.parking_price)?req.body.parking_price:false;
    var duration = (req.body.duration)?req.body.duration:false;
    var start_time= (req.body.start_time)?req.body.start_time:false;
    var end_time = (req.body.end_time)?req.body.end_time:false;
    var place = (req.body.place)?req.body.place:false;
    var paymentId = (req.body.paymentId)?req.body.paymentId:false;
    var paymentStatus = (req.body.paymentStatus)?req.body.paymentStatus:false;
    var paymentAmount = (req.body.paymentAmount)?req.body.paymentAmount:false;
    




    var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='CAR'){

            qb.select('*');
            qb.where('car_parking_available', '>', 0);
            qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='BIKE'){

            qb.select('*');
            qb.where('bike_parking_available', '>', 0);  
            qb.andWhere({'parking_id':parking_id}) 

        }
        else{

            qb.select('*');
            qb.where('cycle_parking_available', '>', 0); 
            qb.andWhere({'parking_id':parking_id}) 

        }

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){

        return bPromise.map(addy.models, function(addy){
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            return BookingServices.add(req.body).then(function(Customer){
            if(Customer)
            {
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"Booked successfully!"}); 
                var park = Parking.forge().query(function (qb) {

                    qb.select('*');
                    qb.where('parking_id', '=', parking_id);

                }).fetchAll().then(function(addy) {
                    return addy;
                }).then(function(addy){

                return bPromise.map(addy.models, function(addy){
                //var vehicle_type='Car'
                    if(vehicle_type=='Car'){
                        var car_parking_available =addy.get("car_parking_available");
                        var car_parking_booked = addy.get("car_parking_booked");
                        var now_car_parking_booked=car_parking_booked +1;
                        var now_car_parking_available=car_parking_available-1;
                        console.log("Now the car available parking is"+now_car_parking_available);

                        params = {
                            "car_parking_available":now_car_parking_available,
                            "car_parking_booked":now_car_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else if (vehicle_type=='Bike'){

                        var bike_parking_available =addy.get("bike_parking_available");
                        var bike_parking_booked = addy.get("bike_parking_booked");
                        var now_bike_parking_booked=bike_parking_booked +1;
                        var now_bike_parking_available=bike_parking_available-1;
                        console.log("Now the bike available parking is"+now_bike_parking_available);

                        params = {
                            "bike_parking_available":now_bike_parking_available,
                            "bike_parking_booked":now_bike_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else{

                        var cycle_parking_available =addy.get("cycle_parking_available");
                        var cycle_parking_booked = addy.get("cycle_parking_booked");
                        var now_cycle_parking_booked=cycle_parking_booked +1;
                        var now_cycle_parking_available=cycle_parking_available-1;
                        console.log("Now the cycle available parking is"+now_cycle_parking_available);

                        params = {
                            "cycle_parking_available":now_cycle_parking_available,
                            "cycle_parking_booked":now_cycle_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);
                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });
                    } 

                })
                });
                park.then(function (park) {
                    if(park.length == 0){

                        var park = [];
                        res.json({"error":false, status:"success","message":"No records are found", result:park});
                    }else{

                        res.json({"error":false, status:"success","message":"These are the records", result:park});

                    }
                })
                .catch(function(err) {
                    return errors.returnError(err,res);
                });

            }

            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            })
                var user = [];
                res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{

            res.json({"error":false, status:"success","message":"User is already exists"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};
