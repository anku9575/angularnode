var config         = require('../config'),
    User = require('../models/user.model'),
    Parking = require('../models/Parking.model'),
    BookingServices = require('../services/Booking.service'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');


exports.bookingNow = function(req, res){

        ///get/bookingNow

       
       var parking_id = (req.body.parking_id)?req.body.parking_id:false;
       var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
       var parking_owner_id = (req.body.parking_owner_id)?req.body.parking_owner_id:false;
        var customer_id = (req.body.customer_id)?req.body.customer_id:false;
        
        var parking_price = (req.body.parking_price)?req.body.parking_price:false;
        var duration = (req.body.duration)?req.body.duration:false;
        var time = (req.body.time)?req.body.time:false;
        var place = (req.body.place)?req.body.place:false;
       
       
        var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='Car'){
        
        qb.select('*');
        qb.where('car_parking_available', '>', 0);
        qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='Bike'){

        qb.select('*');
        qb.where('bike_parking_available', '>', 0);  
        qb.andwhere({'parking_id':parking_id}) 

        }
        else{

        qb.select('*');
        qb.where('cycle_parking_available', '>', 0); 
        qb.andwhere({'parking_id':parking_id}) 

        }
        
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            return BookingServices.add(req.body).then(function(Customer){
            if(Customer)
            {
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"New Customer created successfully!"}); 
                var park = Parking.forge().query(function (qb) {
                qb.select('*');
        
                }).fetchAll().then(function(addy) {
                    return addy;
                }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
            //var vehicle_type='Car'
            if(vehicle_type=='Car'){
            var car_parking_available =addy.get("car_parking_available");
            var car_parking_booked = addy.get("car_parking_booked");
            var now_car_parking_booked=car_parking_booked +1;
            var now_car_parking_available=car_parking_available-1;
            console.log("Now the available parking is"+now_car_parking_available);

            params = {
            "car_parking_available":now_car_parking_available,
            "car_parking_booked":now_car_parking_booked }
                var updateParams = {
                patch : true
            }
            var data = params;
            return Parking.forge().query(function(qb){
                qb.where('parking_id',parking_id);

            }).fetch().then(function(Parking){
            return Parking.save(data, updateParams);
            }).catch(function(err){
                console.log(err);
                return err;
            });
                  
            }
            else if (vehicle_type=='Bike'){

            var bike_parking_available =addy.get("bike_parking_available");
            var bike_parking_booked = addy.get("bike_parking_booked");
                  
            }
            else{

            var cycle_parking_available =addy.get("cycle_parking_available");
            var cycle_parking_booked = addy.get("cycle_parking_booked");

            } 

            })
    });
    park.then(function (park) {
        if(park.length == 0){
        
            var park = [];
            res.json({"error":false, status:"success","message":"No records are found", result:park});
        }else{
       
            res.json({"error":false, status:"success","message":"These are the records", result:park});
           
        }
    })
            .catch(function(err) {
                return errors.returnError(err,res);
            });

        }

            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
        })
            var user = [];
            res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{

            res.json({"error":false, status:"success","message":"User is already exists"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};
