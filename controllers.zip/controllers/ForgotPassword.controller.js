var config         = require('../config'),
    ForgotServices = require('../services/Forgot.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),

    moment_tz= require('moment-timezone');
    Passport = require('passport');
var User = require('../models/user.model');
var request = require('request');
var bPromise = require('bluebird');
var bPromise = require('bluebird');
var crypto = require('crypto');
var DateDiff = require('date-diff');
 //1487918642358
/*var d= Date.now();
var sub=(d-14879186);

console.log("the date is "+sub);*/
/*var twilio = require('twilio');
var client = twilio('TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN');
 "http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList="+result2.get('mobilenumber')+"&msgText="+result2.get('code')+"&senderId=OCEANP"
.
client.sendMessage({
  to: '9754845046',
  from: '9617003656',
  body: 'Hello from Twilio!'
});*/

  /*var now = moment(new Date()); //todays date
  var end = moment("2017-03-23 11:27:35.873"); // another date
  var duration = moment.duration(now.diff(end));
  
  console.log("dat diff is " + duration);

  var days = duration.asDays();
  var Hours = duration.asHours();
  var Minutes = duration.asMinutes();
  console.log("days " + days);
  console.log("Hours " + Hours);
  console.log("Minutes " + Minutes);*/
  //var Seconds = duration.asSeconds();


var datetime = moment(new Date());

//var day = moment("1995-12-25");
console.log("The current date time is "+datetime);


console.log("The current date time is "+datetime);



function randomValueHex (len) {
    return crypto.randomBytes(Math.ceil(len/2))
        .toString('hex') // convert to hexadecimal format
        .slice(0,len);   // return required number of characters
}

exports.forgotPassword = function(req, res){
    var code = randomValueHex(7)
    var contact_no = (req.body.contact_no)?req.body.contact_no:false;
    var userType = (req.body.userType)?req.body.userType:false;
    var user = User.forge().query(function (qb) {
        qb.select('Id', 'password','username','contact_no' ,'code');
        
        qb.where('contact_no', '=', contact_no);
        qb.orWhere({username:  contact_no})
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
            var contact_no = addy.get("contact_no");
           

            console.log("the mobile no is "+contact_no);
            //var code= addy.get("code");

            request("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList="+contact_no+"&msgText=This is a otp number please insert this number "+code+"&senderId=OCEANP", function (error, response, body) {if (!error && response.statusCode == 200) {
            console.log(body); 
                    }
                    })

            return {
                
                
                "username": addy.get("username"),
                "contact_no": addy.get("contact_no"),
                
            }

        


        })
    });

    user.then(function (user) {
        if(user.length == 0){
        
            var user = [];
            res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{
        return ForgotServices.code_update(contact_no,code).then(function(Customer){
            if(Customer){
            /*request("http://apivm.valuemobo.com/SMS/SMS_ApiKey.asmx/SMS_APIKeyNUC?apiKey=25EJ1QKsnIKh3pT&cellNoList="+mobile+"&msgText=This is a otp number please insert this number "+code+"&senderId=OCEANP", function (error, response, body) {if (!error && response.statusCode == 200) {
            console.log(body); 
            }
            }) */ 
            res.json({"error":false, status:"success","message":"Otp no is send on your mobile no", result:user});
        //res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"New Customer created successfully!"}); 
           }
            else
            {
        res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            }
        })
            res.json({"error":false, status:"success","message":"Message is send mobile no ", result:user});
           // res.json({"error":false, status:"success","message":"User is already exists"});
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};



exports.getOtpCode = function(req, res){
    //var clientId = (req.params.clientId)?req.params.clientId:false;
    var code = (req.body.code)?req.body.code:false;
    var contact_no = (req.body.contact_no)?req.body.contact_no:false;

    var date2 = new Date();
    console.log("The otp code is " +code);

    var user = User.forge().query(function (qb) {
        qb.select('Id','username','contact_no' ,'code','datetimeOld');
        
        qb.where('code', '=', code);
        qb.andWhere({contact_no:  contact_no})
        qb.orWhere({username:  contact_no})
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        
           return bPromise.map(addy.models, function(addy){
            var contact_no = addy.get("contact_no");
            var code = addy.get("code");
            var now = moment(new Date()); //todays date
            var end = addy.get("datetimeOld");; // another date
            var duration = moment.duration(now.diff(end));

            console.log("dat diff is " + duration);

            var days = duration.asDays();
            var Hours = duration.asHours();
            var Minutes = duration.asMinutes();
            console.log("days " + days);
            console.log("Hours " + Hours);
            console.log("Minutes " + Minutes);
            
            if(Minutes<=10){   
                return {
                
                username: addy.get("username"),
                contact_no: addy.get("contact_no"),
                
                }

            }
            else{
                
            res.json({"error":false, status:"success","message":"Now this otp no is not valid"})
            }


        })
    });
    user.then(function (user) {
        if(user.length == 0){
        
            var user = [];
            res.json({"error":false, status:"success","message":"Otp no and mobile no mismatch", result:user});
        }else{
        return ForgotServices.getOtpCode(contact_no,code).then(function(Customer){
            if(Customer)
                {
            
            res.json({"error":false, status:"success","message":"Success", result:user});
            }
            else
                {
        res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            }
        })
            res.json({"error":false, status:"success","message":"Success", result:user});
           
        }
    })
    .catch(function(err) {
        return errors.returnError(err,res);
    });
};

exports.enter_new_password = function(req, res){

    console.log("enter_new_password");
    //console.log(req.body.password);
    console.log("The contact_no is "+req.body.contact_no);
    console.log("The new Password is "+req.body.newpassword);
    console.log("The  code is "+req.body.code);
    //console.log("The Password is cc"+req.body.cpassword);
      //password = (req.body.Password)?req.body.Password:false;
    console.log(req.query.id);
    return ForgotServices.enter_new_password(req.body.code,req.body.contact_no,req.body.newpassword).then(function(result){
        
    
        if(result)
            
            //res.json({"StatusCode": 200,"result": result,"ResponseMessage ":"Hello " +result.get('first_name')+" your records are update  successfully"});
            res.json({"StatusCode": 200,"result": result,"ResponseMessage ":"Your password is update successfully"});
    
        else
            res.json({"StatusCode":301,"result": result,"ResponseMessage": "Something went wrong"});

    }).catch(function(err){
        console.log(err);
        res.json({"StatusCode":err.status,"result":[],"ResponseMessage":err.messages});
    });
    
    
}
   

