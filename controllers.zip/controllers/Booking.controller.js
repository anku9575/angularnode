var config         = require('../config'),
    User = require('../models/user.model'),
    Booking = require('../models/Booking.model'),
    Parking = require('../models/Parking.model'),
    BookingServices = require('../services/Booking.service'),
    CustomerServices = require('../services/Customer.service'),
    helperServices = require('../services/helper.service'),
    moment = require('moment'),
    fs = require("fs"),
    bPromise        = require("bluebird"),
    orm = require('../orm');

var multer  = require('multer');
var files_Array = [];
var math = require('mathjs');
//var GCM = require('node-gcm');
var cron = require('node-cron');
var DateDiff = require('date-diff');
var FCM = require('fcm-node');


var FCM = require('fcm-node');
    var serverKey = 'AAAAqtUf550:APA91bECfDvt9B7dMR4MK3yxPaNotyC__i2Xoj2f9Exhue-sfWLIG8OSK9JfHec2869poJ0ckBgmFkE0V956Bd-saJzNRqQQO5S8NfTYf-g1wnbUSlm7F1nInMlDqa0fZTWVzJLEB_xc'; 
    var fcm = new FCM(serverKey);
 
    var message = {
        to: 'eIMdz_My_qU:APA91bF63Fr8aFWX7jr3lXvsCqq8dmIdggR5i2Yz6c7pSSokDpADFyHzxqas3PHvoU0N6q1BDRMMVJXtxbWsARpJ6bTzQSaxM6oGzakU5OpV17F7JUX-3pI2kRX6YaepIxu7J2HR06N6', 

        
        collapse_key: 'your_collapse_key',
        
        notification: {
            title: 'Demo purpose notification', 
            body: 'Hello friend' 
        },
        
        data: {

        booking_id: 32,
        place: "BhawarKua",
        start_time: '12-05-2017 15:12',
        end_time: '12-05-2017 13:15',
        duration: 120,
        parking_price: 50,
        customer_id: 37,
        vehicle_type: "CAR",
        parking_id: 5,
        available: 99,
        parking_owner_id: 6,
        }
    };
    
    fcm.send(message, function(err, response){
        if (err) {
            console.log("Something has gone wrong!");
        } else {
            console.log("Successfully sent with response: ", response);
        }
    });


//var Minutes = duration.asMinutes();

var now = moment("2017-04-19 14:51:33.277"); 
var end = moment("2017-04-19 15:51:33.277"); 
var duration = moment.duration(now.diff(end));
var days = duration.asDays();
var Minutes = duration.asMinutes();
console.log("Amey days"+days)
console.log("Amey minutes"+Minutes)

cron.schedule('*/5 * * * *', function(){
  console.log("Hello amey");
});
var park = User.forge().query(function (qb) {
       
        //var booking_id =32;
        qb.select('tbl_booking.place',
            'tbl_booking.end_time',
            'tbl_booking.start_time',
            'tbl_booking.duration',
            'tbl_booking.parking_price',
            'tbl_booking.customer_id',
            'tbl_booking.vehicle_type',
            'tbl_booking.parking_id',
            'tbl_booking.parking_owner_id',
            'tbl_booking.date_time',
            'tbl_booking.booking_id',
            'tbl_parking.car_parking_available',
            'tbl_parking.car_parking_booked',
            'tbl_parking.bike_parking_available',
            'tbl_parking.bike_parking_booked',
            'tbl_parking.cycle_parking_available',
            'tbl_parking.cycle_parking_booked',
        'tbl_booking.duration','user.username',
        'tbl_booking.parking_status',
        'user.server_key','user.token');
        qb.innerJoin('tbl_booking', function() {
        this.on('tbl_booking.customer_id', '=', 'user.id')
        })
        qb.innerJoin('tbl_parking', function() {
        this.on('tbl_parking.parking_id', '=', 'tbl_booking.parking_id')
        })
        qb.where('tbl_booking.booking_id', '=', 40);
        qb.limit(1);
        //console.log("helllfffffffffo");
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){

                var vehicle_type =addy.get("vehicle_type");
                var parking_id =addy.get("parking_id");
                var now = moment(new Date()); //todays date
                var api_key = addy.get("server_key");
                var token = addy.get("token");
                var booking_id = addy.get("booking_id");
                var place = addy.get("place"); 
                var end_time = addy.get("end_time");
                var start_time= addy.get("start_time");
                var duration= addy.get("duration");
                var parking_price= addy.get("parking_price");
                var customer_id= addy.get("customer_id");
                var vehicle_type= addy.get("vehicle_type");
                var parking_id= addy.get("parking_id");
                var duration_3 = moment.duration(now.diff(start_time));

                
                console.log("==============================");
                console.log("server_key " + api_key);
                console.log("token " + token);
                console.log("booking_id " + booking_id);
                console.log("===============================");

                console.log("dur " + difference);

                //var days = duration.asDays();
                //var Hours = duration.asHours();
                var Minutes = duration_3.asMinutes();
                //var difference = dur-Minutes;
                console.log("Minutes " + Minutes);
                
                var difference=duration-Minutes;
                /*var car_parking_available = addy.get("car_parking_available");
                var car_parking_booked = addy.get("car_parking_booked");
                var vehicle_type = addy.get("car_parking_booked");

                console.log("car parking available ="+car_parking_available);
                console.log("car parking booked ="+car_parking_booked);*/
                console.log("vehicle_type ="+vehicle_type);
                console.log("parking_id ="+parking_id);
                /*update code start from here*/
                //var vehicle_type='Car'

                    if(vehicle_type=='Car' ||vehicle_type=='CAR'){
                        var car_parking_available =addy.get("car_parking_available");
                        var car_parking_booked = addy.get("car_parking_booked");
                        var now_car_parking_booked=car_parking_booked -1;
                        var now_car_parking_available=car_parking_available+1;
                        console.log("Now the car available parking is"+now_car_parking_available);

                        params = {
                            "car_parking_available":now_car_parking_available,
                            "car_parking_booked":now_car_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            var serverKey = 'AAAAqtUf550:APA91bECfDvt9B7dMR4MK3yxPaNotyC__i2Xoj2f9Exhue-sfWLIG8OSK9JfHec2869poJ0ckBgmFkE0V956Bd-saJzNRqQQO5S8NfTYf-g1wnbUSlm7F1nInMlDqa0fZTWVzJLEB_xc'; 
                            var fcm = new FCM(serverKey);

                            var message = {
                            to: token, 
                            collapse_key: 'your_collapse_key',

                            notification: {
                            title: 'Demo purpose notification', 
                            body: 'Hello friend' 
                            },

                            data: {

                           /* booking_id: booking_id,
                            place: place,
                            end_time: end_time,
                            start_time: start_time,
                            duration: duration,
                            parking_price: parking_price,
                            customer_id: customer_id,
                            vehicle_type: vehicle_type,
                            parking_id: parking_id,
                            available: 99,*/
                            booking_id: 32,
                            place: "BhawarKua",
                            end_time: '21-4-20173:00 PM',
                            start_time: '21-4-20175:00 PM',
                            duration: 120,
                            parking_price: 50,
                            customer_id: 37,
                            vehicle_type: "CAR",
                            parking_id: 5,
                            available: 99,
                            }
                            };

                            fcm.send(message, function(err, response){
                            if (err) {
                            console.log("Something has gone wrong  Amey!");
                            } else {
                            console.log("Successfully sent with response Amey: ", response);
                            }
                            });
                            finalResult(booking_id);
                            return Parking.save(data, updateParams);
                            console.log("AMey Raverkar 2");
                        }).catch(function(err){
                            //console.log("AMey Raverkar"+err);
                            //return err;

                            /*send notification code start*/
                            /*var serverKey = 'AAAAqtUf550:APA91bECfDvt9B7dMR4MK3yxPaNotyC__i2Xoj2f9Exhue-sfWLIG8OSK9JfHec2869poJ0ckBgmFkE0V956Bd-saJzNRqQQO5S8NfTYf-g1wnbUSlm7F1nInMlDqa0fZTWVzJLEB_xc'; 
                            var fcm = new FCM(serverKey);

                            var message = {
                            to: token, 
                            collapse_key: 'your_collapse_key',

                            notification: {
                            title: 'Demo purpose notification', 
                            body: 'Hello friend' 
                            },

                            data: {

                            booking_id: booking_id,
                            place: place,
                            end_time: end_time,
                            start_time: start_time,
                            duration: duration,
                            parking_price: parking_price,
                            customer_id: customer_id,
                            vehicle_type: vehicle_type,
                            parking_id: parking_id,
                            available: 99,
                            }
                            };

                            fcm.send(message, function(err, response){
                            if (err) {
                            console.log("Something has gone wrong!");
                            } else {
                            console.log("Successfully sent with response: ", response);
                            }
                            });*/

                            /*send notification code end*/
                        });

                    }
                    else if (vehicle_type=='Bike' ||vehicle_type=='BIKE'){

                        var bike_parking_available =addy.get("bike_parking_available");
                        var bike_parking_booked = addy.get("bike_parking_booked");
                        var now_bike_parking_booked=bike_parking_booked -1;
                        var now_bike_parking_available=bike_parking_available +1;
                        console.log("Now the bike available parking is"+now_bike_parking_available);

                        params = {
                            "bike_parking_available":now_bike_parking_available,
                            "bike_parking_booked":now_bike_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                            
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else{

                        var cycle_parking_available =addy.get("cycle_parking_available");
                        var cycle_parking_booked = addy.get("cycle_parking_booked");
                        var now_cycle_parking_booked=cycle_parking_booked - 1;
                        var now_cycle_parking_available=cycle_parking_available + 1;
                        console.log("Now the cycle available parking is"+now_cycle_parking_available);

                        params = {
                            "cycle_parking_available":now_cycle_parking_available,
                            "cycle_parking_booked":now_cycle_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);
                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                            
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });
                    } 
                    console.log("Book id is "+booking_id)
                    
                /*update code end here*/


               /* 
                if(difference >=10 ||  difference <=12){
                    var parking_owner_id =addy.get("parking_owner_id")
                    var username =addy.get("username")
                    console.log("parking_owner_id is ="+parking_owner_id);
                    console.log("username is ="+username);
                    


                    var serverKey = api_key; //put your server key here 
                    var fcm = new FCM(serverKey);

                    var message = { 
                        to: 'fW1Z2mwY0S4:APA91bGIZs8o3HNJSihxcq1NtOdQ6EZ4wm19k_3Jo0BqQN4J4HERoWnqDX0CGgGXbwJBK_gM0uaI0cIxLdIV2ABqLtBbfFq-RZ6vCebw0JAPWaNINW_aBgz1_0fDoVeH-ux_CJoDe_Rh', 
                        //token key
                        collapse_key: 'your_collapse_key',

                        notification: {
                            title: 'Hello'+username+'Parking notification', 
                            body: 'Body of your Parking notification' 
                        },

                        data: { 
                            booking_id: booking_id,
                            place: place,
                            end_time: end_time,
                            start_time: start_time,
                            duration: duration,
                            parking_price: parking_price,
                            customer_id: customer_id,
                            vehicle_type: vehicle_type,
                            parking_id: parking_id,
                        }
                    };

                    fcm.send(message, function(err, response){
                        if (err) {
                            console.log("Something has gone wrong!");
                        } else {

                            console.log("Successfully sent with response: ", response);
                            return BookingServices.check_validity(booking_id).then(function(Customer){
                                
                            })
                        }
                    });

                }*/
                
            })
        }else{
           return addy;
        }
        
    })

//cron.schedule('*/5 * * * *', function(req, res){
console.log("Cron is working ");
/*var park = User.forge().query(function (qb) {
       
        //var booking_id =32;
        qb.select('tbl_booking.place',
            'tbl_booking.end_time',
            'tbl_booking.start_time',
            'tbl_booking.duration',
            'tbl_booking.parking_price',
            'tbl_booking.customer_id',
            'tbl_booking.vehicle_type',
            'tbl_booking.parking_id',
            'tbl_booking.parking_owner_id',
            'tbl_booking.date_time',
            'tbl_booking.booking_id',
        'tbl_booking.duration','user.username',
        'tbl_booking.parking_status',
        'user.server_key','user.token');
        qb.innerJoin('tbl_booking', function() {
        this.on('tbl_booking.customer_id', '=', 'user.id')
        })
        qb.where('tbl_booking.booking_id', '=', 32);
        qb.limit(1);
        //console.log("helllfffffffffo");
    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){
        if(addy.length){
            return bPromise.map(addy.models, function(addy){
                var now = moment(new Date()); //todays date
                //var end = addy.get("date_time"); 
                //var duration = addy.get("duration");
                var api_key = addy.get("server_key");
                var token = addy.get("token");
                var booking_id = addy.get("booking_id");
                var place = addy.get("place"); 
                var end_time = addy.get("end_time");
                var start_time= addy.get("start_time");
                var duration= addy.get("duration");
                var parking_price= addy.get("parking_price");
                var customer_id= addy.get("customer_id");
                var vehicle_type= addy.get("vehicle_type");
                var parking_id= addy.get("parking_id");
                var duration_3 = moment.duration(now.diff(start_time));

                
                console.log("==============================");
                console.log("server_key " + api_key);
                console.log("token " + token);
                console.log("booking_id " + booking_id);
                console.log("===============================");

                console.log("dur " + difference);

                //var days = duration.asDays();
                //var Hours = duration.asHours();
                var Minutes = duration_3.asMinutes();
                //var difference = dur-Minutes;
                console.log("Minutes " + Minutes);
                
                var difference=duration-Minutes;
                console.log("difference is "+difference);
                if(difference >=10 ||  difference <=12){
                    var parking_owner_id =addy.get("parking_owner_id")
                    var username =addy.get("username")
                    console.log("parking_owner_id is ="+parking_owner_id);
                    console.log("username is ="+username);
                    


                    var serverKey = api_key; //put your server key here 
                    var fcm = new FCM(serverKey);

                    var message = { 
                        to: 'fW1Z2mwY0S4:APA91bGIZs8o3HNJSihxcq1NtOdQ6EZ4wm19k_3Jo0BqQN4J4HERoWnqDX0CGgGXbwJBK_gM0uaI0cIxLdIV2ABqLtBbfFq-RZ6vCebw0JAPWaNINW_aBgz1_0fDoVeH-ux_CJoDe_Rh', 
                        //token key
                        collapse_key: 'your_collapse_key',

                        notification: {
                            title: 'Hello'+username+'Parking notification', 
                            body: 'Body of your Parking notification' 
                        },

                        data: { 
                            booking_id: booking_id,
                            place: place,
                            end_time: end_time,
                            start_time: start_time,
                            duration: duration,
                            parking_price: parking_price,
                            customer_id: customer_id,
                            vehicle_type: vehicle_type,
                            parking_id: parking_id,
                        }
                    };

                    fcm.send(message, function(err, response){
                        if (err) {
                            console.log("Something has gone wrong!");
                        } else {

                            console.log("Successfully sent with response: ", response);
                            return BookingServices.check_validity(booking_id).then(function(Customer){
                                
                            })
                        }
                    });

                }
                
            })
        }else{
           return addy;
        }
        
    })*/

//});               // Cron bracket close






exports.bookingNow = function(req, res){

    var parking_id = (req.body.parking_id)?req.body.parking_id:false;
    var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    var parking_owner_id = (req.body.parking_owner_id)?req.body.parking_owner_id:false;
    var customer_id = (req.body.customer_id)?req.body.customer_id:false;

    var parking_price = (req.body.parking_price)?req.body.parking_price:false;
    var duration = (req.body.duration)?req.body.duration:false;
    var start_time= (req.body.start_time)?req.body.start_time:false;
    var end_time = (req.body.end_time)?req.body.end_time:false;
    var place = (req.body.place)?req.body.place:false;


    var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='CAR' || vehicle_type=='Car'){

            qb.select('*');
            qb.where('car_parking_available', '>', 0);
            qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='BIKE' || vehicle_type=='Bike'){

            qb.select('*');
            qb.where('bike_parking_available', '>', 0);  
            qb.andWhere({'parking_id':parking_id}) 

        }
        else{

            qb.select('*');
            qb.where('cycle_parking_available', '>', 0); 
            qb.andWhere({'parking_id':parking_id}) 

        }

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){

        return bPromise.map(addy.models, function(addy){
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            return BookingServices.add(req.body).then(function(Customer){
            if(Customer)
            {
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"New Customer created successfully!"}); 
                var park = Parking.forge().query(function (qb) {

                    qb.select('*');
                    qb.where('parking_id', '=', parking_id);

                }).fetchAll().then(function(addy) {
                    return addy;
                }).then(function(addy){

                return bPromise.map(addy.models, function(addy){
                //var vehicle_type='Car'
                    if(vehicle_type=='Car'|| vehicle_type=='CAR'){
                        var car_parking_available =addy.get("car_parking_available");
                        var car_parking_booked = addy.get("car_parking_booked");
                        var now_car_parking_booked=car_parking_booked +1;
                        var now_car_parking_available=car_parking_available-1;
                        console.log("Now the car available parking is"+now_car_parking_available);

                        params = {
                            "car_parking_available":now_car_parking_available,
                            "car_parking_booked":now_car_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else if (vehicle_type=='Bike' || vehicle_type=='BIKE'){

                        var bike_parking_available =addy.get("bike_parking_available");
                        var bike_parking_booked = addy.get("bike_parking_booked");
                        var now_bike_parking_booked=bike_parking_booked +1;
                        var now_bike_parking_available=bike_parking_available-1;
                        console.log("Now the bike available parking is"+now_bike_parking_available);

                        params = {
                            "bike_parking_available":now_bike_parking_available,
                            "bike_parking_booked":now_bike_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else{

                        var cycle_parking_available =addy.get("cycle_parking_available");
                        var cycle_parking_booked = addy.get("cycle_parking_booked");
                        var now_cycle_parking_booked=cycle_parking_booked +1;
                        var now_cycle_parking_available=cycle_parking_available-1;
                        console.log("Now the cycle available parking is"+now_cycle_parking_available);

                        params = {
                            "cycle_parking_available":now_cycle_parking_available,
                            "cycle_parking_booked":now_cycle_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);
                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });
                    } 

                })
                });
                park.then(function (park) {
                    if(park.length == 0){

                        var park = [];
                        res.json({"error":false, status:"ResponseMessage","message":"No records are found", result:park});
                    }else{

                        res.json({"error":false, status:"success","ResponseMessage":"These are the records", result:park});

                    }
                })
                .catch(function(err) {
                    return errors.returnError(err,res);
                });

            }

            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            })
                var user = [];
                res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{

            res.json({"error":false, status:"success","message":"No parking space are avilable"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};


exports.check_availability = function(req, res){

    console.log("==============================");
    console.log("=========check availability web service=======");
    console.log(req.body);
    console.log("===============================");

    var parking_id = (req.body.parking_id)?req.body.parking_id:false;
    var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    var parking_owner_id = (req.body.parking_owner_id)?req.body.parking_owner_id:false;
    var customer_id = (req.body.customer_id)?req.body.customer_id:false;

    var parking_price = (req.body.parking_price)?req.body.parking_price:false;
    var duration = (req.body.duration)?req.body.duration:false;
    var start_time= (req.body.start_time)?req.body.start_time:false;
    var end_time = (req.body.end_time)?req.body.end_time:false;
    var place = (req.body.place)?req.body.place:false;


    var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='CAR'){

            qb.select('*');
            qb.where('car_parking_available', '>', 0);
            qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='BIKE'){

            qb.select('*');
            qb.where('bike_parking_available', '>', 0);  
            qb.andWhere({'parking_id':parking_id}) 

        }
        else{

            qb.select('*');
            qb.where('cycle_parking_available', '>', 0); 
            qb.andWhere({'parking_id':parking_id}) 

        }

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){

        return bPromise.map(addy.models, function(addy){

            //"car_parking_available":addy.get("car_parking_available"),
            if(vehicle_type=='CAR'){
            return{
             available: addy.get("car_parking_available"),
            }
        }
        else if(vehicle_type=='BIKE'){
            return{
             available: addy.get("bike_parking_available"),
            }

        }
        else{
         
            return{
             available: addy.get("cycle_parking_available"),
            }

         }   
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            
            res.json({"StatusCode":301,"result":"Success","ResponseMessage":"Success",result:user});
                
        }else{

            res.json({"error":false, status:"success","message":"No parking space are avilable"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};


/*exports.check_out = function(req, res){

    var parking_id = (req.body.parking_id)?req.body.parking_id:false;
    var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    var booking_id = (req.body.booking_id)?req.body.booking_id:false;
    console.log("==========================");
    
    console.log("parking_id"+parking_id);
    console.log("vehicle_type"+vehicle_type);
    console.log("booking_id"+booking_id);
    console.log("==========================");
    var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='CAR'){

            qb.select('*');
            qb.where('car_parking_available', '>', 0);
            qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='BIKE'){

            qb.select('*');
            qb.where('bike_parking_available', '>', 0);  
            qb.andWhere({'parking_id':parking_id}) 

        }
        else{

            qb.select('*');
            qb.where('cycle_parking_available', '>', 0); 
            qb.andWhere({'parking_id':parking_id}) 

        }

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){

        return bPromise.map(addy.models, function(addy){

            
            return{

                booking_id : addy.get("booking_id"),

            }
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            return BookingServices.check_out(booking_id).then(function(Customer){
            if(Customer)
            {
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"Checkout successfully!"}); 
                var park = Parking.forge().query(function (qb) {

                    qb.select('*');
                    qb.where('parking_id', '=', parking_id);

                }).fetchAll().then(function(addy) {
                    return addy;
                }).then(function(addy){

                return bPromise.map(addy.models, function(addy){
                //var vehicle_type='Car'
                    if(vehicle_type=='CAR'){
                        var car_parking_available =addy.get("car_parking_available");
                        var car_parking_booked = addy.get("car_parking_booked");
                        var now_car_parking_booked=car_parking_booked -1;
                        var now_car_parking_available=car_parking_available+1;
                        console.log("Now the car available parking is"+now_car_parking_available);

                        params = {
                            "car_parking_available":now_car_parking_available,
                            "car_parking_booked":now_car_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else if (vehicle_type=='BIKE'){

                        console.log("booking id on server page"+booking_id);
                        var status = 3;
                        params = status;
                        params = {
                            "parking_status":status  
                        }
                        var updateParams = {
                        patch : true
                        }
                        var data = params;
                        return Customer.forge().query(function(qb){
                        qb.where('booking_id',booking_id);
                        // qb.andWhere({'status':  0});  
                        }).fetchAll().then(function(products){

                        products.forEach(function(Customer) {

                        //console.log(products);
                        return Customer.save(data, updateParams);

                        });

                        }).catch(function(err){
                        console.log(err);
                        return err;
                        });


                        var bike_parking_available =addy.get("bike_parking_available");
                        var bike_parking_booked = addy.get("bike_parking_booked");
                        var now_bike_parking_booked=bike_parking_booked -1;
                        var now_bike_parking_available=bike_parking_available +1;
                        console.log("Now the bike available parking is"+now_bike_parking_available);

                        params = {
                            "bike_parking_available":now_bike_parking_available,
                            "bike_parking_booked":now_bike_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else{

                        var cycle_parking_available =addy.get("cycle_parking_available");
                        var cycle_parking_booked = addy.get("cycle_parking_booked");
                        var now_cycle_parking_booked=cycle_parking_booked -1;
                        var now_cycle_parking_available=cycle_parking_available +1;
                        console.log("Now the cycle available parking is"+now_cycle_parking_available);

                        params = {
                            "cycle_parking_available":now_cycle_parking_available,
                            "cycle_parking_booked":now_cycle_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);
                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });
                    } 

                })
                });
                park.then(function (park) {
                    if(park.length == 0){

                        var park = [];
                        res.json({"error":false, status:"success","message":"No records are found", result:park});
                    }else{

                        res.json({"error":false, status:"success","message":"These are the records", result:park});

                    }
                })
                .catch(function(err) {
                    return errors.returnError(err,res);
                });

            }

            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            })
                var user = [];
                res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{

            res.json({"error":false, status:"success","message":"No parking space are avilable"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
        
    });
};*/

exports.check_out = function(req, res){

    console.log("==============================");
    console.log("=========check out web service=======");
    console.log(req.body);
    console.log("===============================");

    var parking_id = (req.body.parking_id)?req.body.parking_id:false;
    var vehicle_type = (req.body.vehicle_type)?req.body.vehicle_type:false;
    var booking_id = (req.body.booking_id)?req.body.booking_id:false;
    var user = Parking.forge().query(function (qb) {
        if(vehicle_type=='CAR'){

            qb.select('*');
            qb.where('car_parking_available', '>', 0);
            qb.andWhere({'parking_id':  parking_id})

        }
        else if(vehicle_type=='BIKE'){

            qb.select('*');
            qb.where('bike_parking_available', '>', 0);  
            qb.andWhere({'parking_id':parking_id}) 

        }
        else{

            qb.select('*');
            qb.where('cycle_parking_available', '>', 0); 
            qb.andWhere({'parking_id':parking_id}) 

        }

    }).fetchAll().then(function(addy) {
        return addy;
    }).then(function(addy){

        return bPromise.map(addy.models, function(addy){
        })
    });

    user.then(function (user) {
        if(user.length != 0){
            return BookingServices.check_out(req.body).then(function(Customer){
            if(Customer)
            {
                res.json({"StatusCode":200,"result":Customer,"ResponseMessage":"Check out successfully"}); 
                var park = Parking.forge().query(function (qb) {

                    qb.select('*');
                    qb.where('parking_id', '=', parking_id);

                }).fetchAll().then(function(addy) {
                    return addy;
                }).then(function(addy){

                return bPromise.map(addy.models, function(addy){
                //var vehicle_type='Car'
                    if(vehicle_type=='CAR'){
                        var car_parking_available =addy.get("car_parking_available");
                        var car_parking_booked = addy.get("car_parking_booked");
                        var now_car_parking_booked=car_parking_booked -1;
                        var now_car_parking_available=car_parking_available +1;
                        console.log("Now the car available parking is"+now_car_parking_available);

                        params = {
                            "car_parking_available":now_car_parking_available,
                            "car_parking_booked":now_car_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else if (vehicle_type=='BIKE'){

                        var bike_parking_available =addy.get("bike_parking_available");
                        var bike_parking_booked = addy.get("bike_parking_booked");
                        var now_bike_parking_booked=bike_parking_booked -1;
                        var now_bike_parking_available=bike_parking_available +1;
                        console.log("Now the bike available parking is"+now_bike_parking_available);

                        params = {
                            "bike_parking_available":now_bike_parking_available,
                            "bike_parking_booked":now_bike_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);

                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });

                    }
                    else{

                        var cycle_parking_available =addy.get("cycle_parking_available");
                        var cycle_parking_booked = addy.get("cycle_parking_booked");
                        var now_cycle_parking_booked=cycle_parking_booked -1;
                        var now_cycle_parking_available=cycle_parking_available +1;
                        console.log("Now the cycle available parking is"+now_cycle_parking_available);

                        params = {
                            "cycle_parking_available":now_cycle_parking_available,
                            "cycle_parking_booked":now_cycle_parking_booked 
                        }
                        var updateParams = {
                            patch : true
                        }
                        var data = params;
                        return Parking.forge().query(function(qb){
                            qb.where('parking_id',parking_id);
                        }).fetch().then(function(Parking){
                            return Parking.save(data, updateParams);
                        }).catch(function(err){
                            console.log(err);
                            return err;
                        });
                    } 

                })
                });
                park.then(function (park) {
                    if(park.length == 0){

                        var park = [];
                        res.json({"error":false, status:"ResponseMessage","message":"No records are found", result:park});
                    }else{

                        res.json({"error":false, status:"success","ResponseMessage":"These are the records", result:park});

                    }
                })
                .catch(function(err) {
                    return errors.returnError(err,res);
                });

            }

            else
                res.json({"StatusCode":301,"result":"Something happened wrong.","ResponseMessage":"Something happened wrong."}); 
            })
                var user = [];
                res.json({"error":false, status:"success","message":"User mobile no is not registered", result:user});
        }else{

            res.json({"error":false, status:"success","message":"No parking space are avilable"});
        }
    }).catch(function(err) {
        return errors.returnError(err,res);
    });
};


