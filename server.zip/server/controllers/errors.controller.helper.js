/**
 * Handler for errors
 */
var returnError = function(err,res,code) {
  if(!code) {
    code = err.status ? err.status : 500;
  }
	return res.status(code).json(JSON.stringify({
	  error: true,
	  code:code,
	  data: { message: err.message }
  }));
};

module.exports.returnError = returnError;
