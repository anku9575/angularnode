var config = require('../config'),
    User = require('../models/authuser.model'),
	userService = require('../services/authuser.service'),
	moment = require('moment'),
	moment_tz = require('moment-timezone'),
    errorTypes = require('../errortypes'),
	Promise = require("bluebird");
var Passport = require('passport');    
var helper = require('../controllers/controller.helper');
var orm = require('../orm');
var BCrypt = require('bcrypt-nodejs');

/**
*   Final callback function
***/
exports.finalCallback = function(req, res, ErrorCode, Status, result, ErrorMessage) {
    res.json({"ErrorCode": ErrorCode, Status: Status, "user": result, "ErrorMessage": ErrorMessage});
}

/**
*   @name : Signup
*   @Params : Parameters which is passed from request ( name, email, password, contact, address, created_date )
***/
/*exports.Signup = function(req, res){
    var body = req.body;
    var created_date = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
    var password = BCrypt.hashSync(body.password);
    var params = helper.createUpdateParamsIgnoringNull([
        {"name":"name", "val":body.name},
        {"name":"email", "val":body.email},
        {"name":"password", "val":password},
        {"name":"contact", "val":body.contact},
        {"name":"address", "val":body.address},
        {"name":"created_date", "val":created_date},
    ]);
    return userService.find(body.email).then(function(userData){
        if(!userData){
            return userService.Signup(params).then(function(user){
                if(user){
                    exports.finalCallback(req, res, 200, true, user, "User created successfully !!!");
                } else {
                    exports.finalCallback(req, res, 301, false, null, "An error has occurred.");
                }
            }).catch(function(err){
                exports.finalCallback(req, res, err.status, true, null, err.message);
            });
        } else {
            var err = new errorTypes.AlreadyExistsError('user with email already exists');
            throw err;
        }
    }).catch(function(err){
        exports.finalCallback(req, res, err.status, false, null, err.message);
    });
}*/
                    
/**
*   @name : Login
*   @Params : Parameters which is passed from request ( email, Password )
***/
/*exports.login = function(req, res, next) {
    email = (req.body.email)?req.body.email:false;
    password = (req.body.password)?req.body.password:false;
           
    if(password){
        req.body.password = password;
    }
    if(!req.body.password || !email){
        exports.finalCallback(req, res, 304, false, null, "Please send required parameter.");
    }else{
        return Passport.authenticate('local',
            function(err, user, info) {
                if(err) {
                    return errors.returnError(err,res);
                }
                if(!user) {
                    if(info.error == true && info.statusCode == 201){
                        exports.finalCallback(req, res, 404, false, null, "User doesn't exist.");
                    } else if(info.error == true && info.statusCode == 202){
                        exports.finalCallback(req, res, 401, false, null, "Invalid Password.");
                    }
                }else{
                    return req.logIn(user, function(err) {; 
                        exports.finalCallback(req, res, 200, true, user, "Success.");
                    });
                }
            }
        )(req, res, next);
    }   
};*/

/**
*   @name : Update User
*   @Params : Parameters which is passed from request ( name, email, password, contact, address, created_date )
***/
/*exports.updateProfile = function(req, res){
    var id = req.params.id
    var body = req.body;
    var created_date = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
    var password = BCrypt.hashSync(body.password);
    var params = helper.createUpdateParamsIgnoringNull([
        {"name":"name", "val":body.name},
        {"name":"email", "val":body.email},
        {"name":"password", "val":password},
        {"name":"contact", "val":body.contact},
        {"name":"address", "val":body.address},
        {"name":"created_date", "val":created_date},
    ]);

    return userService.updateProfile(id, params).then(function(updatedProfile){
        if(updatedProfile){
            exports.finalCallback(req, res, 200, true, updatedProfile, "User updated successfully !!!");
        } else {
            var updatedProfile = []
            exports.finalCallback(req, res, 301, false, updatedProfile, "An error has occured !!!");
        }
    }).catch(function(err){
        return err;
    })
}*/ 

/**
*   @name : Delete User
*   @Params : Parameters which is passed from request ( id )
***/
/*exports.deleteUser = function(req, res){
    var id = req.params.id
    return userService.deleteUser(id).then(function(deletedUser){
        if(deletedUser){
            exports.finalCallback(req, res, 200, true, deletedUser, "User deleted successfully !!!");
        } else {
            var deletedUser = []
            exports.finalCallback(req, res, 301, false, deletedUser, "An error has occured !!!");
        }
    }).catch(function(err){
        return err;
    })
}*/