// Helper for Controllers

/// Create update params
/// Object to contain params
/// arrayValues = 
///    [ { name: 'col name', val: value }
///      ,{ name: 'col name', val: value }]
/// if val is undefined, does not update
var createUpdateParams = function(arrayValues) {
  var params = {}
  arrayValues.forEach(function(entry) {
    if(typeof entry.val !=='undefined' ) {
      params[entry.name] = entry.val;
    }
  });

  return params;
}

var createUpdateParamsIgnoringNull = function(arrayValues) {
  var params = {}
  arrayValues.forEach(function(entry) {
    if(typeof entry.val !=='undefined' && entry.val !==null ) {
      params[entry.name] = entry.val;
    }
  });

  return params;
}

var jsonIsEmpty = function(obj) {
  return Object.keys(obj).length===0;
}

exports.createUpdateParams = createUpdateParams;
exports.createUpdateParamsIgnoringNull = createUpdateParamsIgnoringNull;
exports.jsonIsEmpty = jsonIsEmpty;
