var config = require('../config'),
	Question = require('../models/question.model'),
	questionService = require('../services/question.service'),
	moment = require('moment'),
	moment_tz = require('moment-timezone'),
	errorTypes = require('../errortypes'),
	bPromise = require('bluebird');
var path = require('path');
var fs = require('fs');
var helper = require('../controllers/controller.helper');
var orm = require('../orm');
var multer  = require('multer');
var upload = multer({ dest: './uploads/' });
var fileUpload = require('express-fileupload');

/**
*   Final callback function
***/
exports.finalCallback = function(req, res, ErrorCode, Status, result, ErrorMessage) {
    res.json({"ErrorCode": ErrorCode, Status: Status, "data": result, "ErrorMessage": ErrorMessage});
}

/**
*   @name : card variation controller
*   @Params : Parameters which is passed from request ( title, content, button_call, destinationURL, cover_image, card_border)
***/
exports.questionOptions = function(req, res){
    var body = req.body;
    var created_date = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
    bPromise.each(body, function(item, value) {
        var params = helper.createUpdateParamsIgnoringNull([
            {"name":"Questions", "val":item.Questions},
            {"name":"created_date", "val":created_date}
        ]);

        return questionService.questions(params).then(function(que){
            if(que){
                var option_created_date = moment(new Date()).format('YYYY-MM-DD h:mm:ss');
                bPromise.each(item.options, function(optItem, value) {
                    var params1 = helper.createUpdateParamsIgnoringNull([
                        {"name":"questionIdP", "val":que.get("questionId")},
                        {"name":"option1", "val":optItem.option1},
                        {"name":"option2", "val":optItem.option2},
                        {"name":"option3", "val":optItem.option3},
                        {"name":"option4", "val":optItem.option4},
                        {"name":"option5", "val":optItem.option5},
                        {"name":"multiline_text", "val":"sxfdsfds"},
                        {"name":"option_created_date", "val":option_created_date}
                    ]);

                    return questionService.queOptions(params1).then(function(result){
                        if(result){
                            exports.finalCallback(req, res, 200, true, result, "Question and options created !!!");
                        } else{
                            exports.finalCallback(req, res, 301, false, null, "An error has occurred.");
                        }
                    });
                });    
            } else {
                exports.finalCallback(req, res, 301, false, null, "An error has occurred.");
            }
        }).catch(function(err){
            exports.finalCallback(req, res, err.status, false, null, err.message);
        }); 
    }); 

}