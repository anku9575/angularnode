var config = require('./config');
var user = require('./models/authuser.model');
var LocalStrategy = require('passport-local').Strategy;
var helperServices = require('./services/helper.service')
var Passport = require('passport');
var request = require('request');
var BCrypt = require('bcrypt-nodejs');

//Serialization
Passport.serializeUser(function(user, done) {
  console.log(user);
  done(null, user.id);
});

Passport.deserializeUser(function(userId, done) {

   new user({id: userId}).fetch().then(function(user) {
      done(null, user.toJSON());
   });
});

//Strategies
Passport.use(new LocalStrategy({usernameField:'email'},function(email, password, done) {
 
   new user({email: email }).fetch().then(function(data) {
      var authInfo = data;
      if(authInfo === null) {
        return done(null, false, {error : true, statusCode : 201});
      } else {
          authInfo = data.toJSON();
          password_plaintext = password;
        if(!BCrypt.compareSync(password, authInfo.password)) {
            return done(null, false, {error : true, statusCode : 202});
        } else {
            data = {
              "id": authInfo.id,
              "name":authInfo.name,
              "email": authInfo.email,
              "contact": authInfo.contact,
              "address": authInfo.address,
              "created_date": authInfo.created_date,
            }
            return done(null, data);
          }
      }
   });
}));

module.exports = Passport;

    