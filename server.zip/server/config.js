var config = {
    server: {
      id: "environment",
      name: "demo",
      port: "2018",
      internalPort: "2018",
    },
    logging : {
      level : 'debug', //Can be 'debug' , 'warn', 'info', 'error'
      loggers : {
        graylog : { type :'graylog', port : 12201 },
        local : {type: 'local' }
      }
    },
    database: {
      client:'mysql',
      connection: {
        host:'localhost',
        port:'3306',
        user: 'root',
        password: '',
        database: 'ankitsolanki',
        charset: 'utf8'
      }
    },
    session: {
      secret: 'A Super Special And Fantastic Secret!'
    },
};

module.exports = config;

