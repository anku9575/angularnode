var config = require('../config'),
    Question = require('../models/question.model'),
	Options = require('../models/options.model'),
	moment = require('moment'),
	moment_tz = require('moment-timezone'),
	errorTypes = require('../errortypes'),
	Promise = require('bluebird');

/**
*   @name : Creating card in DB ||(or) Updating a card in DB . 
***/

exports.questions = function(params){
    var questionData = new Question(params);
    return questionData.save(null).tap(function(questionData){
        return questionData;
    }).then(function(questionData){
        return questionData;
    }).catch(function(err){
        var err = new errorTypes.BadRequest();
        throw err;
    });
}

exports.queOptions = function(params){
    var optionData = new Options(params);
    return optionData.save(null).tap(function(model){
        return model;
    }).then(function(model){
        return model;
    }).catch(function(err){
        var err = new errorTypes.BadRequest();
        throw err;
    });
}

/**
*   @name : Fetching all cards of a particular user.
***/
exports.variations = function(user_id){
    
    return Cards.forge().query(function(qb){
        qb.where({"user_id" : user_id});
    }).fetchAll().then(function(data){
        return data;
    }).catch(function(error){
        var err = new errorTypes.BadRequest();
        throw err;
    })
}

/**
*   @Action : Featching default cards
*   @params id<int> is a default card id;
***/
exports.getDefaultCard = function(id){   
    return Cards.forge().query(function(qb){
        qb.where({"id" : id});
    }).fetch().then(function(data){
        return data;
    }).catch(function(error){
        var err = new errorTypes.BadRequest();
        throw err;
    }) 
}