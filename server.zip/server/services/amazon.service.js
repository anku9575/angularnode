/**
 * This module contains methods for accessing the Amazon Web Services (AWS)
 * API using their Node SDK.
 * It assumes the presence of a file ~/.aws/credentials for authentication.
 */

var fs = require('fs');
var path = require('path');
var request = require('request');
var AWS = require('aws-sdk');
AWS.config.region = config.amazon_s3_region; //'us-west-2';
var s3 = new AWS.S3();
var s3prom = bbPromise.promisifyAll(s3);

var amazonService = {
	
	/**
	 * listBuckets() returns a list of buckets from AWS.
	 *
	 * @return array<Bucket>
	 */
	//TODO:Add support for paged results from AWS
  listBuckets: bbPromise.method(function() {
		return s3prom.listBucketsAsync()
		.then(function(data) {
			return data.Buckets;
		})
	}),
	
	/**
	 * getBucketPolicy() returns the security policy for the reuqested bucket.
	 *
	 * @param bucket <string> The name of the AWS bucket.
	 * @return ???
	 *
	 */
	getBucketPolicy: bbPromise.method(function(bucket) {
		return s3prom.getBucketPolicyAsync({Bucket: bucket, GrantRead: 'Everyone'})
		.then(function(data) {
			return data.Contents;
		})
	}),
	
	/**
	 * listObjectsInBucket() Returns a list of objects found in the requested bucket.
	 * 
	 * @param bucket <string> The name of the AWS bucket.
	 * @return array<object> Array of objects (files) in bucket.
	 *
	 */
	listObjectsInBucket: bbPromise.method(function(bucket) {
		return s3prom.listObjectsAsync({Bucket: bucket})
		.then(function(data) {
			return data.Contents;
		})
	}),
	
	/**
	 * uploadBufferToBucket() Uploads a local file to an AWS S3 bucket.
	 *
	 * @param buffer <buffer> Memory buffer (stream) containing the image.
	 * @param fileType <string> The image file type, jpg or png.
	 * @param bucket <string> The name of the AWS bucket.
	 * @param bucketPath <string> Path (folder) in the bucket where the image should saved.
	 * @baseFileName <string> The random file name without the extension.
	 * @return ???
	 *
	 */
	uploadBufferToBucket: bbPromise.method(function(buffer, contentType, bucket, bucketPath, baseFileName) {
		var key = bucketPath + baseFileName + '.' + contentType.split('/')[1];
		var params = {
			Bucket: bucket,
			Key: key,
			ContentType: contentType,
			Body: buffer,
			ACL: "public-read"
		};
		
		return s3prom.uploadAsync(params)
		.then(function(res) {
			return res;
		})
		.catch(function(ex) {
			console.log('Error in AmazonService.uploadBufferToBucket: %s', ex.message);
		})
	}),
	
	/**
	 * uploadLocalFileToBucket() Uploads a local file to an AWS S3 bucket.
	 *
	 * @param localFile <string> Fully qualified file/path.
	 * @param bucket <string> The name of the AWS bucket.
	 * @param bucketPath <string> Path (folder) in the bucket where the image should saved.
	 * @baseFileName <string> The random file name without the extension.
	 * @return ???
	 *
	 */
	uploadLocalFileToBucket: bbPromise.method(function(localFile, bucket, bucketPath, baseFileName) {
		var contentType = getContentTypeByFile(path.basename(localFile));
		var key = bucketPath + baseFileName + '.' + contentType.split('/')[1];
		
		var readStream = fs.createReadStream(localFile);
		var params = {
			Bucket: bucket,
			Key: key,
			ContentType: contentType,
			Body: readStream,
			ACL: "public-read"
		};
		
		return s3prom.uploadAsync(params)
		.then(function(res) {
			return res;
		})
		.catch(function(ex) {
			console.log('Error in AmazonService.uploadLocalFileToBucket: %s', ex.message);
		})
	}),
	
	/**
	 * streamRemoteFileToBucket() Pulls a file from a remote server and uploads it to an AWS S3 bucket.
	 * The file is never saved to our server, but merely streamed from the source server to AWS.
	 *
	 * @param remoteFileUrl <string> Fully qualified file/path.
	 * @param bucket <string> The name of the AWS bucket.
	 * @return ???
	 *
	 */
	streamRemoteFileToBucket: bbPromise.method(function(remoteFileUrl, bucket, bucketPath, baseFileName) {
		return s3UploadMethod2(remoteFileUrl, bucket, bucketPath, baseFileName)
		.then(function(data) {
			//console.log(data);
			return data;
		})
	})
	
}

module.exports = amazonService;

/**
 * --- private methods --- 
 *
 */
 
 function s3UploadMethod2(remoteFileUrl, bucket, bucketPath, baseFileName) {
	 //TODO:Figure out how to do this without buffering the ENTIRE file pulled from remoteFileUrl.
	return new bbPromise(function(resolve, reject) {
		
		request({uri: remoteFileUrl, encoding: 'binary'}, function (error, res, body) {
			
			var key = bucketPath + baseFileName + '.' + res.headers['content-type'].split('/')[1];

			var params = {
				Bucket: bucket,
				Key: key,
				ContentType: res.headers['content-type'],
				Body: new Buffer(body, 'binary'),
				ACL: "public-read"
			};
			
			s3.upload(params, function(err, data) {
				if (err) {
					reject(err);
				}
				resolve(data);
			});
		}); //end request()
		
	}); //end new bbPromise()
 }
 
 function s3UploadMethod1(remoteFileUrl, bucket, bucketPath, baseFileName) {
	 //TODO:This method results in a 0 byte file on S3.
	return new bbPromise(function(resolve, reject) {
		
		//var readStream = request(remoteFileUrl);
		var readStream = request({uri: remoteFileUrl, encoding: 'binary'});
		
		readStream.on('response', function(res) {
			console.log('content-type: %s', res.headers['content-type']);
			console.log('content-length: %s', res.headers['content-length']);
			var key = bucketPath + baseFileName + '.' + res.headers['content-type'].split('/')[1];

			var params = {
				Bucket: bucket,
				Key: key,
				ContentType: res.headers['content-type'],
				//ContentLength: parseInt(res.headers['content-length'], 10),
				Body: new Buffer(readStream, 'binary'),
				ACL: "public-read"
			};
			
			/*return s3prom.uploadAsync(params)
			.then(function(res) {
				resolve(res);
			})*/
			
			/*s3.upload(params, function(err, data) {
				if (err) {
					reject(err);
				}
				resolve(data);
			});*/
			
			s3.upload(params)
			.on('httpUploadProgress', function(evt) {
				console.log('Progress:', evt.loaded, '/', evt.total); 
			})
			.send(function(err, data) {
				if (err) {
					reject(err);
				}
				resolve(data);
			})
			
		}) //end readStream.on
	}); //end new bbPromise()
 }

 function getContentTypeByFile(fileName) {
	//default to jpg
  var rc = 'image/jpg';
  var fn = fileName.toLowerCase();

  if (fn.indexOf('.html') >= 0) rc = 'text/html';
  else if (fn.indexOf('.css') >= 0) rc = 'text/css';
  else if (fn.indexOf('.json') >= 0) rc = 'application/json';
  else if (fn.indexOf('.js') >= 0) rc = 'application/x-javascript';
  else if (fn.indexOf('.png') >= 0) rc = 'image/png';
  else if (fn.indexOf('.jpg') >= 0) rc = 'image/jpg';
	else if (fn.indexOf('.jpg') >= 0) rc = 'image/gif';
  else if (fn.indexOf('.jpeg') >= 0) rc = 'image/jpeg';
	else if (fn.indexOf('.xml') >=0) rc = 'application/xml';
	else if (fn.indexOf('.json') >=0) rc = 'application/json';
	else if (fn.indexOf('.js') >=0) rc = 'application/json';

  return rc;
};