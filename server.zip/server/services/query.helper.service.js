// General helper for working with queries

// applies whereClauses to model.
// whereclause: [
//    {col:'colname', val:1,isList:false}
//    ,{col:'colname', val:[1,2],isList:true}
//    ]
module.exports.addParameters = function(model,whereClauses) {
    var result = model;
    whereClauses.forEach(function(whereClause) {
        if(whereClause.isList && whereClause.isList===true) {
          result = result.where(whereClause.col,'in',whereClause.val);
        } else {
          result = result.where(whereClause.col,whereClause.val);
        }
    });
    return result;
};