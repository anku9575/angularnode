var config = require('../config'),
    User = require('../models/authuser.model'),
    moment = require('moment'),
    moment_tz = require('moment-timezone'),
    errorTypes = require('../errortypes'),
    Promise = require("bluebird");

/**
*   @name : Creating user in DB
***/
/*exports.Signup = function(params){
    var userData = new User(params);

    return userData.save(null).tap(function(userData){
        return userData;
    }).then(function(userData){
        return userData;
    }).catch(function(err){
        var err = new errorTypes.BadRequest();
        throw err;
    });
}*/

/**
*   @name : Get user form DB
***/
/*exports.find = function(email){
    return User.forge().query(function(qb){
        qb.where('email', email);
    }).fetch().then(function(data){
        return data
    }).catch(function(err){
        console.log(err);
        return err;
    });
}*/

/**
*   @name : Updating user in DB
***/
/*exports.updateProfile = function(id, params){
   
    var data = params;
    
    return User.forge().query(function(qb){
        qb.where('id', id);
    }).fetch().then(function(user){
        return user.save(data, {patch : true});
    }).then(function(Item){
        return {
            "name":Item.get("name"),
            "email":Item.get("email"),
            "contact":Item.get("contact"),
            "address":Item.get("address")
        }
    }).catch(function(err){
        console.log(err);
        return err;
    });
}*/

/**
*   @name : Deleting user in DB
***/
/*exports.deleteUser = function(id){
    var deleteData
    return User.forge().query(function(qb){
        qb.where("id", id);
    }).fetch().then(function(data){
        data.destroy()
        return deleteData = data
    }).then(function(deleteData){
        return deleteData
    }).catch(function(err){
        return err;
    })
}*/
