var feast = {
    app: {
        environment: process.env.NODE_ENV,
        isDevConfig: function(){
            return feast.app.environment === 'development';
        },
        isLocalConfig: function(){
            return feast.app.environment === 'local';
        }
    }
};

feast.messages = {
    makeErrorMessage: function (message) {
        console.log('feast ERROR: '+message);
    },
    makeWarningMessage: function(message) {
        console.log('feast WARNING: '+message);
    },
    makeSuccessMessage: function(message){
        console.log('feast SUCCESS: '+message);
    }
};

feast.status = {
    ok: 200,
    created: 201,
    accepted: 202,
    no_content: 204,
    moved_permanently: 301,
    temporary_redirect: 307,
    bad_request: 400,
    unauthorized: 401,
    forbidden: 403,
    not_found: 404,
    internal_server_error: 500,
    service_unavailable: 503
};

module.exports = feast;