var request = require('request');
var lo = require('lodash');
var kounta = require('../config').kounta;
var Promise = require('bluebird');
var request = Promise.promisify(request);
var logger = require('./logger.service'),
  path = require('path'),
  scriptName = path.basename(__filename);


exports.parsedRequest = function(opt) {
  return request(opt)
    .then(parseResponse);
};

var parseResponse = exports.parseResponse = function(args) {
  var response = args[0], body = args[1];
  if (response.statusCode !== 200 && response.statusCode !== 201 && response.statusCode !== 202) {
    // console.log('Body', body);
    // console.log('statusCode', response.statusCode);
    var path = response.request.path;
    var method = response.request.method;
    var body = JSON.stringify(body);
    throw new Error(method+' request to '+path+' failed with code '+response.statusCode+' and body '+body);
  };
  try {
    return JSON.parse(body);
  } catch (err) {
    return body;
  }
};

exports.createOauth2client = function(client_options) {
  var access_token = null;
  logger.debug(scriptName,'creating OAuth2.0 client : ' + JSON.stringify(client_options));
  var refreshToken = function() {
    var options = {
      url: 'https://api.kounta.com/v1/token.json',
      method: 'POST',
      json: {
        "grant_type": "refresh_token",
        "client_id": client_options.client_id,
        "client_secret": client_options.client_secret,
        "refresh_token": client_options.refresh_token
      }
    };

    return request(options).then(function(args) {
      var response = args[0];
      var body = args[1];

      access_token = body.access_token;
    });
  }

  // FIXME: Refactor to return muliple parameter including response, refactor use cases
  var oauth2request = function(opt, withResponse) {
    opt.headers = opt.headers || {};
    opt.headers['Authorization'] = 'Bearer ' + access_token;
    logger.verbose(scriptName,'Request: ' + JSON.stringify(opt));
    return request(opt).then(function(args) {
      var response = args[0];
      var body = args[1];
      logger.verbose(scriptName,'Response: ' + JSON.stringify(response));
      if (response.statusCode === 401) {
        return refreshToken().then( lo.partial(oauth2request, opt) );
      } else {
        if (withResponse)
          return { body: parseResponse(args), response: response };
        else
          return parseResponse(args);
      }
    });
  };

  return oauth2request;
};

exports.test = function() {
  var oauth2request = exports.createOauth2client({
    client_id: kounta.client_id,
    client_secret: kounta.client_secret,
    refresh_token: kounta.refresh_token
  });
  var opt = { url: 'https://api.kounta.com/v1/companies/me.json', method: 'GET' }
  var log = console.log.bind(console);
  return oauth2request(opt, log);
}

