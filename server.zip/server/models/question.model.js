var orm = require('../orm');

// Related Models initilize variables
//var Address, Rating, Order, AuthUser, Kitchen;

var Question = orm.bookshelf.Model.extend({
  tableName: 'questions',
  idAttribute: 'questionId',
});

module.exports = Question;

// Load child models after exports, so that can create 2-way relations
