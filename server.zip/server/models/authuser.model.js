var orm = require('../orm');

// Related Models initilize variables
//var Address, Rating, Order, AuthUser, Kitchen;

var User = orm.bookshelf.Model.extend({
  tableName: 'users',
  idAttribute: 'id',
});

module.exports = User;
// Load child models after exports, so that can create 2-way relations
