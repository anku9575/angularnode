/**
 * Module dependencies
 */
 var controller = require('../controllers/authuser.controller');
 //var middleware = require('../middlewares/AuthUser.middleware');
 /**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {
  /**
   * this accepts all request methods to the `/` path
   */

   /***  For signup as a User  ***/
  	/*router.route('/Signup')
      	.post(controller.Signup);*/

    /***  For login as a user  ***/
  	/*router.route('/login')
      	.post(controller.login);*/

    /***  For updating a user  ***/
  	/*router.route('/updateProfile/:id')
      	.post(controller.updateProfile);*/

    /***  For deleting a user  ***/
  	/*router.route('/deleteUser/:id')
      	.post(controller.deleteUser);*/  	  	
}
