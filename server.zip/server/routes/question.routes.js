/**
 * Module dependencies
 */
 var controller = require('../controllers/question.controller');
 //var middleware = require('../middlewares/AuthUser.middleware');
 /**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {
  /**
   * this accepts all request methods to the `/` path
   */

   /***  For signup as a User  ***/
  	router.route('/questionOptions')
      	.post(controller.questionOptions); 	  	
}
