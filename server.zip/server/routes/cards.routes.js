/**
 * Module dependencies
 */
 var controller = require('../controllers/cards.controller');
 var middleware = require('../middlewares/authusers.middleware');
 /**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
 module.exports = function(router){
	/**
	* this accepts all request methods to the `/` path
	*/
   /***  For Creating a Card  ***/
  	router.route('/createCard')
  		.post(middleware.requireAccessKey, controller.createCard);

  	/***  For Image uploading  ***/	
  	router.route('/imageUpload')
  		.post(controller.imageUpload);		
 
 	/***  For Card Variations  ***/	
  	router.route('/variations')
  		.get(controller.variations); 		
 }